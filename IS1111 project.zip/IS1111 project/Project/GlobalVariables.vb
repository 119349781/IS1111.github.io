﻿Module GlobalVariables
    Public decSubTotal, decTotal, decGrandTotal, decVat, decLaces, decEye,
         decQuarter, decVamp, decHeel, decBack, decText, decExtra,
         decCustom, decLogo As Decimal
End Module
