﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmStaffLogin
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnLogin = New System.Windows.Forms.Button()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.btnNewUser = New System.Windows.Forms.Button()
        Me.btnBack = New System.Windows.Forms.Button()
        Me.gbxLogin = New System.Windows.Forms.GroupBox()
        Me.rdoLogin = New System.Windows.Forms.RadioButton()
        Me.rdoAddUser = New System.Windows.Forms.RadioButton()
        Me.gbxAddUser = New System.Windows.Forms.GroupBox()
        Me.txtUsername = New System.Windows.Forms.TextBox()
        Me.txtPassword = New System.Windows.Forms.TextBox()
        Me.lblUsername = New System.Windows.Forms.Label()
        Me.lblPassword = New System.Windows.Forms.Label()
        Me.txtUsernameNew = New System.Windows.Forms.TextBox()
        Me.txtPasswordNew = New System.Windows.Forms.TextBox()
        Me.txtConfirm = New System.Windows.Forms.TextBox()
        Me.lblUsernameNew = New System.Windows.Forms.Label()
        Me.lblPasswordNew = New System.Windows.Forms.Label()
        Me.lblConfirm = New System.Windows.Forms.Label()
        Me.btnClearUser = New System.Windows.Forms.Button()
        Me.gbxLogin.SuspendLayout()
        Me.gbxAddUser.SuspendLayout()
        Me.SuspendLayout()
        '
        'btnLogin
        '
        Me.btnLogin.Location = New System.Drawing.Point(18, 240)
        Me.btnLogin.Name = "btnLogin"
        Me.btnLogin.Size = New System.Drawing.Size(75, 23)
        Me.btnLogin.TabIndex = 0
        Me.btnLogin.Text = "L&ogin"
        Me.btnLogin.UseVisualStyleBackColor = True
        '
        'btnClear
        '
        Me.btnClear.ForeColor = System.Drawing.Color.Red
        Me.btnClear.Location = New System.Drawing.Point(152, 240)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(75, 23)
        Me.btnClear.TabIndex = 1
        Me.btnClear.Text = "&Clear"
        Me.btnClear.UseVisualStyleBackColor = True
        '
        'btnNewUser
        '
        Me.btnNewUser.Location = New System.Drawing.Point(23, 240)
        Me.btnNewUser.Name = "btnNewUser"
        Me.btnNewUser.Size = New System.Drawing.Size(75, 23)
        Me.btnNewUser.TabIndex = 2
        Me.btnNewUser.Text = "Add &User"
        Me.btnNewUser.UseVisualStyleBackColor = True
        '
        'btnBack
        '
        Me.btnBack.ForeColor = System.Drawing.Color.Red
        Me.btnBack.Location = New System.Drawing.Point(37, 415)
        Me.btnBack.Name = "btnBack"
        Me.btnBack.Size = New System.Drawing.Size(75, 23)
        Me.btnBack.TabIndex = 3
        Me.btnBack.Text = "&Back"
        Me.btnBack.UseVisualStyleBackColor = True
        '
        'gbxLogin
        '
        Me.gbxLogin.Controls.Add(Me.lblPassword)
        Me.gbxLogin.Controls.Add(Me.lblUsername)
        Me.gbxLogin.Controls.Add(Me.txtPassword)
        Me.gbxLogin.Controls.Add(Me.txtUsername)
        Me.gbxLogin.Controls.Add(Me.btnLogin)
        Me.gbxLogin.Controls.Add(Me.btnClear)
        Me.gbxLogin.Location = New System.Drawing.Point(80, 96)
        Me.gbxLogin.Name = "gbxLogin"
        Me.gbxLogin.Size = New System.Drawing.Size(247, 284)
        Me.gbxLogin.TabIndex = 4
        Me.gbxLogin.TabStop = False
        Me.gbxLogin.Text = "Login"
        Me.gbxLogin.Visible = False
        '
        'rdoLogin
        '
        Me.rdoLogin.AutoSize = True
        Me.rdoLogin.Location = New System.Drawing.Point(107, 45)
        Me.rdoLogin.Name = "rdoLogin"
        Me.rdoLogin.Size = New System.Drawing.Size(51, 17)
        Me.rdoLogin.TabIndex = 5
        Me.rdoLogin.TabStop = True
        Me.rdoLogin.Text = "&Login"
        Me.rdoLogin.UseVisualStyleBackColor = True
        '
        'rdoAddUser
        '
        Me.rdoAddUser.AutoSize = True
        Me.rdoAddUser.Location = New System.Drawing.Point(542, 45)
        Me.rdoAddUser.Name = "rdoAddUser"
        Me.rdoAddUser.Size = New System.Drawing.Size(69, 17)
        Me.rdoAddUser.TabIndex = 6
        Me.rdoAddUser.TabStop = True
        Me.rdoAddUser.Text = "&Add User"
        Me.rdoAddUser.UseVisualStyleBackColor = True
        '
        'gbxAddUser
        '
        Me.gbxAddUser.Controls.Add(Me.btnClearUser)
        Me.gbxAddUser.Controls.Add(Me.lblConfirm)
        Me.gbxAddUser.Controls.Add(Me.lblPasswordNew)
        Me.gbxAddUser.Controls.Add(Me.lblUsernameNew)
        Me.gbxAddUser.Controls.Add(Me.txtConfirm)
        Me.gbxAddUser.Controls.Add(Me.txtPasswordNew)
        Me.gbxAddUser.Controls.Add(Me.txtUsernameNew)
        Me.gbxAddUser.Controls.Add(Me.btnNewUser)
        Me.gbxAddUser.Location = New System.Drawing.Point(427, 96)
        Me.gbxAddUser.Name = "gbxAddUser"
        Me.gbxAddUser.Size = New System.Drawing.Size(276, 284)
        Me.gbxAddUser.TabIndex = 7
        Me.gbxAddUser.TabStop = False
        Me.gbxAddUser.Text = "Add User"
        Me.gbxAddUser.Visible = False
        '
        'txtUsername
        '
        Me.txtUsername.Location = New System.Drawing.Point(115, 65)
        Me.txtUsername.Name = "txtUsername"
        Me.txtUsername.Size = New System.Drawing.Size(100, 20)
        Me.txtUsername.TabIndex = 2
        '
        'txtPassword
        '
        Me.txtPassword.Location = New System.Drawing.Point(115, 148)
        Me.txtPassword.Name = "txtPassword"
        Me.txtPassword.Size = New System.Drawing.Size(100, 20)
        Me.txtPassword.TabIndex = 3
        '
        'lblUsername
        '
        Me.lblUsername.AutoSize = True
        Me.lblUsername.Location = New System.Drawing.Point(18, 71)
        Me.lblUsername.Name = "lblUsername"
        Me.lblUsername.Size = New System.Drawing.Size(61, 13)
        Me.lblUsername.TabIndex = 4
        Me.lblUsername.Text = "Username: "
        '
        'lblPassword
        '
        Me.lblPassword.AutoSize = True
        Me.lblPassword.Location = New System.Drawing.Point(18, 151)
        Me.lblPassword.Name = "lblPassword"
        Me.lblPassword.Size = New System.Drawing.Size(56, 13)
        Me.lblPassword.TabIndex = 5
        Me.lblPassword.Text = "Password:"
        '
        'txtUsernameNew
        '
        Me.txtUsernameNew.Location = New System.Drawing.Point(135, 53)
        Me.txtUsernameNew.Name = "txtUsernameNew"
        Me.txtUsernameNew.Size = New System.Drawing.Size(100, 20)
        Me.txtUsernameNew.TabIndex = 3
        '
        'txtPasswordNew
        '
        Me.txtPasswordNew.Location = New System.Drawing.Point(135, 124)
        Me.txtPasswordNew.Name = "txtPasswordNew"
        Me.txtPasswordNew.Size = New System.Drawing.Size(100, 20)
        Me.txtPasswordNew.TabIndex = 4
        '
        'txtConfirm
        '
        Me.txtConfirm.Location = New System.Drawing.Point(135, 182)
        Me.txtConfirm.Name = "txtConfirm"
        Me.txtConfirm.Size = New System.Drawing.Size(100, 20)
        Me.txtConfirm.TabIndex = 5
        '
        'lblUsernameNew
        '
        Me.lblUsernameNew.AutoSize = True
        Me.lblUsernameNew.Location = New System.Drawing.Point(20, 56)
        Me.lblUsernameNew.Name = "lblUsernameNew"
        Me.lblUsernameNew.Size = New System.Drawing.Size(61, 13)
        Me.lblUsernameNew.TabIndex = 6
        Me.lblUsernameNew.Text = "Username: "
        '
        'lblPasswordNew
        '
        Me.lblPasswordNew.AutoSize = True
        Me.lblPasswordNew.Location = New System.Drawing.Point(20, 127)
        Me.lblPasswordNew.Name = "lblPasswordNew"
        Me.lblPasswordNew.Size = New System.Drawing.Size(56, 13)
        Me.lblPasswordNew.TabIndex = 7
        Me.lblPasswordNew.Text = "Password:"
        '
        'lblConfirm
        '
        Me.lblConfirm.AutoSize = True
        Me.lblConfirm.Location = New System.Drawing.Point(20, 189)
        Me.lblConfirm.Name = "lblConfirm"
        Me.lblConfirm.Size = New System.Drawing.Size(97, 13)
        Me.lblConfirm.TabIndex = 8
        Me.lblConfirm.Text = "Confirm Password: "
        '
        'btnClearUser
        '
        Me.btnClearUser.BackColor = System.Drawing.SystemColors.Control
        Me.btnClearUser.ForeColor = System.Drawing.Color.Red
        Me.btnClearUser.Location = New System.Drawing.Point(152, 240)
        Me.btnClearUser.Name = "btnClearUser"
        Me.btnClearUser.Size = New System.Drawing.Size(75, 23)
        Me.btnClearUser.TabIndex = 9
        Me.btnClearUser.Text = "Clea&r"
        Me.btnClearUser.UseVisualStyleBackColor = False
        '
        'frmStaffLogin
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.gbxAddUser)
        Me.Controls.Add(Me.rdoAddUser)
        Me.Controls.Add(Me.rdoLogin)
        Me.Controls.Add(Me.gbxLogin)
        Me.Controls.Add(Me.btnBack)
        Me.Name = "frmStaffLogin"
        Me.Text = "Staff Login"
        Me.gbxLogin.ResumeLayout(False)
        Me.gbxLogin.PerformLayout()
        Me.gbxAddUser.ResumeLayout(False)
        Me.gbxAddUser.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btnLogin As Button
    Friend WithEvents btnClear As Button
    Friend WithEvents btnNewUser As Button
    Friend WithEvents btnBack As Button
    Friend WithEvents gbxLogin As GroupBox
    Friend WithEvents lblPassword As Label
    Friend WithEvents lblUsername As Label
    Friend WithEvents txtPassword As TextBox
    Friend WithEvents txtUsername As TextBox
    Friend WithEvents rdoLogin As RadioButton
    Friend WithEvents rdoAddUser As RadioButton
    Friend WithEvents gbxAddUser As GroupBox
    Friend WithEvents btnClearUser As Button
    Friend WithEvents lblConfirm As Label
    Friend WithEvents lblPasswordNew As Label
    Friend WithEvents lblUsernameNew As Label
    Friend WithEvents txtConfirm As TextBox
    Friend WithEvents txtPasswordNew As TextBox
    Friend WithEvents txtUsernameNew As TextBox
End Class
