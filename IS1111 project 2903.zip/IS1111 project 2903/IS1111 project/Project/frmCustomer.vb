﻿Public Class frmCustomer

    Private Sub btnBack_Click(sender As Object, e As EventArgs) Handles btnBack.Click
        'brings the user back to the start up page 
        Me.Hide()
        frmStartPage.Show()
    End Sub

    Private Sub btnCreate_Click(sender As Object, e As EventArgs) Handles btnCreate.Click
        'validating the form
        Dim intMinLen As Integer = 14
        Dim intMin As Integer = 10
        Dim intPassMin As Integer = 8
        Dim intPassMax As Integer = 20
        If txtName.Text = ("") Then
            MessageBox.Show("Please Enter Your Name", "ERROR",
                            MessageBoxButtons.OK,
                             MessageBoxIcon.Error)
        ElseIf mskDOB.Text = ("  /  /") Then
            MessageBox.Show("Please Enter your Date of Birth", "ERROR",
                            MessageBoxButtons.OK,
                             MessageBoxIcon.Error)
        ElseIf Len(mskDOB.Text) < intMin Then
            MessageBox.Show("Please Enter your Date Of Birth in the format DD/MM/YYYY", "ERROR",
                                MessageBoxButtons.OK,
                                 MessageBoxIcon.Error)
        ElseIf txtAddress.Text = ("") Then
            MessageBox.Show("Please Enter your Address", "ERROR",
                            MessageBoxButtons.OK,
                             MessageBoxIcon.Error)
        ElseIf txtCity.Text = ("") Then
            MessageBox.Show("Please Enter your Town/City", "ERROR",
                            MessageBoxButtons.OK,
                             MessageBoxIcon.Error)
        ElseIf mskContact.Text = ("(   )    -") Then
            MessageBox.Show("Please Enter your Phone Number", "ERROR",
                            MessageBoxButtons.OK,
                             MessageBoxIcon.Error)
        ElseIf Len(mskContact.Text) < intMinLen Then
            MessageBox.Show("Phone Number must be 10 digits", "ERROR",
                                MessageBoxButtons.OK,
                                 MessageBoxIcon.Error)
        ElseIf txtEmail.Text = ("") Then
            MessageBox.Show("Please Enter your Email Address", "ERROR",
                            MessageBoxButtons.OK,
                             MessageBoxIcon.Error)
        ElseIf txtUser.Text = ("") Then
            MessageBox.Show("Please Enter a Username", "ERROR",
                            MessageBoxButtons.OK,
                             MessageBoxIcon.Error)
        ElseIf txtPass.Text = "" Then
            MessageBox.Show("Please Enter a Password", "ERROR",
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Error)
        ElseIf Len(txtPass.Text) < intPassMin Or Len(txtPass.Text) > intPassMax Then
            MessageBox.Show("Password Must Be Between 8 and 20 characters", "ERROR",
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Error)
        ElseIf txtConfirm.Text <> txtPass.Text Then
            MessageBox.Show("Passwords don't match", "ERROR",
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Error)
        Else
            'if all information is correctly entered then the customer will be brought
            'to their account page
            MessageBox.Show("Account Successfully Created!", "Success",
                            MessageBoxButtons.OK)
            Me.Hide()
            frmAccount.Show()
        End If

    End Sub

    Private Sub btnReset_Click(sender As Object, e As EventArgs) Handles btnReset.Click
        'clears the form
        Dim DialogResult As DialogResult
        DialogResult = MessageBox.Show("Clear the form?", "Clear Form",
                                       MessageBoxButtons.YesNo,
                                       MessageBoxIcon.Question,
                                       MessageBoxDefaultButton.Button2)
        If DialogResult = DialogResult.Yes Then
            txtName.Clear()
            mskDOB.Clear()
            txtAddress.Clear()
            txtCity.Clear()
            mskContact.Clear()
            txtEmail.Clear()
            txtUser.Clear()
            txtPass.Clear()
            txtName.Focus()
        End If
    End Sub

    Private Sub radExisting_CheckedChanged(sender As Object, e As EventArgs) Handles radExisting.CheckedChanged
        'showing the appropriate group box to the customer
        If radNew.Checked Then
            grbExisting.Visible = False
            grbNew.Visible = True
        Else
            grbExisting.Visible = True
            grbNew.Visible = False
        End If
    End Sub

    Private Sub radNew_CheckedChanged(sender As Object, e As EventArgs) Handles radNew.CheckedChanged
        'showing the appropriate group box to the customer
        If radNew.Checked Then
            grbExisting.Visible = False
            grbNew.Visible = True
        Else
            grbExisting.Visible = True
            grbNew.Visible = False
        End If
    End Sub

    Private Sub txtPassword_TextChanged(sender As Object, e As EventArgs) Handles txtPassword.TextChanged
        txtPassword.UseSystemPasswordChar = True
    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        'clears the form
        Dim DialogResult As DialogResult
        DialogResult = MessageBox.Show("Clear the form?", "Clear Form",
                                       MessageBoxButtons.YesNo,
                                       MessageBoxIcon.Question,
                                       MessageBoxDefaultButton.Button2)
        If DialogResult = DialogResult.Yes Then
            txtUsername.Clear()
            txtPassword.Clear()
            txtUsername.Focus()
        End If
    End Sub

    Private Sub btnLogin_Click(sender As Object, e As EventArgs) Handles btnLogin.Click
        'if the login information is correct the user will be brought
        'to their account page
        Me.Hide()
        frmAccount.Show()
    End Sub

End Class
