﻿Public Class frmStaffLogin
    Private Sub rdoLogin_CheckedChanged(sender As Object, e As EventArgs) Handles rdoLogin.CheckedChanged
        'Making gbxLogin visibile if rdoLogin is checked otherwise gbxLogin is invisible.
        If rdoLogin.Checked = True Then
            gbxLogin.Visible = True
        Else gbxLogin.Visible = False
        End If
    End Sub

    Private Sub rdoAddUser_CheckedChanged(sender As Object, e As EventArgs) Handles rdoAddUser.CheckedChanged
        'Making gbxAddUser visible if rdoAddUser is checked otherwise gbxAddUser is invisible.
        If rdoAddUser.Checked = True Then
            gbxAddUser.Visible = True
        Else gbxAddUser.Visible = False
        End If
    End Sub

    Private Sub btnBack_Click(sender As Object, e As EventArgs) Handles btnBack.Click
        'Closing the current form abd opening frmStartPage if btnBack is clicked.
        Me.Hide()
        frmStartPage.Show()
    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        'Clearing txtPassword and txtUsername if btnClear is clicked.
        txtPassword.Clear()
        txtUsername.Clear()
    End Sub

    Private Sub btnClearUser_Click(sender As Object, e As EventArgs) Handles btnClearUser.Click
        'Clearing txtPasswordNew, txtUsernameNew and txtConfirm if btnClearUser is clicked.
        txtPasswordNew.Clear()
        txtUsernameNew.Clear()
        txtConfirm.Clear()
    End Sub

    Private Sub btnNewUser_Click(sender As Object, e As EventArgs) Handles btnNewUser.Click
        'Using an if statement to check if the text in the textboxes match
        If txtPasswordNew.Text = txtConfirm.Text Then
            'If the text matches then display a message to let the user know it was successful
            MessageBox.Show("You have successfully added a new user")
            'If the text doesnt match display a message letting the user know that it wasnt successful
        Else MessageBox.Show("The passwords did not match please try again")
        End If
    End Sub

    Private Sub BindingSource1_CurrentChanged(sender As Object, e As EventArgs) Handles BindingSource1.CurrentChanged

    End Sub

    Private Sub frmStaffLogin_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'StaffLoginDataSet.StaffLogin' table. You can move, or remove it, as needed.
        Me.StaffLoginTableAdapter.Fill(Me.StaffLoginDataSet.StaffLogin)

    End Sub

    Private Sub btnView_Click(sender As Object, e As EventArgs) Handles btnView.Click
        'Closing the current form and opening frmStaffAccountQuery when btnRun is clicked.
        Me.Hide()
        frmStaffAccountQuery.Show()
    End Sub
End Class