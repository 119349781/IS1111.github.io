﻿Public Class frmConfirmation
    Private Sub btnExit_Click(sender As Object, e As EventArgs)
        'Closing the current form and opening frmMeme
        frmMeme.Show()
        Me.Hide()
    End Sub

    Private Sub btnPrint_Click(sender As Object, e As EventArgs) Handles btnPrint.Click
        'Closing the current form and opening frmMeme2
        frmMeme2.Show()
        Me.Hide()
    End Sub

End Class