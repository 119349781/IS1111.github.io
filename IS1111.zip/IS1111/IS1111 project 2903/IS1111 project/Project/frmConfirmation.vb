﻿Public Class frmConfirmation

    Private Sub MensShoesToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles MensShoesToolStripMenuItem.Click
        'Brings customer to order form
        Me.Close()
        frmOrder.Show()
    End Sub

    Private Sub WomensShoesToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles WomensShoesToolStripMenuItem.Click
        'Brings customer to order form
        Me.Close()
        frmOrder.Show()
    End Sub

    Private Sub LogoutToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles LogoutToolStripMenuItem.Click
        'brings customer back to login page 
        Dim DialogResult As DialogResult
        DialogResult = MessageBox.Show("Are you sure you want to logout?", "Your Style Ltd.",
                                       MessageBoxButtons.YesNo,
                                       MessageBoxIcon.Question,
                                       MessageBoxDefaultButton.Button2)
        If DialogResult = DialogResult.Yes Then
            Me.Close()
            frmCustomer.Show()
        End If
    End Sub

    Private Sub btnReceipt_Click(sender As Object, e As EventArgs) Handles btnReceipt.Click
        'prints off the order receipt
        PrintPreviewDialog1.ShowDialog()
        If DialogResult = DialogResult.Yes Then
            PrintDocument1.Print()
        End If
    End Sub

    Private Sub dgvReceipt_CellContentClick(sender As Object, e As DataGridViewCellEventArgs)

    End Sub

    Private Sub frmConfirmation_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim strResult
        If frmOrder.picLogo.ImageLocation <> ("") Then
            strResult = "Yes"
        Else
            strResult = "No"
        End If

        'receipt shows when the form loads
        txtToday.Text = Today()
        Dim rn As New Random
        txtNumber.Text = rn.Next()
        txtName.Text = frmPayment.txtCustomer.Text
        txtAddr.Text = frmPayment.txtAddress.Text
        txtContact.Text = frmPayment.mskPhone.Text
        txtCustom.Text = frmOrder.cmbShoeType.SelectedItem
        txtPicture.Text = strResult
        txtAnswer.Text = strResult
        txtQuarter.Text = ("Quarter: " & frmOrder.cmbQuarter.SelectedItem)
        txtVamp.Text = ("Vamp: " & frmOrder.cmbVamp.SelectedItem)
        txtEye.Text = ("Eyestay: " & frmOrder.cmbEyestay.SelectedItem)
        txtLaces.Text = ("Laces: " & frmOrder.cmbLaces.SelectedItem)
        txtBack.Text = ("Back Counter: " & frmOrder.cmbBack.SelectedItem)
        txtText.Text = ("Text: " & frmOrder.txtText.Text)
        txtShoeS.Text = frmOrder.cmbSize.SelectedItem
        txtMode.Text = FormatCurrency(decSubTotal)
        txtQuart.Text = FormatCurrency(decQuarter)
        txtVamps.Text = FormatCurrency(decVamp)
        txtEyestay.Text = FormatCurrency(decEye)
        txtLacess.Text = FormatCurrency(decLaces)
        txtCounter.Text = FormatCurrency(decBack)
        txtTexts.Text = FormatCurrency(decText + decExtra)
        txtPic.Text = FormatCurrency(decLogo)
        txtPriceShoe.Text = FormatCurrency(decTotal / 2)
        txtVatat.Text = FormatCurrency(decVat)
        txtTot.Text = FormatCurrency(decGrandTotal)
        txtQuant.Text = dblQuantity
        txtDis.Text = FormatCurrency(decDiscount)
        txtTotAmount.Text = FormatCurrency(decOverallTotal)
    End Sub

End Class