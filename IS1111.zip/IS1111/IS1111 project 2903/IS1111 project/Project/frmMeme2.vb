﻿Public Class frmMeme2
    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        'opening frmMeme2 and closing the current form
        Me.Close()
        frmMeme.Show()
    End Sub
End Class