﻿Module GlobalVariables
    Public decSubTotal, decTotal, decGrandTotal, decVat, decLaces, decEye,
         decQuarter, decVamp, decHeel, decBack, decText, decExtra,
         decCustom, decOverallTotal, decLogo, decDiscount As Decimal
    Public dblQuantity As Double
    Public strUser As String
End Module
