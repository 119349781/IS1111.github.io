﻿Public Class frmReports
    Private Sub btnDisplay_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub btnPrint_Click(sender As Object, e As EventArgs)
        MsgBox("How many copies? ")
    End Sub

    Private Sub LogoutToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles LogoutToolStripMenuItem.Click
        Dim DialogResult As DialogResult
        DialogResult = MessageBox.Show("Are you sure you want to logout.", "Your Style Ltd.",
                                   MessageBoxButtons.YesNo,
                                   MessageBoxIcon.Question,
                                   MessageBoxDefaultButton.Button2)
        If DialogResult = DialogResult.Yes Then
            Me.Close()
            frmStaffLogin.Show()
        End If
    End Sub

    Private Sub frmReports_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'ReportsDataSet.tblReport' table. You can move, or remove it, as needed.
        Me.TblReportTableAdapter.Fill(Me.ReportsDataSet.tblReport)

    End Sub

    Private Sub btnBack_Click(sender As Object, e As EventArgs) Handles btnBack.Click
        frmOptions.Show()
        Me.Hide()
    End Sub

    Private Sub HomeToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles HomeToolStripMenuItem.Click
        'opening frmStartPage and closing the current form
        frmStartPage.Show()
        Me.Hide()

    End Sub

    Private Sub HelpToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles HelpToolStripMenuItem.Click
        'opening frmUserManual and closing the current page
        frmUserManual.Show()
        Me.Hide()
    End Sub

    Private Sub AboutToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AboutToolStripMenuItem.Click
        'opening frmAboutUs.
        frmAboutUs.Show()

    End Sub

    Private Sub btnPrint_Click_1(sender As Object, e As EventArgs) Handles btnPrint.Click
        'Closing the current form and opening frmMeme2
        frmMeme2.Show()
        Me.Hide()
    End Sub
End Class