﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmPayment
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.txtAddress = New System.Windows.Forms.TextBox()
        Me.txtCustomer = New System.Windows.Forms.TextBox()
        Me.mskPhone = New System.Windows.Forms.MaskedTextBox()
        Me.lblContact = New System.Windows.Forms.Label()
        Me.lblAddress = New System.Windows.Forms.Label()
        Me.lblCustomer = New System.Windows.Forms.Label()
        Me.lblOrder = New System.Windows.Forms.Label()
        Me.mskCvv = New System.Windows.Forms.MaskedTextBox()
        Me.lblCvv = New System.Windows.Forms.Label()
        Me.mskExpiry = New System.Windows.Forms.MaskedTextBox()
        Me.lblExpiry = New System.Windows.Forms.Label()
        Me.mskNumber = New System.Windows.Forms.MaskedTextBox()
        Me.lblNumber = New System.Windows.Forms.Label()
        Me.txtName = New System.Windows.Forms.TextBox()
        Me.lblName = New System.Windows.Forms.Label()
        Me.btnPay = New System.Windows.Forms.Button()
        Me.lblDetails = New System.Windows.Forms.Label()
        Me.txtTotal = New System.Windows.Forms.TextBox()
        Me.lblTotal = New System.Windows.Forms.Label()
        Me.btnBack = New System.Windows.Forms.Button()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.HomeToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TrackOrderToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ContactUsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.LogoutToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'txtAddress
        '
        Me.txtAddress.Location = New System.Drawing.Point(127, 344)
        Me.txtAddress.Margin = New System.Windows.Forms.Padding(2)
        Me.txtAddress.Name = "txtAddress"
        Me.txtAddress.Size = New System.Drawing.Size(127, 20)
        Me.txtAddress.TabIndex = 38
        '
        'txtCustomer
        '
        Me.txtCustomer.Location = New System.Drawing.Point(127, 309)
        Me.txtCustomer.Margin = New System.Windows.Forms.Padding(2)
        Me.txtCustomer.Name = "txtCustomer"
        Me.txtCustomer.Size = New System.Drawing.Size(127, 20)
        Me.txtCustomer.TabIndex = 37
        '
        'mskPhone
        '
        Me.mskPhone.Location = New System.Drawing.Point(127, 377)
        Me.mskPhone.Margin = New System.Windows.Forms.Padding(2)
        Me.mskPhone.Mask = "(999) 000-0000"
        Me.mskPhone.Name = "mskPhone"
        Me.mskPhone.Size = New System.Drawing.Size(127, 20)
        Me.mskPhone.TabIndex = 41
        '
        'lblContact
        '
        Me.lblContact.AutoSize = True
        Me.lblContact.BackColor = System.Drawing.Color.Transparent
        Me.lblContact.Location = New System.Drawing.Point(17, 377)
        Me.lblContact.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblContact.Name = "lblContact"
        Me.lblContact.Size = New System.Drawing.Size(87, 13)
        Me.lblContact.TabIndex = 44
        Me.lblContact.Text = "Contact Number:"
        '
        'lblAddress
        '
        Me.lblAddress.AutoSize = True
        Me.lblAddress.BackColor = System.Drawing.Color.Transparent
        Me.lblAddress.Location = New System.Drawing.Point(9, 344)
        Me.lblAddress.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblAddress.Name = "lblAddress"
        Me.lblAddress.Size = New System.Drawing.Size(95, 13)
        Me.lblAddress.TabIndex = 43
        Me.lblAddress.Text = "Customer Address:"
        '
        'lblCustomer
        '
        Me.lblCustomer.AutoSize = True
        Me.lblCustomer.BackColor = System.Drawing.Color.Transparent
        Me.lblCustomer.Location = New System.Drawing.Point(19, 314)
        Me.lblCustomer.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblCustomer.Name = "lblCustomer"
        Me.lblCustomer.Size = New System.Drawing.Size(85, 13)
        Me.lblCustomer.TabIndex = 40
        Me.lblCustomer.Text = "Customer Name:"
        '
        'lblOrder
        '
        Me.lblOrder.AutoSize = True
        Me.lblOrder.BackColor = System.Drawing.Color.Transparent
        Me.lblOrder.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblOrder.Location = New System.Drawing.Point(122, 269)
        Me.lblOrder.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblOrder.Name = "lblOrder"
        Me.lblOrder.Size = New System.Drawing.Size(163, 25)
        Me.lblOrder.TabIndex = 39
        Me.lblOrder.Text = "Order Information"
        '
        'mskCvv
        '
        Me.mskCvv.Location = New System.Drawing.Point(126, 243)
        Me.mskCvv.Margin = New System.Windows.Forms.Padding(2)
        Me.mskCvv.Mask = "000"
        Me.mskCvv.Name = "mskCvv"
        Me.mskCvv.Size = New System.Drawing.Size(43, 20)
        Me.mskCvv.TabIndex = 36
        '
        'lblCvv
        '
        Me.lblCvv.AutoSize = True
        Me.lblCvv.BackColor = System.Drawing.Color.Transparent
        Me.lblCvv.Location = New System.Drawing.Point(73, 247)
        Me.lblCvv.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblCvv.Name = "lblCvv"
        Me.lblCvv.Size = New System.Drawing.Size(31, 13)
        Me.lblCvv.TabIndex = 35
        Me.lblCvv.Text = "CVV:"
        '
        'mskExpiry
        '
        Me.mskExpiry.Location = New System.Drawing.Point(126, 218)
        Me.mskExpiry.Margin = New System.Windows.Forms.Padding(2)
        Me.mskExpiry.Mask = "00/0000"
        Me.mskExpiry.Name = "mskExpiry"
        Me.mskExpiry.Size = New System.Drawing.Size(64, 20)
        Me.mskExpiry.TabIndex = 34
        '
        'lblExpiry
        '
        Me.lblExpiry.AutoSize = True
        Me.lblExpiry.BackColor = System.Drawing.Color.Transparent
        Me.lblExpiry.Location = New System.Drawing.Point(40, 222)
        Me.lblExpiry.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblExpiry.Name = "lblExpiry"
        Me.lblExpiry.Size = New System.Drawing.Size(64, 13)
        Me.lblExpiry.TabIndex = 33
        Me.lblExpiry.Text = "Expiry Date:"
        '
        'mskNumber
        '
        Me.mskNumber.Location = New System.Drawing.Point(126, 190)
        Me.mskNumber.Margin = New System.Windows.Forms.Padding(2)
        Me.mskNumber.Mask = "0000-0000-0000-0000"
        Me.mskNumber.Name = "mskNumber"
        Me.mskNumber.Size = New System.Drawing.Size(119, 20)
        Me.mskNumber.TabIndex = 32
        '
        'lblNumber
        '
        Me.lblNumber.AutoSize = True
        Me.lblNumber.BackColor = System.Drawing.Color.Transparent
        Me.lblNumber.Location = New System.Drawing.Point(32, 194)
        Me.lblNumber.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblNumber.Name = "lblNumber"
        Me.lblNumber.Size = New System.Drawing.Size(72, 13)
        Me.lblNumber.TabIndex = 31
        Me.lblNumber.Text = "Card Number:"
        '
        'txtName
        '
        Me.txtName.Location = New System.Drawing.Point(126, 160)
        Me.txtName.Margin = New System.Windows.Forms.Padding(2)
        Me.txtName.Name = "txtName"
        Me.txtName.Size = New System.Drawing.Size(119, 20)
        Me.txtName.TabIndex = 30
        '
        'lblName
        '
        Me.lblName.AutoSize = True
        Me.lblName.BackColor = System.Drawing.Color.Transparent
        Me.lblName.Location = New System.Drawing.Point(-2, 164)
        Me.lblName.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblName.Name = "lblName"
        Me.lblName.Size = New System.Drawing.Size(106, 13)
        Me.lblName.TabIndex = 29
        Me.lblName.Text = "Name of CardHolder:"
        '
        'btnPay
        '
        Me.btnPay.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnPay.Location = New System.Drawing.Point(437, 218)
        Me.btnPay.Margin = New System.Windows.Forms.Padding(2)
        Me.btnPay.Name = "btnPay"
        Me.btnPay.Size = New System.Drawing.Size(81, 33)
        Me.btnPay.TabIndex = 42
        Me.btnPay.Text = "&Pay Now"
        Me.btnPay.UseVisualStyleBackColor = True
        '
        'lblDetails
        '
        Me.lblDetails.AutoSize = True
        Me.lblDetails.BackColor = System.Drawing.Color.Transparent
        Me.lblDetails.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDetails.Location = New System.Drawing.Point(122, 124)
        Me.lblDetails.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblDetails.Name = "lblDetails"
        Me.lblDetails.Size = New System.Drawing.Size(281, 25)
        Me.lblDetails.TabIndex = 28
        Me.lblDetails.Text = "Please Enter Your Card Details"
        '
        'txtTotal
        '
        Me.txtTotal.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtTotal.Location = New System.Drawing.Point(189, 90)
        Me.txtTotal.Margin = New System.Windows.Forms.Padding(2)
        Me.txtTotal.Name = "txtTotal"
        Me.txtTotal.ReadOnly = True
        Me.txtTotal.Size = New System.Drawing.Size(165, 30)
        Me.txtTotal.TabIndex = 27
        '
        'lblTotal
        '
        Me.lblTotal.AutoSize = True
        Me.lblTotal.BackColor = System.Drawing.Color.Transparent
        Me.lblTotal.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTotal.Location = New System.Drawing.Point(122, 93)
        Me.lblTotal.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblTotal.Name = "lblTotal"
        Me.lblTotal.Size = New System.Drawing.Size(68, 25)
        Me.lblTotal.TabIndex = 26
        Me.lblTotal.Text = "Total:"
        '
        'btnBack
        '
        Me.btnBack.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnBack.ForeColor = System.Drawing.Color.Red
        Me.btnBack.Location = New System.Drawing.Point(438, 302)
        Me.btnBack.Margin = New System.Windows.Forms.Padding(2)
        Me.btnBack.Name = "btnBack"
        Me.btnBack.Size = New System.Drawing.Size(79, 32)
        Me.btnBack.TabIndex = 45
        Me.btnBack.Text = "&Back"
        Me.btnBack.UseVisualStyleBackColor = True
        '
        'MenuStrip1
        '
        Me.MenuStrip1.BackColor = System.Drawing.Color.Transparent
        Me.MenuStrip1.Font = New System.Drawing.Font("Segoe UI", 12.0!)
        Me.MenuStrip1.ImageScalingSize = New System.Drawing.Size(24, 24)
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.HomeToolStripMenuItem, Me.TrackOrderToolStripMenuItem, Me.ContactUsToolStripMenuItem, Me.LogoutToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Padding = New System.Windows.Forms.Padding(4, 1, 0, 1)
        Me.MenuStrip1.Size = New System.Drawing.Size(800, 27)
        Me.MenuStrip1.TabIndex = 46
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'HomeToolStripMenuItem
        '
        Me.HomeToolStripMenuItem.Name = "HomeToolStripMenuItem"
        Me.HomeToolStripMenuItem.Size = New System.Drawing.Size(64, 25)
        Me.HomeToolStripMenuItem.Text = "&Home"
        '
        'TrackOrderToolStripMenuItem
        '
        Me.TrackOrderToolStripMenuItem.Name = "TrackOrderToolStripMenuItem"
        Me.TrackOrderToolStripMenuItem.Size = New System.Drawing.Size(64, 25)
        Me.TrackOrderToolStripMenuItem.Text = "&About"
        '
        'ContactUsToolStripMenuItem
        '
        Me.ContactUsToolStripMenuItem.Name = "ContactUsToolStripMenuItem"
        Me.ContactUsToolStripMenuItem.Size = New System.Drawing.Size(54, 25)
        Me.ContactUsToolStripMenuItem.Text = "H&elp"
        '
        'LogoutToolStripMenuItem
        '
        Me.LogoutToolStripMenuItem.Name = "LogoutToolStripMenuItem"
        Me.LogoutToolStripMenuItem.Size = New System.Drawing.Size(71, 25)
        Me.LogoutToolStripMenuItem.Text = "Logout"
        '
        'frmPayment
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = Global.Project.My.Resources.Resources.background
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.txtAddress)
        Me.Controls.Add(Me.txtCustomer)
        Me.Controls.Add(Me.mskPhone)
        Me.Controls.Add(Me.lblContact)
        Me.Controls.Add(Me.lblAddress)
        Me.Controls.Add(Me.lblCustomer)
        Me.Controls.Add(Me.lblOrder)
        Me.Controls.Add(Me.mskCvv)
        Me.Controls.Add(Me.lblCvv)
        Me.Controls.Add(Me.mskExpiry)
        Me.Controls.Add(Me.lblExpiry)
        Me.Controls.Add(Me.mskNumber)
        Me.Controls.Add(Me.lblNumber)
        Me.Controls.Add(Me.txtName)
        Me.Controls.Add(Me.lblName)
        Me.Controls.Add(Me.btnPay)
        Me.Controls.Add(Me.lblDetails)
        Me.Controls.Add(Me.txtTotal)
        Me.Controls.Add(Me.lblTotal)
        Me.Controls.Add(Me.btnBack)
        Me.Controls.Add(Me.MenuStrip1)
        Me.Name = "frmPayment"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "frmPayment"
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents txtAddress As TextBox
    Friend WithEvents txtCustomer As TextBox
    Friend WithEvents mskPhone As MaskedTextBox
    Friend WithEvents lblContact As Label
    Friend WithEvents lblAddress As Label
    Friend WithEvents lblCustomer As Label
    Friend WithEvents lblOrder As Label
    Friend WithEvents mskCvv As MaskedTextBox
    Friend WithEvents lblCvv As Label
    Friend WithEvents mskExpiry As MaskedTextBox
    Friend WithEvents lblExpiry As Label
    Friend WithEvents mskNumber As MaskedTextBox
    Friend WithEvents lblNumber As Label
    Friend WithEvents txtName As TextBox
    Friend WithEvents lblName As Label
    Friend WithEvents btnPay As Button
    Friend WithEvents lblDetails As Label
    Friend WithEvents txtTotal As TextBox
    Friend WithEvents lblTotal As Label
    Friend WithEvents btnBack As Button
    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents HomeToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents TrackOrderToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ContactUsToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents LogoutToolStripMenuItem As ToolStripMenuItem
End Class
