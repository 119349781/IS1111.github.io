﻿Public Class frmCustomer
    'Contribution by each group member
    'Casey/119365941: Set up the access database, made a background and logo and put them in every form.
    'designed and programmed the staff side and user manual got all the forms working together and 
    'tidied up design And comments. Implemented menustrips And made sure all controls were labeled. Designed the login 
    'system for both staff and customer using an array, sub procedure and loop. Made a  splashscreen and about screen.
    'Added a timer. Made a query For staff To track a customers order. Used a nav tool to allow new staff members to be added. 
    'Niamh/119349781: Designed and programmed the customer side. Helped to ensure the logo, background and menustrip was in
    'each form. Made a github repository for code to be exchanged. Made a query for customers to track their order. Made. the
    'order form for customers to design their order and confirm payment details.
    'Oisin/119303443: Nothing.
    'Liam/119357686: Nothing.

    'Declaring variables and their datatype. strCredentials is an array with 5 values inside.
    Dim strCredentials(6) As String
    Dim strUsername As String
    Dim strPassword As String
    'Declaring n as an Integer and setting the value of n as -1
    Dim n As Integer = -1
    'Declaring intCount as an integer and setting it equal to 3. Using it to limit the attempts at login
    Dim intCount As Integer = 3

    'Creating a sub procedure called correct()
    Public Sub correct()
        'Using a Do loop
        Do
            'Increasing the value of n by 1
            n += 1
            'Looping until strCredentials() >= strUsername Or until n = 6
        Loop Until (strCredentials(n) >= strUsername) Or (n = 6)

        'Using an if statement to check if strCredentials(n) = strUsername
        If strCredentials(n) = strUsername Then
            'If they are equal then frmOptions is opened and the current form is closed.
            frmAccount.Show()
            Me.Hide()
        End If
    End Sub

    Private Sub frmCustomer_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'CustomerDataSet.tblCustomerInfo' table. You can move, or remove it, as needed.
        Me.TblCustomerInfoTableAdapter.Fill(Me.CustomerDataSet.tblCustomerInfo)
        'TODO: This line of code loads data into the 'IS1111DataSet1.tblCustomer' table. You can move, or remove it, as needed.
        Me.TblCustomerInfoTableAdapter.Fill(Me.CustomerDataSet.tblCustomerInfo)

        'Populating the array when the form loads.
        strCredentials = {"aosullivan", "croche", "ecollins", "jdoe", "jsmith", "ldunne", "mmurphy"}

    End Sub
    Private Sub btnBack_Click(sender As Object, e As EventArgs) Handles btnBack.Click
        'brings the user back to the start up page 
        Me.Hide()
        frmStartPage.Show()
    End Sub

    Private Sub btnCreate_Click(sender As Object, e As EventArgs) Handles btnCreate.Click
        'validating the form
        strUser = txtUser.Text
        Dim intMinLen As Integer = 14
        Dim intMin As Integer = 10
        Dim intPassMin As Integer = 8
        Dim intPassMax As Integer = 20
        If txtName.Text = ("") Then
            MessageBox.Show("Please Enter Your Name", "Shoes Ltd.",
                            MessageBoxButtons.OK,
                             MessageBoxIcon.Error)
            txtName.Focus()
        ElseIf txtSurname.Text = ("") Then
            MessageBox.Show("Please Enter your Surname", "Shoes Ltd.",
                            MessageBoxButtons.OK,
                             MessageBoxIcon.Error)
            txtSurname.Focus()
        ElseIf mskDOB.Text = ("  /  /    ") Then
            MessageBox.Show("Please Enter your Date of Birth", "Shoes Ltd.",
            MessageBoxButtons.OK,
            MessageBoxIcon.Error)
            mskDOB.Focus()
        ElseIf Len(mskDOB.Text) < intMin Then
            MessageBox.Show("Please Enter your Date Of Birth in the format MM/DD/YYYY", "Shoes Ltd.",
                                MessageBoxButtons.OK,
                                 MessageBoxIcon.Error)

        ElseIf txtAddress.Text = ("") Then
            MessageBox.Show("Please Enter your Address", "Shoes Ltd.",
                            MessageBoxButtons.OK,
                             MessageBoxIcon.Error)
            txtAddress.Focus()
        ElseIf mskContact.Text = ("(   )    -") Then
            MessageBox.Show("Please Enter your Phone Number", "Shoes Ltd.",
                            MessageBoxButtons.OK,
                             MessageBoxIcon.Error)
            mskContact.Focus()
        ElseIf Len(mskContact.Text) < intMinLen Then
            MessageBox.Show("Phone Number must be 10 digits", "Shoes Ltd.",
                                MessageBoxButtons.OK,
                                 MessageBoxIcon.Error)
        ElseIf txtEmail.Text = ("") Then
            MessageBox.Show("Please Enter your Email Address", "Shoes Ltd.",
                            MessageBoxButtons.OK,
                             MessageBoxIcon.Error)
            txtEmail.Focus()
        ElseIf txtUser.Text = ("") Then
            MessageBox.Show("Please Enter a Username", "Shoes Ltd.",
                            MessageBoxButtons.OK,
                             MessageBoxIcon.Error)
            txtUser.Focus()
        Else
            ' If all information Is correctly entered Then the customer will be brought
            'to their account page 
            BindingSource1.AddNew()
            Try
                BindingSource1.EndEdit()
                TblCustomerInfoTableAdapter.Update(Me.CustomerDataSet.tblCustomerInfo)
                MessageBox.Show("Account Successfully Created!", "Shoes Ltd.",
                    MessageBoxButtons.OK)
                Me.Close()
                frmAccount.Show()
            Catch ex As Exception
                MessageBox.Show("Error Creating Account", "Shoes Ltd.",
                MessageBoxButtons.OK,
                MessageBoxIcon.Error)
            End Try
        End If

    End Sub

    Private Sub btnReset_Click(sender As Object, e As EventArgs) Handles btnReset.Click
        'clears the form
        Dim DialogResult As DialogResult
        DialogResult = MessageBox.Show("Clear the form?", "Shoes Ltd.",
                                       MessageBoxButtons.YesNo,
                                       MessageBoxIcon.Question,
                                       MessageBoxDefaultButton.Button2)
        If DialogResult = DialogResult.Yes Then
            txtName.Clear()
            mskDOB.Clear()
            txtAddress.Clear()
            txtSurname.Clear()
            mskContact.Clear()
            txtEmail.Clear()
            txtUser.Clear()
            txtName.Focus()
        End If
    End Sub

    Private Sub radExisting_CheckedChanged(sender As Object, e As EventArgs) Handles radExisting.CheckedChanged
        'showing the appropriate group box to the customer
        If radNew.Checked Then
            grbExisting.Visible = False
            grbNew.Visible = True
        Else
            grbExisting.Visible = True
            grbNew.Visible = False
        End If
    End Sub

    Private Sub radNew_CheckedChanged(sender As Object, e As EventArgs) Handles radNew.CheckedChanged
        'showing the appropriate group box to the customer
        If radNew.Checked Then
            grbExisting.Visible = False
            grbNew.Visible = True
        Else
            grbExisting.Visible = True
            grbNew.Visible = False
        End If
    End Sub

    Private Sub txtPassword_TextChanged(sender As Object, e As EventArgs) Handles txtPassword.TextChanged
        'using the password symbol to hide password
        txtPassword.UseSystemPasswordChar = True
    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        'clears the form
        Dim DialogResult As DialogResult
        DialogResult = MessageBox.Show("Clear the form?", "Shoes Ltd.",
                                       MessageBoxButtons.YesNo,
                                       MessageBoxIcon.Question,
                                       MessageBoxDefaultButton.Button2)
        If DialogResult = DialogResult.Yes Then
            txtUsername.Clear()
            txtPassword.Clear()
            txtUsername.Focus()
        End If
    End Sub

    Private Sub btnLogin_Click(sender As Object, e As EventArgs) Handles btnLogin.Click
        'Setting the values in txtUsername and txtPassword equal to strUsername and strPassword.
        strUsername = txtUsername.Text
        strPassword = txtPassword.Text

        'Using an if statement to test if strUsername is equal to strPassword.
        If strUsername = strPassword Then
            'If they are equal then execute the sub procedure correct()
            Call correct()
            'If they are not equal nd intCount is greater than -1 then display a message box.
        Else
            MsgBox("Incorrect password/username. You have " & intCount & " attempt(s) left.")
            'Decreasing the value of intCount by -1 if they are not equal.
            intCount -= 1
            txtUsername.Clear()
            txtPassword.Clear()
            txtUsername.Focus()
        End If

        'Using an if statement to check if intCount is equal to -1
        If intCount = -1 Then
            'If intCount is equal to -1 then the program closes and a message box is displayed.
            Me.Close()
            MsgBox("Too many failed attempts :/")
        End If

    End Sub

    Private Sub AboutToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AboutToolStripMenuItem.Click
        'opening frmABoutUs
        frmAboutUs.Show()

    End Sub

    Private Sub HelpToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles HelpToolStripMenuItem.Click
        'opening frmUserManual and closing the current form.
        frmUserManual.Show()
        Me.Hide()
    End Sub

    Private Sub HomeToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles HomeToolStripMenuItem.Click
        'opening frmStartPage and clsoing the current form.
        frmStartPage.Show()
        Me.Hide()
    End Sub
End Class