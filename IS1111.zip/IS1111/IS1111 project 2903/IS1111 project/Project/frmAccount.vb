﻿Public Class frmAccount
    Private Sub btnNew_Click(sender As Object, e As EventArgs) Handles btnNew.Click
        'Brings customer to order form
        Me.Hide()
        frmOrder.Show()
    End Sub

    Private Sub btnLogout_Click(sender As Object, e As EventArgs) Handles btnLogout.Click
        'brings customer back to login page 
        Dim DialogResult As DialogResult
        DialogResult = MessageBox.Show("Are you sure you want to logout?", "Your Style",
                                       MessageBoxButtons.YesNo,
                                       MessageBoxIcon.Question,
                                       MessageBoxDefaultButton.Button2)
        'if yes is clicked in the messagebox then the form closes and frmCustomer opens
        If DialogResult = DialogResult.Yes Then
            Me.Hide()
            frmCustomer.Show()
        End If
    End Sub

    Private Sub btnTrack_Click(sender As Object, e As EventArgs) Handles btnTrack.Click
        'Opening frmTrack and closing the current form
        frmTrack.Show()
        Me.Hide()
    End Sub

    Private Sub HomeToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles HomeToolStripMenuItem.Click
        'Closing the current form and opening frmStartPage
        frmStartPage.Show()
        Me.Hide()
    End Sub

    Private Sub AboutToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AboutToolStripMenuItem.Click
        'opening frmAboutUs
        frmAboutUs.Show()
    End Sub

    Private Sub HelpToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles HelpToolStripMenuItem.Click
        'opening frmUserManual and closing the current form
        frmUserManual.Show()
        Me.Hide()
    End Sub


End Class