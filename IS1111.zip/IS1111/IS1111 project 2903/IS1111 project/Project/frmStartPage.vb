﻿Public Class frmStartPage
    'Contribution by each group member
    'Casey/119365941: Set up the access database, made a background and logo and put them in every form.
    'designed and programmed the staff side and user manual got all the forms working together and 
    'tidied up design And comments. Implemented menustrips And made sure all controls were labeled. Designed the login 
    'system for both staff and customer using an array, sub procedure and loop. Made a  splashscreen and about screen.
    'Added a timer. Made a query For staff To track a customers order. Used a nav tool to allow new staff members to be added. 
    'Niamh/119349781: Designed and programmed the customer side. Helped to ensure the logo, background and menustrip was in
    'each form. Made a github repository for code to be exchanged. Made a query for customers to track their order. Made. the
    'order form for customers to design their order and confirm payment details.
    'Oisin/119303443: Nothing.
    'Liam/119357686: Nothing.


    Private Sub StaffToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles StaffToolStripMenuItem.Click
        'Opening frmStaffLogin and closing the current form.
        frmStaffLogin.Show()
        Me.Hide()
    End Sub

    Private Sub CustomerToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles CustomerToolStripMenuItem.Click
        'Opening frmCustomer and closing the current form.
        frmCustomer.Show()
        Me.Hide()
    End Sub

    Private Sub AboutToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AboutToolStripMenuItem.Click
        'opening frmAboutUs
        frmAboutUs.Show()
    End Sub

End Class
