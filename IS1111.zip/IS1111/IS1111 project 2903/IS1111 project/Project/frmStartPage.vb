﻿Public Class frmStartPage


    Private Sub StaffToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles StaffToolStripMenuItem.Click
        'Opening frmStaffLogin and closing the current form.
        frmStaffLogin.Show()
        Me.Hide()
    End Sub

    Private Sub CustomerToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles CustomerToolStripMenuItem.Click
        'Opening frmCustoner and closing the current form.
        frmCustomer.Show()
        Me.Hide()
    End Sub


End Class
