﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmUserManual
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lblUser = New System.Windows.Forms.Label()
        Me.lblGeneral = New System.Windows.Forms.Label()
        Me.lblOne = New System.Windows.Forms.Label()
        Me.lblOneTwo = New System.Windows.Forms.Label()
        Me.lblOneThree = New System.Windows.Forms.Label()
        Me.lblTwo = New System.Windows.Forms.Label()
        Me.mstUserManual = New System.Windows.Forms.MenuStrip()
        Me.HomeToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AboutToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.HelpToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.LogoutToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.lblStaff = New System.Windows.Forms.Label()
        Me.lblStaffOne = New System.Windows.Forms.Label()
        Me.lblStaffTwo = New System.Windows.Forms.Label()
        Me.lblStaffThree = New System.Windows.Forms.Label()
        Me.pbxStaff = New System.Windows.Forms.PictureBox()
        Me.pbxCustomer = New System.Windows.Forms.PictureBox()
        Me.pbxBackbutton = New System.Windows.Forms.PictureBox()
        Me.pbxMenustrip = New System.Windows.Forms.PictureBox()
        Me.pbxLogo = New System.Windows.Forms.PictureBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.lblCustomer = New System.Windows.Forms.Label()
        Me.lblCustomerOne = New System.Windows.Forms.Label()
        Me.lblCustomerTwo = New System.Windows.Forms.Label()
        Me.lblCustomerThree = New System.Windows.Forms.Label()
        Me.lblPrint = New System.Windows.Forms.Label()
        Me.lblPrintTwo = New System.Windows.Forms.Label()
        Me.mstUserManual.SuspendLayout()
        CType(Me.pbxStaff, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbxCustomer, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbxBackbutton, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbxMenustrip, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbxLogo, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'lblUser
        '
        Me.lblUser.AutoSize = True
        Me.lblUser.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblUser.Location = New System.Drawing.Point(54, 48)
        Me.lblUser.Name = "lblUser"
        Me.lblUser.Size = New System.Drawing.Size(159, 29)
        Me.lblUser.TabIndex = 1
        Me.lblUser.Text = "User Manual"
        '
        'lblGeneral
        '
        Me.lblGeneral.AutoSize = True
        Me.lblGeneral.BackColor = System.Drawing.Color.White
        Me.lblGeneral.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblGeneral.ForeColor = System.Drawing.Color.Red
        Me.lblGeneral.Location = New System.Drawing.Point(56, 110)
        Me.lblGeneral.Name = "lblGeneral"
        Me.lblGeneral.Size = New System.Drawing.Size(67, 18)
        Me.lblGeneral.TabIndex = 2
        Me.lblGeneral.Text = "General"
        '
        'lblOne
        '
        Me.lblOne.AutoSize = True
        Me.lblOne.Location = New System.Drawing.Point(29, 159)
        Me.lblOne.Name = "lblOne"
        Me.lblOne.Size = New System.Drawing.Size(444, 13)
        Me.lblOne.TabIndex = 3
        Me.lblOne.Text = "1. Every form has a menustrip as shown. Home brings you to the start page. About " &
    "brings you"
        '
        'lblOneTwo
        '
        Me.lblOneTwo.AutoSize = True
        Me.lblOneTwo.Location = New System.Drawing.Point(43, 172)
        Me.lblOneTwo.Name = "lblOneTwo"
        Me.lblOneTwo.Size = New System.Drawing.Size(430, 13)
        Me.lblOneTwo.TabIndex = 5
        Me.lblOneTwo.Text = " to the form with info about our company. Help brings you to the user manual form" &
    ". Logout "
        '
        'lblOneThree
        '
        Me.lblOneThree.AutoSize = True
        Me.lblOneThree.Location = New System.Drawing.Point(43, 187)
        Me.lblOneThree.Name = "lblOneThree"
        Me.lblOneThree.Size = New System.Drawing.Size(411, 13)
        Me.lblOneThree.TabIndex = 6
        Me.lblOneThree.Text = "gives you the option to logout of your account and return to the respective login" &
    " page."
        '
        'lblTwo
        '
        Me.lblTwo.AutoSize = True
        Me.lblTwo.Location = New System.Drawing.Point(29, 219)
        Me.lblTwo.Name = "lblTwo"
        Me.lblTwo.Size = New System.Drawing.Size(437, 13)
        Me.lblTwo.TabIndex = 7
        Me.lblTwo.Text = "2. Each form has a button called ""Back"", it will bring you to the previous form w" &
    "hen clicked."
        '
        'mstUserManual
        '
        Me.mstUserManual.BackColor = System.Drawing.Color.Transparent
        Me.mstUserManual.Font = New System.Drawing.Font("Segoe UI", 12.0!)
        Me.mstUserManual.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.HomeToolStripMenuItem, Me.AboutToolStripMenuItem, Me.HelpToolStripMenuItem, Me.LogoutToolStripMenuItem})
        Me.mstUserManual.Location = New System.Drawing.Point(0, 0)
        Me.mstUserManual.Name = "mstUserManual"
        Me.mstUserManual.Size = New System.Drawing.Size(800, 29)
        Me.mstUserManual.TabIndex = 8
        Me.mstUserManual.Text = "MenuStrip1"
        '
        'HomeToolStripMenuItem
        '
        Me.HomeToolStripMenuItem.Name = "HomeToolStripMenuItem"
        Me.HomeToolStripMenuItem.Size = New System.Drawing.Size(64, 25)
        Me.HomeToolStripMenuItem.Text = "&Home"
        '
        'AboutToolStripMenuItem
        '
        Me.AboutToolStripMenuItem.Name = "AboutToolStripMenuItem"
        Me.AboutToolStripMenuItem.Size = New System.Drawing.Size(64, 25)
        Me.AboutToolStripMenuItem.Text = "&About"
        '
        'HelpToolStripMenuItem
        '
        Me.HelpToolStripMenuItem.Name = "HelpToolStripMenuItem"
        Me.HelpToolStripMenuItem.Size = New System.Drawing.Size(54, 25)
        Me.HelpToolStripMenuItem.Text = "H&elp"
        '
        'LogoutToolStripMenuItem
        '
        Me.LogoutToolStripMenuItem.Name = "LogoutToolStripMenuItem"
        Me.LogoutToolStripMenuItem.Size = New System.Drawing.Size(71, 25)
        Me.LogoutToolStripMenuItem.Text = "&Logout"
        '
        'lblStaff
        '
        Me.lblStaff.AutoSize = True
        Me.lblStaff.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblStaff.ForeColor = System.Drawing.Color.Red
        Me.lblStaff.Location = New System.Drawing.Point(55, 265)
        Me.lblStaff.Name = "lblStaff"
        Me.lblStaff.Size = New System.Drawing.Size(43, 18)
        Me.lblStaff.TabIndex = 11
        Me.lblStaff.Text = "Staff"
        '
        'lblStaffOne
        '
        Me.lblStaffOne.AutoSize = True
        Me.lblStaffOne.Location = New System.Drawing.Point(32, 297)
        Me.lblStaffOne.Name = "lblStaffOne"
        Me.lblStaffOne.Size = New System.Drawing.Size(438, 13)
        Me.lblStaffOne.TabIndex = 12
        Me.lblStaffOne.Text = "When logged, staff have the ability to run a report and queries. If login is succ" &
    "essful staff will"
        '
        'lblStaffTwo
        '
        Me.lblStaffTwo.AutoSize = True
        Me.lblStaffTwo.Location = New System.Drawing.Point(32, 314)
        Me.lblStaffTwo.Name = "lblStaffTwo"
        Me.lblStaffTwo.Size = New System.Drawing.Size(442, 13)
        Me.lblStaffTwo.TabIndex = 13
        Me.lblStaffTwo.Text = "or query be brought to the options form, as shown. They can then continue to eith" &
    "er report or"
        '
        'lblStaffThree
        '
        Me.lblStaffThree.AutoSize = True
        Me.lblStaffThree.Location = New System.Drawing.Point(32, 331)
        Me.lblStaffThree.Name = "lblStaffThree"
        Me.lblStaffThree.Size = New System.Drawing.Size(375, 13)
        Me.lblStaffThree.TabIndex = 14
        Me.lblStaffThree.Text = "query forms. To run a query they must enter an order id to see the order status."
        '
        'pbxStaff
        '
        Me.pbxStaff.BackgroundImage = Global.Project.My.Resources.Resources.options
        Me.pbxStaff.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.pbxStaff.Location = New System.Drawing.Point(500, 297)
        Me.pbxStaff.Name = "pbxStaff"
        Me.pbxStaff.Size = New System.Drawing.Size(100, 106)
        Me.pbxStaff.TabIndex = 16
        Me.pbxStaff.TabStop = False
        '
        'pbxCustomer
        '
        Me.pbxCustomer.BackgroundImage = Global.Project.My.Resources.Resources.customer
        Me.pbxCustomer.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.pbxCustomer.Location = New System.Drawing.Point(500, 435)
        Me.pbxCustomer.Name = "pbxCustomer"
        Me.pbxCustomer.Size = New System.Drawing.Size(100, 160)
        Me.pbxCustomer.TabIndex = 15
        Me.pbxCustomer.TabStop = False
        '
        'pbxBackbutton
        '
        Me.pbxBackbutton.BackgroundImage = Global.Project.My.Resources.Resources.backbutton
        Me.pbxBackbutton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.pbxBackbutton.Location = New System.Drawing.Point(500, 219)
        Me.pbxBackbutton.Name = "pbxBackbutton"
        Me.pbxBackbutton.Size = New System.Drawing.Size(93, 39)
        Me.pbxBackbutton.TabIndex = 10
        Me.pbxBackbutton.TabStop = False
        '
        'pbxMenustrip
        '
        Me.pbxMenustrip.BackgroundImage = Global.Project.My.Resources.Resources.StaffManual1
        Me.pbxMenustrip.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.pbxMenustrip.Location = New System.Drawing.Point(500, 159)
        Me.pbxMenustrip.Name = "pbxMenustrip"
        Me.pbxMenustrip.Size = New System.Drawing.Size(211, 41)
        Me.pbxMenustrip.TabIndex = 4
        Me.pbxMenustrip.TabStop = False
        '
        'pbxLogo
        '
        Me.pbxLogo.BackgroundImage = Global.Project.My.Resources.Resources.logo1
        Me.pbxLogo.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.pbxLogo.Location = New System.Drawing.Point(614, 12)
        Me.pbxLogo.Name = "pbxLogo"
        Me.pbxLogo.Size = New System.Drawing.Size(141, 116)
        Me.pbxLogo.TabIndex = 0
        Me.pbxLogo.TabStop = False
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(0, 0)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(39, 13)
        Me.Label6.TabIndex = 17
        Me.Label6.Text = "Label6"
        '
        'lblCustomer
        '
        Me.lblCustomer.AutoSize = True
        Me.lblCustomer.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCustomer.ForeColor = System.Drawing.Color.Red
        Me.lblCustomer.Location = New System.Drawing.Point(55, 425)
        Me.lblCustomer.Name = "lblCustomer"
        Me.lblCustomer.Size = New System.Drawing.Size(82, 18)
        Me.lblCustomer.TabIndex = 18
        Me.lblCustomer.Text = "Customer"
        '
        'lblCustomerOne
        '
        Me.lblCustomerOne.AutoSize = True
        Me.lblCustomerOne.Location = New System.Drawing.Point(32, 464)
        Me.lblCustomerOne.Name = "lblCustomerOne"
        Me.lblCustomerOne.Size = New System.Drawing.Size(421, 13)
        Me.lblCustomerOne.TabIndex = 19
        Me.lblCustomerOne.Text = "Customers can track orders or make new orders. To track an order they must enter " &
    "their "
        '
        'lblCustomerTwo
        '
        Me.lblCustomerTwo.AutoSize = True
        Me.lblCustomerTwo.Location = New System.Drawing.Point(32, 481)
        Me.lblCustomerTwo.Name = "lblCustomerTwo"
        Me.lblCustomerTwo.Size = New System.Drawing.Size(419, 13)
        Me.lblCustomerTwo.TabIndex = 20
        Me.lblCustomerTwo.Text = "Order ID. After placing a new order they must provide payment details and they th" &
    "en get"
        '
        'lblCustomerThree
        '
        Me.lblCustomerThree.AutoSize = True
        Me.lblCustomerThree.Location = New System.Drawing.Point(32, 498)
        Me.lblCustomerThree.Name = "lblCustomerThree"
        Me.lblCustomerThree.Size = New System.Drawing.Size(195, 13)
        Me.lblCustomerThree.TabIndex = 21
        Me.lblCustomerThree.Text = "brought to an order confirmation screen."
        '
        'lblPrint
        '
        Me.lblPrint.AutoSize = True
        Me.lblPrint.Location = New System.Drawing.Point(32, 551)
        Me.lblPrint.Name = "lblPrint"
        Me.lblPrint.Size = New System.Drawing.Size(402, 13)
        Me.lblPrint.TabIndex = 22
        Me.lblPrint.Text = "*There is a print option for staff for reports and queries and for customers in t" &
    "he order"
        '
        'lblPrintTwo
        '
        Me.lblPrintTwo.AutoSize = True
        Me.lblPrintTwo.Location = New System.Drawing.Point(32, 568)
        Me.lblPrintTwo.Name = "lblPrintTwo"
        Me.lblPrintTwo.Size = New System.Drawing.Size(94, 13)
        Me.lblPrintTwo.TabIndex = 23
        Me.lblPrintTwo.Text = "confirmation page."
        '
        'frmUserManual
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(800, 607)
        Me.Controls.Add(Me.lblPrintTwo)
        Me.Controls.Add(Me.lblPrint)
        Me.Controls.Add(Me.lblCustomerThree)
        Me.Controls.Add(Me.lblCustomerTwo)
        Me.Controls.Add(Me.lblCustomerOne)
        Me.Controls.Add(Me.lblCustomer)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.pbxStaff)
        Me.Controls.Add(Me.pbxCustomer)
        Me.Controls.Add(Me.lblStaffThree)
        Me.Controls.Add(Me.lblStaffTwo)
        Me.Controls.Add(Me.lblStaffOne)
        Me.Controls.Add(Me.lblStaff)
        Me.Controls.Add(Me.pbxBackbutton)
        Me.Controls.Add(Me.lblTwo)
        Me.Controls.Add(Me.lblOneThree)
        Me.Controls.Add(Me.lblOneTwo)
        Me.Controls.Add(Me.pbxMenustrip)
        Me.Controls.Add(Me.lblOne)
        Me.Controls.Add(Me.lblGeneral)
        Me.Controls.Add(Me.lblUser)
        Me.Controls.Add(Me.pbxLogo)
        Me.Controls.Add(Me.mstUserManual)
        Me.MainMenuStrip = Me.mstUserManual
        Me.Name = "frmUserManual"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "frmUserManual"
        Me.mstUserManual.ResumeLayout(False)
        Me.mstUserManual.PerformLayout()
        CType(Me.pbxStaff, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbxCustomer, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbxBackbutton, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbxMenustrip, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbxLogo, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents pbxLogo As PictureBox
    Friend WithEvents lblUser As Label
    Friend WithEvents lblGeneral As Label
    Friend WithEvents lblOne As Label
    Friend WithEvents pbxMenustrip As PictureBox
    Friend WithEvents lblOneTwo As Label
    Friend WithEvents lblOneThree As Label
    Friend WithEvents lblTwo As Label
    Friend WithEvents mstUserManual As MenuStrip
    Friend WithEvents HomeToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents AboutToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents HelpToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents LogoutToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents pbxBackbutton As PictureBox
    Friend WithEvents lblStaff As Label
    Friend WithEvents lblStaffOne As Label
    Friend WithEvents lblStaffTwo As Label
    Friend WithEvents lblStaffThree As Label
    Friend WithEvents pbxCustomer As PictureBox
    Friend WithEvents pbxStaff As PictureBox
    Friend WithEvents Label6 As Label
    Friend WithEvents lblCustomer As Label
    Friend WithEvents lblCustomerOne As Label
    Friend WithEvents lblCustomerTwo As Label
    Friend WithEvents lblCustomerThree As Label
    Friend WithEvents lblPrint As Label
    Friend WithEvents lblPrintTwo As Label
End Class
