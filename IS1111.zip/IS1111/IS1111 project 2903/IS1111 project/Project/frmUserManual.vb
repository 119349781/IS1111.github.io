﻿Public Class frmUserManual
    Private Sub HomeToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles HomeToolStripMenuItem.Click
        'Opening frmStartPage and closing the current form.
        frmStartPage.Show()
        Me.Hide()
    End Sub

    Private Sub HelpToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles HelpToolStripMenuItem.Click
        'Refreshing the page.
        Me.Refresh()
    End Sub

    Private Sub LogoutToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles LogoutToolStripMenuItem.Click
        Dim DialogResult As DialogResult
        DialogResult = MessageBox.Show("Are you sure you want to logout.", "Your Style Ltd.",
                                   MessageBoxButtons.YesNo,
                                   MessageBoxIcon.Question,
                                   MessageBoxDefaultButton.Button2)
        If DialogResult = DialogResult.Yes Then
            Me.Close()
            frmStaffLogin.Show()
        End If
    End Sub

    Private Sub AboutToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AboutToolStripMenuItem.Click
        'opening frmAboutUs
        frmAboutUs.Show()
    End Sub


End Class