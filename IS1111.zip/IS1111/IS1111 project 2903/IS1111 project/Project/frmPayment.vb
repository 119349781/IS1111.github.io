﻿Public Class frmPayment
    Private Sub btnBack_Click(sender As Object, e As EventArgs) Handles btnBack.Click
        'brings customer back to order form
        Me.Close()
        frmOrder.Show()
    End Sub

    Private Sub frmReview_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'showing customer the total
        txtTotal.Text = FormatCurrency(decOverallTotal)
    End Sub

    Private Sub btnPay_Click(sender As Object, e As EventArgs) Handles btnPay.Click
        'validating form and paying for shoes
        Dim intMinNum As Integer = 19
        Dim intMinDate As Integer = 7
        Dim intMinCvv As Integer = 3
        Dim intMinPhone As Integer = 14
        If txtName.Text = "" Then
            MessageBox.Show("Please Enter the Cardholder name.", "ERROR",
                               MessageBoxButtons.OK,
                                MessageBoxIcon.Error)
            txtName.Focus()
        ElseIf IsNumeric(txtName.Text) Then
            MessageBox.Show("Numeric Values are not valid", "ERROR",
                               MessageBoxButtons.OK,
                                MessageBoxIcon.Error)
            txtName.Focus()
        ElseIf mskNumber.Text = "    -    -    -" Then
            MessageBox.Show("Please enter the card number", "ERROR",
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Error)
            mskNumber.Focus()
        ElseIf Len(mskNumber.Text) < intMinNum Then
            MessageBox.Show("Please Enter a 16 digit card number.", "ERROR",
                               MessageBoxButtons.OK,
                                MessageBoxIcon.Error)
            mskNumber.Focus()
        ElseIf mskExpiry.Text = "  /" Then
            MessageBox.Show("Please Enter the Card Expiry Date.", "ERROR",
                               MessageBoxButtons.OK,
                                MessageBoxIcon.Error)
            mskExpiry.Focus()
        ElseIf Len(mskExpiry.Text) < intMinDate Then
            MessageBox.Show("Please Enter the expiry date in the form MM/YYYY.", "ERROR",
                               MessageBoxButtons.OK,
                                MessageBoxIcon.Error)
            mskExpiry.Focus()
        ElseIf mskCvv.Text = "" Then
            MessageBox.Show("Please Enter the CVV.", "ERROR",
                               MessageBoxButtons.OK,
                                MessageBoxIcon.Error)
            mskCvv.Focus()
        ElseIf Len(mskCvv.Text) < intMinCvv Then
            MessageBox.Show("Please Enter a 3 digit CVV.", "ERROR",
                               MessageBoxButtons.OK,
                                MessageBoxIcon.Error)
            mskCvv.Focus()
        ElseIf txtCustomer.Text = "" Then
            MessageBox.Show("Please Enter your name", "Your Style Ltd.",
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Error)
            txtCustomer.Focus()
        ElseIf txtAddress.Text = "" Then
            MessageBox.Show("Please Enter your address", "Your Style Ltd.",
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Error)
            txtAddress.Focus()
        ElseIf mskPhone.Text = "(   )    -" Then
            MessageBox.Show("Please Enter your Phone Number", "Your Style Ltd.",
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Error)
            mskPhone.Focus()
        ElseIf Len(mskPhone.Text) < intMinPhone Then
            MessageBox.Show("Please Enter a 10 digit number", "Your Style Ltd.",
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Error)
            mskPhone.Focus()
        Else
            Me.Close()
            frmConfirmation.Show()
        End If
    End Sub

    Private Sub MensToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles MensToolStripMenuItem.Click
        'brings customer back to new order form
        Dim DialogResult As DialogResult
        DialogResult = MessageBox.Show("Are you sure you want to leave the page? Your order will be lost.", "Your Style Ltd.",
                                       MessageBoxButtons.YesNo,
                                       MessageBoxIcon.Question,
                                       MessageBoxDefaultButton.Button2)
        If DialogResult = DialogResult.Yes Then
            Me.Close()
            frmOrder.Show()
        End If
    End Sub

    Private Sub WomensToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles WomensToolStripMenuItem.Click
        Dim DialogResult As DialogResult
        DialogResult = MessageBox.Show("Are you sure you want to leave the page? Your order will be lost.", "Your Style Ltd.",
                                   MessageBoxButtons.YesNo,
                                   MessageBoxIcon.Question,
                                   MessageBoxDefaultButton.Button2)
        If DialogResult = DialogResult.Yes Then
            Me.Close()
            frmOrder.Show()
        End If
    End Sub

    Private Sub LogoutToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles LogoutToolStripMenuItem.Click
        Dim DialogResult As DialogResult
        DialogResult = MessageBox.Show("Are you sure you want to logout.", "Your Style Ltd.",
                                   MessageBoxButtons.YesNo,
                                   MessageBoxIcon.Question,
                                   MessageBoxDefaultButton.Button2)
        If DialogResult = DialogResult.Yes Then
            Me.Close()
            frmCustomer.Show()
        End If
    End Sub
End Class