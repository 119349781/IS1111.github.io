﻿Public Class frmStaffLogin
    'Contribution by each group member
    'Casey/119365941: Set up the access database, made a background and logo and put them in every form.
    'designed and programmed the staff side and user manual got all the forms working together and 
    'tidied up design And comments. Implemented menustrips And made sure all controls were labeled. Designed the login 
    'system for both staff and customer using an array, sub procedure and loop. Made a  splashscreen and about screen.
    'Added a timer. Made a query For staff To track a customers order. Used a nav tool to allow new staff members to be added. 
    'Niamh/119349781: Designed and programmed the customer side. Helped to ensure the logo, background and menustrip was in
    'each form. Made a github repository for code to be exchanged. Made a query for customers to track their order. Made. the
    'order form for customers to design their order and confirm payment details.
    'Oisin/119303443: Nothing.
    'Liam/119357686: Nothing.

    'Declaring variables and their datatype. strCredentials is an array with 5 values inside.
    Dim strCredentials(4) As String
    Dim strUsername As String
    Dim strPassword As String
    'Declaring n as an Integer and setting the value of n as -1
    Dim n As Integer = -1
    'Declaring intCount as an integer and setting it equal to 3. Using it to limit the attempts at login
    Dim intCount As Integer = 3

    'Creating a sub procedure called correct()
    Public Sub correct()
        'Using a Do loop
        Do
            'Increasing the value of n by 1
            n += 1
            'Looping until strCredentials() >= strUsername Or until n = 4
        Loop Until (strCredentials(n) >= strUsername) Or (n = 4)

        'Using an if statement to check if strCredentials(n) = strUsername
        If strCredentials(n) = strUsername Then
            'If they are equal then frmOptions is opened and the current form is closed.
            frmOptions.Show()
            Me.Hide()
            'Clearing the textboxes and resetting n as -1
            txtUsername.Clear()
            txtPassword.Clear()
            n = -1
        End If
    End Sub

    Private Sub btnLogin_Click_1(sender As Object, e As EventArgs) Handles btnLogin.Click
        'if either textbox is empty a message box prompts the user to fill them and prevents moving on
        If txtPassword.Text = " " Or txtUsername.Text = " " Then
            MessageBox.Show("Please fill out all relevent fields")
        End If

        'Setting the values in txtUsername and txtPassword equal to strUsername and strPassword.
        strUsername = txtUsername.Text
        strPassword = txtPassword.Text

        'Using an if statement to test if strUsername is equal to strPassword.
        If strUsername = strPassword Then
            'If they are equal then execute the sub procedure correct()
            Call correct()
            'If they are not equal nd intCount is greater than -1 then display a message box.
        Else
            MsgBox("Incorrect password/username. You have " & intCount & " attempt(s) left.")
            'Decreasing the value of intCount by -1 if they are not equal.
            intCount -= 1
        End If

        'Using an if statement to check if intCount is equal to -1
        If intCount = -1 Then
            'If intCount is equal to -1 then the program closes and a message box is displayed.
            Me.Close()
            MsgBox("Too many failed attempts :/")
        End If

    End Sub

    Private Sub btnCreate_Click(sender As Object, e As EventArgs) Handles btnCreate.Click
        'Opens frmStaffCreate and closes the current form.
        frmStaffCreate.Show()
        Me.Hide()

    End Sub

    Private Sub btnBack_Click(sender As Object, e As EventArgs)
        'Closes the current form and opens frmStartPage.
        Me.Hide()
        frmStartPage.Show()
    End Sub

    Private Sub frmStaffLogin_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'Populating the array when the form loads.
        strCredentials = {"yoconnor", "cdoran", "nhorgan", "lkennedy", "olyons"}
    End Sub

    Private Sub HomeToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles HomeToolStripMenuItem.Click
        'Opening frmStartPage and Closing the current page.
        frmStartPage.Show()
        Me.Hide()
    End Sub

    Private Sub HelpToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles HelpToolStripMenuItem.Click
        'Opening frmAbout and closing the current form.
        frmUserManual.Show()
        Me.Hide()
    End Sub

    Private Sub AboutToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AboutToolStripMenuItem.Click
        'opening frmAboutUs
        frmAboutUs.Show()
    End Sub
End Class