﻿Public Class frmQuery
    Private Sub frmQuery_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'OrderStatusDataSet.tblOrders' table. You can move, or remove it, as needed.
        Me.TblOrdersTableAdapter.Fill(Me.OrderStatusDataSet.tblOrders)
        'TODO: This line of code loads data into the 'OrderStatusDataSet.tblOrders' table. You can move, or remove it, as needed.
        Me.TblOrdersTableAdapter.Fill(Me.OrderStatusDataSet.tblOrders)

    End Sub

    Private Sub btnRun_Click(sender As Object, e As EventArgs) Handles btnRun.Click
        Dim query = From order In OrderStatusDataSet.tblOrders
                    Where order.Username = txtStatus.Text
                    Select order.Name, order.Username, order.Status, order.Price

        If query.Count = 1 Then
            dgvOrderStatus.DataSource = query.ToList
            dgvOrderStatus.CurrentCell = Nothing
        Else MsgBox("Order not found")
        End If
    End Sub

    Private Sub HomeToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles HomeToolStripMenuItem.Click
        'opening frmStartPage and closing the current form
        frmStartPage.Show()
        Me.Hide()
    End Sub

    Private Sub AboutToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AboutToolStripMenuItem.Click
        'opening frmAboutUs
        frmAboutUs.Show()
    End Sub

    Private Sub HelpToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles HelpToolStripMenuItem.Click
        'opening frmUserManual and closing the current form
        frmUserManual.Show()
        Me.Hide()
    End Sub

    Private Sub LogoutToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles LogoutToolStripMenuItem.Click
        Dim DialogResult As DialogResult
        DialogResult = MessageBox.Show("Are you sure you want to logout.", "Your Style Ltd.",
                                   MessageBoxButtons.YesNo,
                                   MessageBoxIcon.Question,
                                   MessageBoxDefaultButton.Button2)
        If DialogResult = DialogResult.Yes Then
            Me.Close()
            frmStaffLogin.Show()
        End If
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnPrint.Click
        'opening frmMeme2 and closing the current form
        frmMeme2.Show()
        Me.Hide()
    End Sub
End Class