﻿Public Class frmQuery
    Private Sub frmQuery_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'OrderStatusDataSet.tblOrders' table. You can move, or remove it, as needed.
        Me.TblOrdersTableAdapter.Fill(Me.OrderStatusDataSet.tblOrders)

    End Sub

    Private Sub btnRun_Click(sender As Object, e As EventArgs) Handles btnRun.Click
        Dim query = From order In OrderStatusDataSet.tblOrders
                    Where order.Username = txtStatus.Text
                    Select order.Name, order.Username, order.Status, order.Price

        If query.Count = 1 Then
            dgvOrderStatus.DataSource = query.ToList
            dgvOrderStatus.CurrentCell = Nothing
        Else MsgBox("Order not found")
        End If
    End Sub

    Private Sub HomeToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles HomeToolStripMenuItem.Click
        frmStartPage.Show()
        Me.Hide()
    End Sub

    Private Sub AboutToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AboutToolStripMenuItem.Click
        frmUserManual.Show()
        Me.Hide()
    End Sub

    Private Sub HelpToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles HelpToolStripMenuItem.Click

    End Sub

    Private Sub ReportToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ReportToolStripMenuItem.Click
        frmOptions.Show()
        Me.Hide()
    End Sub
End Class