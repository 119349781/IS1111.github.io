﻿Public Class frmTrack
    Private Sub frmTrack_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'TrackOrderDataSet.tblOrders' table. You can move, or remove it, as needed.
        Me.TblOrdersTableAdapter.Fill(Me.TrackOrderDataSet.tblOrders)
        'TODO: This line of code loads data into the 'TrackOrderDataSet.tblOrders' table. You can move, or remove it, as needed.
        Me.TblOrdersTableAdapter.Fill(Me.TrackOrderDataSet.tblOrders)

    End Sub

    Private Sub LogoutToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles LogoutToolStripMenuItem.Click
        'brings customer back to login page 
        Dim DialogResult As DialogResult
        DialogResult = MessageBox.Show("Are you sure you want to logout?", "Shoes Ltd.",
                                       MessageBoxButtons.YesNo,
                                       MessageBoxIcon.Question,
                                       MessageBoxDefaultButton.Button2)
        If DialogResult = DialogResult.Yes Then
            Me.Close()
            frmCustomer.Show()
        End If
    End Sub




    Private Sub btnTrack_Click(sender As Object, e As EventArgs) Handles btnTrack.Click
        'shows the order status if it exists
        Dim query1 = From order In TrackOrderDataSet.tblOrders
                     Where order.OrderID = txtOrder.Text
                     Select order.OrderID, order.Name, order.Price, order.Status

        If query1.Count = 1 Then
            dgvOrder.DataSource = query1.ToList
            dgvOrder.CurrentCell = Nothing
        Else
            MessageBox.Show("Invalid order ID. Please try again", "Shoes Ltd.",
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Error)
            txtOrder.Text = ""
            txtOrder.Focus()
        End If
    End Sub

    Private Sub HelpToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles HelpToolStripMenuItem.Click
        'brings cuustomer to user manual form
        Me.Close()
        frmUserManual.Show()
    End Sub

    Private Sub AboutToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AboutToolStripMenuItem.Click
        'opening frmAboutUs
        frmAboutUs.Show()
    End Sub
End Class