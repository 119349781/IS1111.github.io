﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmOrder
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmOrder))
        Me.lblSelect = New System.Windows.Forms.Label()
        Me.cmbShoeType = New System.Windows.Forms.ComboBox()
        Me.picClassic = New System.Windows.Forms.PictureBox()
        Me.picRetro = New System.Windows.Forms.PictureBox()
        Me.picVintage = New System.Windows.Forms.PictureBox()
        Me.lblQuarter = New System.Windows.Forms.Label()
        Me.cmbQuarter = New System.Windows.Forms.ComboBox()
        Me.lblVamp = New System.Windows.Forms.Label()
        Me.cmbVamp = New System.Windows.Forms.ComboBox()
        Me.lblEyestay = New System.Windows.Forms.Label()
        Me.cmbEyestay = New System.Windows.Forms.ComboBox()
        Me.lblHeel = New System.Windows.Forms.Label()
        Me.cmbHeel = New System.Windows.Forms.ComboBox()
        Me.lblBackCounter = New System.Windows.Forms.Label()
        Me.cmbBack = New System.Windows.Forms.ComboBox()
        Me.lblLaces = New System.Windows.Forms.Label()
        Me.cmbLaces = New System.Windows.Forms.ComboBox()
        Me.lblText = New System.Windows.Forms.Label()
        Me.txtText = New System.Windows.Forms.TextBox()
        Me.lblLogo = New System.Windows.Forms.Label()
        Me.btnBrowse = New System.Windows.Forms.Button()
        Me.btnBack = New System.Windows.Forms.Button()
        Me.btnPayment = New System.Windows.Forms.Button()
        Me.picLogo = New System.Windows.Forms.PictureBox()
        Me.OFGSelectImage = New System.Windows.Forms.OpenFileDialog()
        Me.picWhite = New System.Windows.Forms.PictureBox()
        Me.picBlack = New System.Windows.Forms.PictureBox()
        Me.picGrey = New System.Windows.Forms.PictureBox()
        Me.picBrown = New System.Windows.Forms.PictureBox()
        Me.picGreen = New System.Windows.Forms.PictureBox()
        Me.picBlue = New System.Windows.Forms.PictureBox()
        Me.picPurple = New System.Windows.Forms.PictureBox()
        Me.picPink = New System.Windows.Forms.PictureBox()
        Me.picYellow = New System.Windows.Forms.PictureBox()
        Me.picOrange = New System.Windows.Forms.PictureBox()
        Me.picRed = New System.Windows.Forms.PictureBox()
        Me.lblSize = New System.Windows.Forms.Label()
        Me.lblQuantity = New System.Windows.Forms.Label()
        Me.nudQuantity = New System.Windows.Forms.NumericUpDown()
        Me.cmbSize = New System.Windows.Forms.ComboBox()
        Me.lblDiscount = New System.Windows.Forms.Label()
        Me.txtDiscount = New System.Windows.Forms.TextBox()
        Me.btnApply = New System.Windows.Forms.Button()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.ShopToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MensToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.WomensToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TrackOrderToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ContactUsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.LogoutToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        CType(Me.picClassic, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picRetro, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picVintage, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picLogo, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picWhite, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picBlack, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picGrey, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picBrown, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picGreen, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picBlue, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picPurple, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picPink, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picYellow, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picOrange, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picRed, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.nudQuantity, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'lblSelect
        '
        Me.lblSelect.AutoSize = True
        Me.lblSelect.Location = New System.Drawing.Point(15, 21)
        Me.lblSelect.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblSelect.Name = "lblSelect"
        Me.lblSelect.Size = New System.Drawing.Size(95, 13)
        Me.lblSelect.TabIndex = 0
        Me.lblSelect.Text = "Select Shoe Type:"
        '
        'cmbShoeType
        '
        Me.cmbShoeType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbShoeType.FormattingEnabled = True
        Me.cmbShoeType.Items.AddRange(New Object() {"Classic", "Retro", "Vintage"})
        Me.cmbShoeType.Location = New System.Drawing.Point(124, 15)
        Me.cmbShoeType.Margin = New System.Windows.Forms.Padding(2)
        Me.cmbShoeType.Name = "cmbShoeType"
        Me.cmbShoeType.Size = New System.Drawing.Size(89, 21)
        Me.cmbShoeType.TabIndex = 1
        '
        'picClassic
        '
        Me.picClassic.Image = CType(resources.GetObject("picClassic.Image"), System.Drawing.Image)
        Me.picClassic.Location = New System.Drawing.Point(277, 15)
        Me.picClassic.Margin = New System.Windows.Forms.Padding(2)
        Me.picClassic.Name = "picClassic"
        Me.picClassic.Size = New System.Drawing.Size(234, 164)
        Me.picClassic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picClassic.TabIndex = 2
        Me.picClassic.TabStop = False
        Me.picClassic.Visible = False
        '
        'picRetro
        '
        Me.picRetro.Image = CType(resources.GetObject("picRetro.Image"), System.Drawing.Image)
        Me.picRetro.Location = New System.Drawing.Point(277, 15)
        Me.picRetro.Margin = New System.Windows.Forms.Padding(2)
        Me.picRetro.Name = "picRetro"
        Me.picRetro.Size = New System.Drawing.Size(234, 164)
        Me.picRetro.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picRetro.TabIndex = 3
        Me.picRetro.TabStop = False
        Me.picRetro.Visible = False
        '
        'picVintage
        '
        Me.picVintage.Image = CType(resources.GetObject("picVintage.Image"), System.Drawing.Image)
        Me.picVintage.Location = New System.Drawing.Point(277, 15)
        Me.picVintage.Margin = New System.Windows.Forms.Padding(2)
        Me.picVintage.Name = "picVintage"
        Me.picVintage.Size = New System.Drawing.Size(234, 164)
        Me.picVintage.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picVintage.TabIndex = 4
        Me.picVintage.TabStop = False
        Me.picVintage.Visible = False
        '
        'lblQuarter
        '
        Me.lblQuarter.AutoSize = True
        Me.lblQuarter.Location = New System.Drawing.Point(15, 50)
        Me.lblQuarter.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblQuarter.Name = "lblQuarter"
        Me.lblQuarter.Size = New System.Drawing.Size(45, 13)
        Me.lblQuarter.TabIndex = 5
        Me.lblQuarter.Text = "Quarter:"
        '
        'cmbQuarter
        '
        Me.cmbQuarter.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbQuarter.FormattingEnabled = True
        Me.cmbQuarter.Items.AddRange(New Object() {"White", "Red", "Orange", "Yellow", "Pink", "Purple", "Blue", "Green", "Brown", "Black", "Grey"})
        Me.cmbQuarter.Location = New System.Drawing.Point(124, 45)
        Me.cmbQuarter.Margin = New System.Windows.Forms.Padding(2)
        Me.cmbQuarter.Name = "cmbQuarter"
        Me.cmbQuarter.Size = New System.Drawing.Size(89, 21)
        Me.cmbQuarter.TabIndex = 2
        '
        'lblVamp
        '
        Me.lblVamp.AutoSize = True
        Me.lblVamp.Location = New System.Drawing.Point(15, 116)
        Me.lblVamp.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblVamp.Name = "lblVamp"
        Me.lblVamp.Size = New System.Drawing.Size(37, 13)
        Me.lblVamp.TabIndex = 7
        Me.lblVamp.Text = "Vamp:"
        '
        'cmbVamp
        '
        Me.cmbVamp.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbVamp.FormattingEnabled = True
        Me.cmbVamp.Items.AddRange(New Object() {"White", "Red", "Orange", "Yellow", "Pink", "Purple", "Blue", "Green", "Brown", "Black", "Grey"})
        Me.cmbVamp.Location = New System.Drawing.Point(124, 110)
        Me.cmbVamp.Margin = New System.Windows.Forms.Padding(2)
        Me.cmbVamp.Name = "cmbVamp"
        Me.cmbVamp.Size = New System.Drawing.Size(89, 21)
        Me.cmbVamp.TabIndex = 3
        '
        'lblEyestay
        '
        Me.lblEyestay.AutoSize = True
        Me.lblEyestay.Location = New System.Drawing.Point(15, 179)
        Me.lblEyestay.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblEyestay.Name = "lblEyestay"
        Me.lblEyestay.Size = New System.Drawing.Size(47, 13)
        Me.lblEyestay.TabIndex = 9
        Me.lblEyestay.Text = "Eyestay:"
        '
        'cmbEyestay
        '
        Me.cmbEyestay.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbEyestay.FormattingEnabled = True
        Me.cmbEyestay.Items.AddRange(New Object() {"White", "Red", "Orange", "Yellow", "Pink", "Purple", "Blue", "Green", "Brown", "Black", "Grey"})
        Me.cmbEyestay.Location = New System.Drawing.Point(124, 174)
        Me.cmbEyestay.Margin = New System.Windows.Forms.Padding(2)
        Me.cmbEyestay.Name = "cmbEyestay"
        Me.cmbEyestay.Size = New System.Drawing.Size(89, 21)
        Me.cmbEyestay.TabIndex = 5
        '
        'lblHeel
        '
        Me.lblHeel.AutoSize = True
        Me.lblHeel.Location = New System.Drawing.Point(15, 250)
        Me.lblHeel.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblHeel.Name = "lblHeel"
        Me.lblHeel.Size = New System.Drawing.Size(54, 13)
        Me.lblHeel.TabIndex = 11
        Me.lblHeel.Text = "Heel Tab:"
        '
        'cmbHeel
        '
        Me.cmbHeel.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbHeel.FormattingEnabled = True
        Me.cmbHeel.Items.AddRange(New Object() {"White", "Red", "Orange", "Yellow", "Pink", "Purple", "Blue", "Green", "Brown", "Black", "Grey"})
        Me.cmbHeel.Location = New System.Drawing.Point(124, 244)
        Me.cmbHeel.Margin = New System.Windows.Forms.Padding(2)
        Me.cmbHeel.Name = "cmbHeel"
        Me.cmbHeel.Size = New System.Drawing.Size(89, 21)
        Me.cmbHeel.TabIndex = 7
        '
        'lblBackCounter
        '
        Me.lblBackCounter.AutoSize = True
        Me.lblBackCounter.Location = New System.Drawing.Point(15, 212)
        Me.lblBackCounter.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblBackCounter.Name = "lblBackCounter"
        Me.lblBackCounter.Size = New System.Drawing.Size(75, 13)
        Me.lblBackCounter.TabIndex = 13
        Me.lblBackCounter.Text = "Back Counter:"
        '
        'cmbBack
        '
        Me.cmbBack.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbBack.FormattingEnabled = True
        Me.cmbBack.Items.AddRange(New Object() {"White", "Red", "Orange", "Yellow", "Pink", "Purple", "Blue", "Green", "Brown", "Black", "Grey"})
        Me.cmbBack.Location = New System.Drawing.Point(124, 207)
        Me.cmbBack.Margin = New System.Windows.Forms.Padding(2)
        Me.cmbBack.Name = "cmbBack"
        Me.cmbBack.Size = New System.Drawing.Size(89, 21)
        Me.cmbBack.TabIndex = 6
        '
        'lblLaces
        '
        Me.lblLaces.AutoSize = True
        Me.lblLaces.Location = New System.Drawing.Point(15, 148)
        Me.lblLaces.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblLaces.Name = "lblLaces"
        Me.lblLaces.Size = New System.Drawing.Size(39, 13)
        Me.lblLaces.TabIndex = 15
        Me.lblLaces.Text = "Laces:"
        '
        'cmbLaces
        '
        Me.cmbLaces.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbLaces.FormattingEnabled = True
        Me.cmbLaces.Items.AddRange(New Object() {"White", "Red", "Orange", "Yellow", "Pink", "Purple", "Blue", "Green", "Brown", "Black", "Grey"})
        Me.cmbLaces.Location = New System.Drawing.Point(124, 142)
        Me.cmbLaces.Margin = New System.Windows.Forms.Padding(2)
        Me.cmbLaces.Name = "cmbLaces"
        Me.cmbLaces.Size = New System.Drawing.Size(89, 21)
        Me.cmbLaces.TabIndex = 4
        '
        'lblText
        '
        Me.lblText.AutoSize = True
        Me.lblText.Location = New System.Drawing.Point(15, 324)
        Me.lblText.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblText.Name = "lblText"
        Me.lblText.Size = New System.Drawing.Size(31, 13)
        Me.lblText.TabIndex = 17
        Me.lblText.Text = "Text:"
        '
        'txtText
        '
        Me.txtText.Location = New System.Drawing.Point(48, 322)
        Me.txtText.Margin = New System.Windows.Forms.Padding(2)
        Me.txtText.Name = "txtText"
        Me.txtText.Size = New System.Drawing.Size(165, 20)
        Me.txtText.TabIndex = 9
        '
        'lblLogo
        '
        Me.lblLogo.AutoSize = True
        Me.lblLogo.Location = New System.Drawing.Point(15, 285)
        Me.lblLogo.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblLogo.Name = "lblLogo"
        Me.lblLogo.Size = New System.Drawing.Size(68, 13)
        Me.lblLogo.TabIndex = 19
        Me.lblLogo.Text = "Logo/Image:"
        '
        'btnBrowse
        '
        Me.btnBrowse.Location = New System.Drawing.Point(124, 279)
        Me.btnBrowse.Margin = New System.Windows.Forms.Padding(2)
        Me.btnBrowse.Name = "btnBrowse"
        Me.btnBrowse.Size = New System.Drawing.Size(88, 23)
        Me.btnBrowse.TabIndex = 8
        Me.btnBrowse.Text = "Bro&wse"
        Me.btnBrowse.UseVisualStyleBackColor = True
        '
        'btnBack
        '
        Me.btnBack.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnBack.ForeColor = System.Drawing.Color.Red
        Me.btnBack.Location = New System.Drawing.Point(18, 416)
        Me.btnBack.Margin = New System.Windows.Forms.Padding(2)
        Me.btnBack.Name = "btnBack"
        Me.btnBack.Size = New System.Drawing.Size(131, 23)
        Me.btnBack.TabIndex = 10
        Me.btnBack.Text = "&Back"
        Me.btnBack.UseVisualStyleBackColor = True
        '
        'btnPayment
        '
        Me.btnPayment.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnPayment.Location = New System.Drawing.Point(425, 416)
        Me.btnPayment.Margin = New System.Windows.Forms.Padding(2)
        Me.btnPayment.Name = "btnPayment"
        Me.btnPayment.Size = New System.Drawing.Size(131, 23)
        Me.btnPayment.TabIndex = 11
        Me.btnPayment.Text = "&Proceed to Payment"
        Me.btnPayment.UseVisualStyleBackColor = True
        '
        'picLogo
        '
        Me.picLogo.Location = New System.Drawing.Point(277, 207)
        Me.picLogo.Margin = New System.Windows.Forms.Padding(2)
        Me.picLogo.Name = "picLogo"
        Me.picLogo.Size = New System.Drawing.Size(234, 131)
        Me.picLogo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picLogo.TabIndex = 24
        Me.picLogo.TabStop = False
        '
        'OFGSelectImage
        '
        Me.OFGSelectImage.FileName = "OFGSelectImage"
        Me.OFGSelectImage.Filter = "JPEG Files|*.JPG|GIF Files|*.GIF|Windows Bitmaps|*.BMP"
        '
        'picWhite
        '
        Me.picWhite.Image = CType(resources.GetObject("picWhite.Image"), System.Drawing.Image)
        Me.picWhite.Location = New System.Drawing.Point(18, 75)
        Me.picWhite.Margin = New System.Windows.Forms.Padding(2)
        Me.picWhite.Name = "picWhite"
        Me.picWhite.Size = New System.Drawing.Size(194, 26)
        Me.picWhite.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picWhite.TabIndex = 25
        Me.picWhite.TabStop = False
        Me.picWhite.Visible = False
        '
        'picBlack
        '
        Me.picBlack.Image = CType(resources.GetObject("picBlack.Image"), System.Drawing.Image)
        Me.picBlack.Location = New System.Drawing.Point(18, 75)
        Me.picBlack.Margin = New System.Windows.Forms.Padding(2)
        Me.picBlack.Name = "picBlack"
        Me.picBlack.Size = New System.Drawing.Size(194, 26)
        Me.picBlack.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picBlack.TabIndex = 26
        Me.picBlack.TabStop = False
        Me.picBlack.Visible = False
        '
        'picGrey
        '
        Me.picGrey.Image = CType(resources.GetObject("picGrey.Image"), System.Drawing.Image)
        Me.picGrey.Location = New System.Drawing.Point(18, 75)
        Me.picGrey.Margin = New System.Windows.Forms.Padding(2)
        Me.picGrey.Name = "picGrey"
        Me.picGrey.Size = New System.Drawing.Size(194, 26)
        Me.picGrey.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picGrey.TabIndex = 27
        Me.picGrey.TabStop = False
        Me.picGrey.Visible = False
        '
        'picBrown
        '
        Me.picBrown.Image = CType(resources.GetObject("picBrown.Image"), System.Drawing.Image)
        Me.picBrown.Location = New System.Drawing.Point(18, 75)
        Me.picBrown.Margin = New System.Windows.Forms.Padding(2)
        Me.picBrown.Name = "picBrown"
        Me.picBrown.Size = New System.Drawing.Size(194, 26)
        Me.picBrown.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picBrown.TabIndex = 28
        Me.picBrown.TabStop = False
        Me.picBrown.Visible = False
        '
        'picGreen
        '
        Me.picGreen.Image = CType(resources.GetObject("picGreen.Image"), System.Drawing.Image)
        Me.picGreen.Location = New System.Drawing.Point(18, 75)
        Me.picGreen.Margin = New System.Windows.Forms.Padding(2)
        Me.picGreen.Name = "picGreen"
        Me.picGreen.Size = New System.Drawing.Size(194, 26)
        Me.picGreen.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picGreen.TabIndex = 29
        Me.picGreen.TabStop = False
        Me.picGreen.Visible = False
        '
        'picBlue
        '
        Me.picBlue.Image = CType(resources.GetObject("picBlue.Image"), System.Drawing.Image)
        Me.picBlue.Location = New System.Drawing.Point(18, 75)
        Me.picBlue.Margin = New System.Windows.Forms.Padding(2)
        Me.picBlue.Name = "picBlue"
        Me.picBlue.Size = New System.Drawing.Size(194, 26)
        Me.picBlue.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picBlue.TabIndex = 30
        Me.picBlue.TabStop = False
        Me.picBlue.Visible = False
        '
        'picPurple
        '
        Me.picPurple.Image = CType(resources.GetObject("picPurple.Image"), System.Drawing.Image)
        Me.picPurple.Location = New System.Drawing.Point(18, 75)
        Me.picPurple.Margin = New System.Windows.Forms.Padding(2)
        Me.picPurple.Name = "picPurple"
        Me.picPurple.Size = New System.Drawing.Size(194, 26)
        Me.picPurple.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picPurple.TabIndex = 31
        Me.picPurple.TabStop = False
        Me.picPurple.Visible = False
        '
        'picPink
        '
        Me.picPink.Image = CType(resources.GetObject("picPink.Image"), System.Drawing.Image)
        Me.picPink.Location = New System.Drawing.Point(18, 75)
        Me.picPink.Margin = New System.Windows.Forms.Padding(2)
        Me.picPink.Name = "picPink"
        Me.picPink.Size = New System.Drawing.Size(194, 26)
        Me.picPink.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picPink.TabIndex = 32
        Me.picPink.TabStop = False
        Me.picPink.Visible = False
        '
        'picYellow
        '
        Me.picYellow.Image = CType(resources.GetObject("picYellow.Image"), System.Drawing.Image)
        Me.picYellow.Location = New System.Drawing.Point(18, 75)
        Me.picYellow.Margin = New System.Windows.Forms.Padding(2)
        Me.picYellow.Name = "picYellow"
        Me.picYellow.Size = New System.Drawing.Size(194, 26)
        Me.picYellow.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picYellow.TabIndex = 33
        Me.picYellow.TabStop = False
        Me.picYellow.Visible = False
        '
        'picOrange
        '
        Me.picOrange.Image = CType(resources.GetObject("picOrange.Image"), System.Drawing.Image)
        Me.picOrange.Location = New System.Drawing.Point(18, 75)
        Me.picOrange.Margin = New System.Windows.Forms.Padding(2)
        Me.picOrange.Name = "picOrange"
        Me.picOrange.Size = New System.Drawing.Size(194, 26)
        Me.picOrange.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picOrange.TabIndex = 34
        Me.picOrange.TabStop = False
        Me.picOrange.Visible = False
        '
        'picRed
        '
        Me.picRed.Image = CType(resources.GetObject("picRed.Image"), System.Drawing.Image)
        Me.picRed.Location = New System.Drawing.Point(18, 75)
        Me.picRed.Margin = New System.Windows.Forms.Padding(2)
        Me.picRed.Name = "picRed"
        Me.picRed.Size = New System.Drawing.Size(194, 26)
        Me.picRed.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picRed.TabIndex = 35
        Me.picRed.TabStop = False
        Me.picRed.Visible = False
        '
        'lblSize
        '
        Me.lblSize.AutoSize = True
        Me.lblSize.Location = New System.Drawing.Point(22, 365)
        Me.lblSize.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblSize.Name = "lblSize"
        Me.lblSize.Size = New System.Drawing.Size(30, 13)
        Me.lblSize.TabIndex = 45
        Me.lblSize.Text = "Size:"
        '
        'lblQuantity
        '
        Me.lblQuantity.AutoSize = True
        Me.lblQuantity.Location = New System.Drawing.Point(22, 397)
        Me.lblQuantity.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblQuantity.Name = "lblQuantity"
        Me.lblQuantity.Size = New System.Drawing.Size(49, 13)
        Me.lblQuantity.TabIndex = 44
        Me.lblQuantity.Text = "Quantity:"
        '
        'nudQuantity
        '
        Me.nudQuantity.Location = New System.Drawing.Point(118, 396)
        Me.nudQuantity.Margin = New System.Windows.Forms.Padding(2)
        Me.nudQuantity.Name = "nudQuantity"
        Me.nudQuantity.Size = New System.Drawing.Size(34, 20)
        Me.nudQuantity.TabIndex = 43
        '
        'cmbSize
        '
        Me.cmbSize.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbSize.FormattingEnabled = True
        Me.cmbSize.Items.AddRange(New Object() {"UK Size 3", "UK Size 4", "UK Size 5", "UK Size 6", "UK Size 7", "UK Size 8", "UK Size 9", "UK Size 10", "UK Size 11", "UK Size 12", "UK Size 13", "UK Size 14"})
        Me.cmbSize.Location = New System.Drawing.Point(118, 360)
        Me.cmbSize.Margin = New System.Windows.Forms.Padding(2)
        Me.cmbSize.Name = "cmbSize"
        Me.cmbSize.Size = New System.Drawing.Size(89, 21)
        Me.cmbSize.TabIndex = 42
        '
        'lblDiscount
        '
        Me.lblDiscount.AutoSize = True
        Me.lblDiscount.Location = New System.Drawing.Point(293, 392)
        Me.lblDiscount.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblDiscount.Name = "lblDiscount"
        Me.lblDiscount.Size = New System.Drawing.Size(80, 13)
        Me.lblDiscount.TabIndex = 49
        Me.lblDiscount.Text = "Discount Code:"
        '
        'txtDiscount
        '
        Me.txtDiscount.Location = New System.Drawing.Point(375, 390)
        Me.txtDiscount.Margin = New System.Windows.Forms.Padding(2)
        Me.txtDiscount.Name = "txtDiscount"
        Me.txtDiscount.Size = New System.Drawing.Size(88, 20)
        Me.txtDiscount.TabIndex = 48
        '
        'btnApply
        '
        Me.btnApply.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnApply.Location = New System.Drawing.Point(466, 387)
        Me.btnApply.Margin = New System.Windows.Forms.Padding(2)
        Me.btnApply.Name = "btnApply"
        Me.btnApply.Size = New System.Drawing.Size(63, 23)
        Me.btnApply.TabIndex = 47
        Me.btnApply.Text = "&Apply"
        Me.btnApply.UseVisualStyleBackColor = True
        '
        'btnClear
        '
        Me.btnClear.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnClear.Location = New System.Drawing.Point(459, 350)
        Me.btnClear.Margin = New System.Windows.Forms.Padding(2)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(70, 21)
        Me.btnClear.TabIndex = 46
        Me.btnClear.Text = "&Clear Image"
        Me.btnClear.UseVisualStyleBackColor = True
        Me.btnClear.Visible = False
        '
        'MenuStrip1
        '
        Me.MenuStrip1.ImageScalingSize = New System.Drawing.Size(24, 24)
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ShopToolStripMenuItem, Me.TrackOrderToolStripMenuItem, Me.ContactUsToolStripMenuItem, Me.LogoutToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Padding = New System.Windows.Forms.Padding(4, 1, 0, 1)
        Me.MenuStrip1.Size = New System.Drawing.Size(800, 24)
        Me.MenuStrip1.TabIndex = 50
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'ShopToolStripMenuItem
        '
        Me.ShopToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.MensToolStripMenuItem, Me.WomensToolStripMenuItem})
        Me.ShopToolStripMenuItem.Name = "ShopToolStripMenuItem"
        Me.ShopToolStripMenuItem.Size = New System.Drawing.Size(46, 22)
        Me.ShopToolStripMenuItem.Text = "Shop"
        '
        'MensToolStripMenuItem
        '
        Me.MensToolStripMenuItem.Name = "MensToolStripMenuItem"
        Me.MensToolStripMenuItem.Size = New System.Drawing.Size(121, 22)
        Me.MensToolStripMenuItem.Text = "Mens"
        '
        'WomensToolStripMenuItem
        '
        Me.WomensToolStripMenuItem.Name = "WomensToolStripMenuItem"
        Me.WomensToolStripMenuItem.Size = New System.Drawing.Size(121, 22)
        Me.WomensToolStripMenuItem.Text = "Womens"
        '
        'TrackOrderToolStripMenuItem
        '
        Me.TrackOrderToolStripMenuItem.Name = "TrackOrderToolStripMenuItem"
        Me.TrackOrderToolStripMenuItem.Size = New System.Drawing.Size(79, 22)
        Me.TrackOrderToolStripMenuItem.Text = "Track Order"
        '
        'ContactUsToolStripMenuItem
        '
        Me.ContactUsToolStripMenuItem.Name = "ContactUsToolStripMenuItem"
        Me.ContactUsToolStripMenuItem.Size = New System.Drawing.Size(77, 22)
        Me.ContactUsToolStripMenuItem.Text = "Contact Us"
        '
        'LogoutToolStripMenuItem
        '
        Me.LogoutToolStripMenuItem.Name = "LogoutToolStripMenuItem"
        Me.LogoutToolStripMenuItem.Size = New System.Drawing.Size(57, 22)
        Me.LogoutToolStripMenuItem.Text = "Logout"
        '
        'frmOrder
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.MenuStrip1)
        Me.Controls.Add(Me.lblDiscount)
        Me.Controls.Add(Me.txtDiscount)
        Me.Controls.Add(Me.btnApply)
        Me.Controls.Add(Me.btnClear)
        Me.Controls.Add(Me.lblSize)
        Me.Controls.Add(Me.lblQuantity)
        Me.Controls.Add(Me.nudQuantity)
        Me.Controls.Add(Me.cmbSize)
        Me.Controls.Add(Me.picRed)
        Me.Controls.Add(Me.picOrange)
        Me.Controls.Add(Me.picYellow)
        Me.Controls.Add(Me.picPink)
        Me.Controls.Add(Me.picPurple)
        Me.Controls.Add(Me.picBlue)
        Me.Controls.Add(Me.picGreen)
        Me.Controls.Add(Me.picBrown)
        Me.Controls.Add(Me.picGrey)
        Me.Controls.Add(Me.picBlack)
        Me.Controls.Add(Me.picWhite)
        Me.Controls.Add(Me.picLogo)
        Me.Controls.Add(Me.btnPayment)
        Me.Controls.Add(Me.btnBack)
        Me.Controls.Add(Me.btnBrowse)
        Me.Controls.Add(Me.lblLogo)
        Me.Controls.Add(Me.txtText)
        Me.Controls.Add(Me.lblText)
        Me.Controls.Add(Me.cmbLaces)
        Me.Controls.Add(Me.lblLaces)
        Me.Controls.Add(Me.cmbBack)
        Me.Controls.Add(Me.lblBackCounter)
        Me.Controls.Add(Me.cmbHeel)
        Me.Controls.Add(Me.lblHeel)
        Me.Controls.Add(Me.cmbEyestay)
        Me.Controls.Add(Me.lblEyestay)
        Me.Controls.Add(Me.cmbVamp)
        Me.Controls.Add(Me.lblVamp)
        Me.Controls.Add(Me.cmbQuarter)
        Me.Controls.Add(Me.lblQuarter)
        Me.Controls.Add(Me.picVintage)
        Me.Controls.Add(Me.picRetro)
        Me.Controls.Add(Me.picClassic)
        Me.Controls.Add(Me.cmbShoeType)
        Me.Controls.Add(Me.lblSelect)
        Me.Margin = New System.Windows.Forms.Padding(2)
        Me.Name = "frmOrder"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Order"
        CType(Me.picClassic, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picRetro, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picVintage, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picLogo, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picWhite, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picBlack, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picGrey, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picBrown, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picGreen, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picBlue, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picPurple, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picPink, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picYellow, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picOrange, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picRed, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.nudQuantity, System.ComponentModel.ISupportInitialize).EndInit()
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblSelect As Label
    Friend WithEvents cmbShoeType As ComboBox
    Friend WithEvents picClassic As PictureBox
    Friend WithEvents picRetro As PictureBox
    Friend WithEvents picVintage As PictureBox
    Friend WithEvents lblQuarter As Label
    Friend WithEvents cmbQuarter As ComboBox
    Friend WithEvents lblVamp As Label
    Friend WithEvents cmbVamp As ComboBox
    Friend WithEvents lblEyestay As Label
    Friend WithEvents cmbEyestay As ComboBox
    Friend WithEvents lblHeel As Label
    Friend WithEvents cmbHeel As ComboBox
    Friend WithEvents lblBackCounter As Label
    Friend WithEvents cmbBack As ComboBox
    Friend WithEvents lblLaces As Label
    Friend WithEvents cmbLaces As ComboBox
    Friend WithEvents lblText As Label
    Friend WithEvents txtText As TextBox
    Friend WithEvents lblLogo As Label
    Friend WithEvents btnBrowse As Button
    Friend WithEvents btnBack As Button
    Friend WithEvents btnPayment As Button
    Friend WithEvents picLogo As PictureBox
    Friend WithEvents OFGSelectImage As OpenFileDialog
    Friend WithEvents picWhite As PictureBox
    Friend WithEvents picBlack As PictureBox
    Friend WithEvents picGrey As PictureBox
    Friend WithEvents picBrown As PictureBox
    Friend WithEvents picGreen As PictureBox
    Friend WithEvents picBlue As PictureBox
    Friend WithEvents picPurple As PictureBox
    Friend WithEvents picPink As PictureBox
    Friend WithEvents picYellow As PictureBox
    Friend WithEvents picOrange As PictureBox
    Friend WithEvents picRed As PictureBox
    Friend WithEvents lblSize As Label
    Friend WithEvents lblQuantity As Label
    Friend WithEvents nudQuantity As NumericUpDown
    Friend WithEvents cmbSize As ComboBox
    Friend WithEvents lblDiscount As Label
    Friend WithEvents txtDiscount As TextBox
    Friend WithEvents btnApply As Button
    Friend WithEvents btnClear As Button
    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents ShopToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents MensToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents WomensToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents TrackOrderToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ContactUsToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents LogoutToolStripMenuItem As ToolStripMenuItem
End Class
