﻿Public Class frmOptions


    Private Sub btnBack_Click(sender As Object, e As EventArgs) Handles btnBack.Click
        'Closing the current form and opening frmStaffLogin when btnBack is clicked
        Me.Hide()
        frmStaffLogin.Show()
    End Sub

    Private Sub btnReports_Click(sender As Object, e As EventArgs) Handles btnReports.Click
        'Closing the current form and opening frmReports when btnReports is clicked.
        frmReports.Show()
        Me.Hide()
    End Sub

    Private Sub btnQuery_Click(sender As Object, e As EventArgs) Handles btnQuery.Click
        'Closing the current form and opening frmQuery
        frmQuery.Show()
        Me.Hide()
    End Sub

    Private Sub HomeToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles HomeToolStripMenuItem.Click
        'openin frmStartPage and closing the current form
        frmStartPage.Show()
        Me.Hide()
    End Sub

    Private Sub AboutToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AboutToolStripMenuItem.Click
        'opening frmAboutUs
        frmAboutUs.Show()
    End Sub

    Private Sub HelpToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles HelpToolStripMenuItem.Click
        'Opening frmUserManual and closing the current form
        frmUserManual.Show()
        Me.Hide()
    End Sub

    Private Sub LogoutToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles LogoutToolStripMenuItem.Click
        Dim DialogResult As DialogResult
        DialogResult = MessageBox.Show("Are you sure you want to logout.", "Your Style Ltd.",
                                   MessageBoxButtons.YesNo,
                                   MessageBoxIcon.Question,
                                   MessageBoxDefaultButton.Button2)
        If DialogResult = DialogResult.Yes Then
            Me.Close()
            frmStaffLogin.Show()
        End If
    End Sub
End Class