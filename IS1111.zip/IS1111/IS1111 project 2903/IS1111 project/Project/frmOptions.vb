﻿Public Class frmOptions


    Private Sub btnBack_Click(sender As Object, e As EventArgs) Handles btnBack.Click
        'Closing the current form and opening frmStaffLogin when btnBack is clicked
        Me.Hide()
        frmStaffLogin.Show()
    End Sub

    Private Sub btnReports_Click(sender As Object, e As EventArgs) Handles btnReports.Click
        'Closing the current form and opening frmReports when btnReports is clicked.
        frmReports.Show()
        Me.Hide()
    End Sub

    Private Sub btnQuery_Click(sender As Object, e As EventArgs) Handles btnQuery.Click
        'Closing the current form and opening frmQuery
        frmQuery.Show()
        Me.Hide()
    End Sub
End Class