﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmCustomer
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.radExisting = New System.Windows.Forms.RadioButton()
        Me.radNew = New System.Windows.Forms.RadioButton()
        Me.grbExisting = New System.Windows.Forms.GroupBox()
        Me.btnLogin = New System.Windows.Forms.Button()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.lblPassword = New System.Windows.Forms.Label()
        Me.lblUsername = New System.Windows.Forms.Label()
        Me.txtPassword = New System.Windows.Forms.TextBox()
        Me.txtUsername = New System.Windows.Forms.TextBox()
        Me.grbNew = New System.Windows.Forms.GroupBox()
        Me.txtConfirm = New System.Windows.Forms.TextBox()
        Me.lblConfirm = New System.Windows.Forms.Label()
        Me.btnReset = New System.Windows.Forms.Button()
        Me.btnCreate = New System.Windows.Forms.Button()
        Me.txtPass = New System.Windows.Forms.TextBox()
        Me.txtUser = New System.Windows.Forms.TextBox()
        Me.lblPass = New System.Windows.Forms.Label()
        Me.lblUser = New System.Windows.Forms.Label()
        Me.txtCity = New System.Windows.Forms.TextBox()
        Me.lblCity = New System.Windows.Forms.Label()
        Me.lblEmail = New System.Windows.Forms.Label()
        Me.txtEmail = New System.Windows.Forms.TextBox()
        Me.lblPhone = New System.Windows.Forms.Label()
        Me.mskContact = New System.Windows.Forms.MaskedTextBox()
        Me.txtAddress = New System.Windows.Forms.TextBox()
        Me.lblAddress = New System.Windows.Forms.Label()
        Me.mskDOB = New System.Windows.Forms.MaskedTextBox()
        Me.lblDOB = New System.Windows.Forms.Label()
        Me.txtName = New System.Windows.Forms.TextBox()
        Me.lblName = New System.Windows.Forms.Label()
        Me.btnBack = New System.Windows.Forms.Button()
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.BindingSource1 = New System.Windows.Forms.BindingSource(Me.components)
        Me.CustomerDataSet = New Project.CustomerDataSet()
        Me.TblCustomerInfoTableAdapter = New Project.CustomerDataSetTableAdapters.tblCustomerInfoTableAdapter()
        Me.txtSurname = New System.Windows.Forms.TextBox()
        Me.grbExisting.SuspendLayout()
        Me.grbNew.SuspendLayout()
        CType(Me.BindingSource1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.CustomerDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'radExisting
        '
        Me.radExisting.AutoSize = True
        Me.radExisting.Location = New System.Drawing.Point(103, 29)
        Me.radExisting.Name = "radExisting"
        Me.radExisting.Size = New System.Drawing.Size(108, 17)
        Me.radExisting.TabIndex = 0
        Me.radExisting.TabStop = True
        Me.radExisting.Text = "Existing Customer"
        Me.radExisting.UseVisualStyleBackColor = True
        '
        'radNew
        '
        Me.radNew.AutoSize = True
        Me.radNew.Location = New System.Drawing.Point(372, 29)
        Me.radNew.Name = "radNew"
        Me.radNew.Size = New System.Drawing.Size(94, 17)
        Me.radNew.TabIndex = 1
        Me.radNew.TabStop = True
        Me.radNew.Text = "New Customer"
        Me.radNew.UseVisualStyleBackColor = True
        '
        'grbExisting
        '
        Me.grbExisting.Controls.Add(Me.btnLogin)
        Me.grbExisting.Controls.Add(Me.btnClear)
        Me.grbExisting.Controls.Add(Me.lblPassword)
        Me.grbExisting.Controls.Add(Me.lblUsername)
        Me.grbExisting.Controls.Add(Me.txtPassword)
        Me.grbExisting.Controls.Add(Me.txtUsername)
        Me.grbExisting.Location = New System.Drawing.Point(58, 51)
        Me.grbExisting.Name = "grbExisting"
        Me.grbExisting.Size = New System.Drawing.Size(248, 193)
        Me.grbExisting.TabIndex = 2
        Me.grbExisting.TabStop = False
        Me.grbExisting.Text = "Existing Customer"
        Me.grbExisting.Visible = False
        '
        'btnLogin
        '
        Me.btnLogin.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnLogin.ForeColor = System.Drawing.Color.Black
        Me.btnLogin.Location = New System.Drawing.Point(131, 146)
        Me.btnLogin.Name = "btnLogin"
        Me.btnLogin.Size = New System.Drawing.Size(75, 23)
        Me.btnLogin.TabIndex = 5
        Me.btnLogin.Text = "&Login"
        Me.btnLogin.UseVisualStyleBackColor = True
        '
        'btnClear
        '
        Me.btnClear.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnClear.ForeColor = System.Drawing.Color.Red
        Me.btnClear.Location = New System.Drawing.Point(23, 146)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(75, 23)
        Me.btnClear.TabIndex = 4
        Me.btnClear.Text = "&Clear"
        Me.btnClear.UseVisualStyleBackColor = True
        '
        'lblPassword
        '
        Me.lblPassword.AutoSize = True
        Me.lblPassword.Location = New System.Drawing.Point(20, 96)
        Me.lblPassword.Name = "lblPassword"
        Me.lblPassword.Size = New System.Drawing.Size(56, 13)
        Me.lblPassword.TabIndex = 3
        Me.lblPassword.Text = "Password:"
        '
        'lblUsername
        '
        Me.lblUsername.AutoSize = True
        Me.lblUsername.Location = New System.Drawing.Point(18, 41)
        Me.lblUsername.Name = "lblUsername"
        Me.lblUsername.Size = New System.Drawing.Size(58, 13)
        Me.lblUsername.TabIndex = 2
        Me.lblUsername.Text = "Username:"
        '
        'txtPassword
        '
        Me.txtPassword.Location = New System.Drawing.Point(106, 93)
        Me.txtPassword.Name = "txtPassword"
        Me.txtPassword.Size = New System.Drawing.Size(100, 20)
        Me.txtPassword.TabIndex = 1
        '
        'txtUsername
        '
        Me.txtUsername.Location = New System.Drawing.Point(106, 34)
        Me.txtUsername.Name = "txtUsername"
        Me.txtUsername.Size = New System.Drawing.Size(100, 20)
        Me.txtUsername.TabIndex = 0
        '
        'grbNew
        '
        Me.grbNew.Controls.Add(Me.txtSurname)
        Me.grbNew.Controls.Add(Me.txtConfirm)
        Me.grbNew.Controls.Add(Me.lblConfirm)
        Me.grbNew.Controls.Add(Me.btnReset)
        Me.grbNew.Controls.Add(Me.btnCreate)
        Me.grbNew.Controls.Add(Me.txtPass)
        Me.grbNew.Controls.Add(Me.txtUser)
        Me.grbNew.Controls.Add(Me.lblPass)
        Me.grbNew.Controls.Add(Me.lblUser)
        Me.grbNew.Controls.Add(Me.txtCity)
        Me.grbNew.Controls.Add(Me.lblCity)
        Me.grbNew.Controls.Add(Me.lblEmail)
        Me.grbNew.Controls.Add(Me.txtEmail)
        Me.grbNew.Controls.Add(Me.lblPhone)
        Me.grbNew.Controls.Add(Me.mskContact)
        Me.grbNew.Controls.Add(Me.txtAddress)
        Me.grbNew.Controls.Add(Me.lblAddress)
        Me.grbNew.Controls.Add(Me.mskDOB)
        Me.grbNew.Controls.Add(Me.lblDOB)
        Me.grbNew.Controls.Add(Me.txtName)
        Me.grbNew.Controls.Add(Me.lblName)
        Me.grbNew.Location = New System.Drawing.Point(372, 51)
        Me.grbNew.Name = "grbNew"
        Me.grbNew.Size = New System.Drawing.Size(356, 340)
        Me.grbNew.TabIndex = 3
        Me.grbNew.TabStop = False
        Me.grbNew.Text = "New Customer"
        Me.grbNew.Visible = False
        '
        'txtConfirm
        '
        Me.txtConfirm.Location = New System.Drawing.Point(111, 304)
        Me.txtConfirm.Margin = New System.Windows.Forms.Padding(2)
        Me.txtConfirm.Name = "txtConfirm"
        Me.txtConfirm.Size = New System.Drawing.Size(100, 20)
        Me.txtConfirm.TabIndex = 17
        '
        'lblConfirm
        '
        Me.lblConfirm.AutoSize = True
        Me.lblConfirm.Location = New System.Drawing.Point(6, 308)
        Me.lblConfirm.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblConfirm.Name = "lblConfirm"
        Me.lblConfirm.Size = New System.Drawing.Size(94, 13)
        Me.lblConfirm.TabIndex = 16
        Me.lblConfirm.Text = "Confirm Password:"
        '
        'btnReset
        '
        Me.btnReset.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnReset.ForeColor = System.Drawing.Color.Red
        Me.btnReset.Location = New System.Drawing.Point(241, 174)
        Me.btnReset.Name = "btnReset"
        Me.btnReset.Size = New System.Drawing.Size(75, 38)
        Me.btnReset.TabIndex = 10
        Me.btnReset.Text = "C&lear"
        Me.btnReset.UseVisualStyleBackColor = True
        '
        'btnCreate
        '
        Me.btnCreate.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCreate.Location = New System.Drawing.Point(241, 103)
        Me.btnCreate.Name = "btnCreate"
        Me.btnCreate.Size = New System.Drawing.Size(75, 39)
        Me.btnCreate.TabIndex = 9
        Me.btnCreate.Text = "Create &Account"
        Me.btnCreate.UseVisualStyleBackColor = True
        '
        'txtPass
        '
        Me.txtPass.Location = New System.Drawing.Point(111, 268)
        Me.txtPass.Name = "txtPass"
        Me.txtPass.Size = New System.Drawing.Size(100, 20)
        Me.txtPass.TabIndex = 15
        Me.ToolTip1.SetToolTip(Me.txtPass, "Password must be between 8-20 characters!")
        '
        'txtUser
        '
        Me.txtUser.Location = New System.Drawing.Point(111, 233)
        Me.txtUser.Name = "txtUser"
        Me.txtUser.Size = New System.Drawing.Size(100, 20)
        Me.txtUser.TabIndex = 8
        '
        'lblPass
        '
        Me.lblPass.AutoSize = True
        Me.lblPass.Location = New System.Drawing.Point(5, 272)
        Me.lblPass.Name = "lblPass"
        Me.lblPass.Size = New System.Drawing.Size(56, 13)
        Me.lblPass.TabIndex = 13
        Me.lblPass.Text = "Password:"
        '
        'lblUser
        '
        Me.lblUser.AutoSize = True
        Me.lblUser.Location = New System.Drawing.Point(6, 237)
        Me.lblUser.Name = "lblUser"
        Me.lblUser.Size = New System.Drawing.Size(58, 13)
        Me.lblUser.TabIndex = 12
        Me.lblUser.Text = "Username:"
        '
        'txtCity
        '
        Me.txtCity.Location = New System.Drawing.Point(111, 133)
        Me.txtCity.Name = "txtCity"
        Me.txtCity.Size = New System.Drawing.Size(100, 20)
        Me.txtCity.TabIndex = 5
        '
        'lblCity
        '
        Me.lblCity.AutoSize = True
        Me.lblCity.Location = New System.Drawing.Point(6, 125)
        Me.lblCity.Name = "lblCity"
        Me.lblCity.Size = New System.Drawing.Size(65, 13)
        Me.lblCity.TabIndex = 10
        Me.lblCity.Text = "City / Town:"
        '
        'lblEmail
        '
        Me.lblEmail.AutoSize = True
        Me.lblEmail.Location = New System.Drawing.Point(7, 200)
        Me.lblEmail.Name = "lblEmail"
        Me.lblEmail.Size = New System.Drawing.Size(35, 13)
        Me.lblEmail.TabIndex = 9
        Me.lblEmail.Text = "Email:"
        '
        'txtEmail
        '
        Me.txtEmail.Location = New System.Drawing.Point(111, 196)
        Me.txtEmail.Name = "txtEmail"
        Me.txtEmail.Size = New System.Drawing.Size(100, 20)
        Me.txtEmail.TabIndex = 7
        '
        'lblPhone
        '
        Me.lblPhone.AutoSize = True
        Me.lblPhone.Location = New System.Drawing.Point(6, 163)
        Me.lblPhone.Name = "lblPhone"
        Me.lblPhone.Size = New System.Drawing.Size(81, 13)
        Me.lblPhone.TabIndex = 7
        Me.lblPhone.Text = "Phone Number:"
        '
        'mskContact
        '
        Me.mskContact.Location = New System.Drawing.Point(111, 159)
        Me.mskContact.Mask = "(999) 000-0000"
        Me.mskContact.Name = "mskContact"
        Me.mskContact.Size = New System.Drawing.Size(100, 20)
        Me.mskContact.TabIndex = 6
        '
        'txtAddress
        '
        Me.txtAddress.Location = New System.Drawing.Point(111, 107)
        Me.txtAddress.Name = "txtAddress"
        Me.txtAddress.Size = New System.Drawing.Size(100, 20)
        Me.txtAddress.TabIndex = 4
        '
        'lblAddress
        '
        Me.lblAddress.AutoSize = True
        Me.lblAddress.Location = New System.Drawing.Point(5, 87)
        Me.lblAddress.Name = "lblAddress"
        Me.lblAddress.Size = New System.Drawing.Size(48, 13)
        Me.lblAddress.TabIndex = 4
        Me.lblAddress.Text = "Address:"
        '
        'mskDOB
        '
        Me.mskDOB.Location = New System.Drawing.Point(111, 80)
        Me.mskDOB.Mask = "00/00/0000"
        Me.mskDOB.Name = "mskDOB"
        Me.mskDOB.Size = New System.Drawing.Size(100, 20)
        Me.mskDOB.TabIndex = 3
        Me.mskDOB.ValidatingType = GetType(Date)
        '
        'lblDOB
        '
        Me.lblDOB.AutoSize = True
        Me.lblDOB.Location = New System.Drawing.Point(5, 51)
        Me.lblDOB.Name = "lblDOB"
        Me.lblDOB.Size = New System.Drawing.Size(39, 13)
        Me.lblDOB.TabIndex = 2
        Me.lblDOB.Text = "D.O.B:"
        '
        'txtName
        '
        Me.txtName.Location = New System.Drawing.Point(111, 19)
        Me.txtName.Name = "txtName"
        Me.txtName.Size = New System.Drawing.Size(100, 20)
        Me.txtName.TabIndex = 2
        '
        'lblName
        '
        Me.lblName.AutoSize = True
        Me.lblName.Location = New System.Drawing.Point(7, 20)
        Me.lblName.Name = "lblName"
        Me.lblName.Size = New System.Drawing.Size(38, 13)
        Me.lblName.TabIndex = 0
        Me.lblName.Text = "Name:"
        '
        'btnBack
        '
        Me.btnBack.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnBack.ForeColor = System.Drawing.Color.FromArgb(CType(CType(245, Byte), Integer), CType(CType(5, Byte), Integer), CType(CType(12, Byte), Integer))
        Me.btnBack.Location = New System.Drawing.Point(37, 415)
        Me.btnBack.Margin = New System.Windows.Forms.Padding(2)
        Me.btnBack.Name = "btnBack"
        Me.btnBack.Size = New System.Drawing.Size(75, 23)
        Me.btnBack.TabIndex = 20
        Me.btnBack.Text = "&Back"
        Me.btnBack.UseVisualStyleBackColor = True
        '
        'ToolTip1
        '
        Me.ToolTip1.ToolTipIcon = System.Windows.Forms.ToolTipIcon.Info
        '
        'BindingSource1
        '
        Me.BindingSource1.DataMember = "tblCustomerInfo"
        Me.BindingSource1.DataSource = Me.CustomerDataSet
        '
        'CustomerDataSet
        '
        Me.CustomerDataSet.DataSetName = "CustomerDataSet"
        Me.CustomerDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'TblCustomerInfoTableAdapter
        '
        Me.TblCustomerInfoTableAdapter.ClearBeforeFill = True
        '
        'txtSurname
        '
        Me.txtSurname.Location = New System.Drawing.Point(111, 54)
        Me.txtSurname.Name = "txtSurname"
        Me.txtSurname.Size = New System.Drawing.Size(100, 20)
        Me.txtSurname.TabIndex = 18
        '
        'frmCustomer
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.btnBack)
        Me.Controls.Add(Me.grbNew)
        Me.Controls.Add(Me.grbExisting)
        Me.Controls.Add(Me.radNew)
        Me.Controls.Add(Me.radExisting)
        Me.Name = "frmCustomer"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Customer"
        Me.grbExisting.ResumeLayout(False)
        Me.grbExisting.PerformLayout()
        Me.grbNew.ResumeLayout(False)
        Me.grbNew.PerformLayout()
        CType(Me.BindingSource1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.CustomerDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents radExisting As RadioButton
    Friend WithEvents radNew As RadioButton
    Friend WithEvents grbExisting As GroupBox
    Friend WithEvents lblPassword As Label
    Friend WithEvents lblUsername As Label
    Friend WithEvents txtPassword As TextBox
    Friend WithEvents txtUsername As TextBox
    Friend WithEvents grbNew As GroupBox
    Friend WithEvents btnLogin As Button
    Friend WithEvents btnClear As Button
    Friend WithEvents btnReset As Button
    Friend WithEvents btnCreate As Button
    Friend WithEvents txtPass As TextBox
    Friend WithEvents txtUser As TextBox
    Friend WithEvents lblPass As Label
    Friend WithEvents lblUser As Label
    Friend WithEvents txtCity As TextBox
    Friend WithEvents lblCity As Label
    Friend WithEvents lblEmail As Label
    Friend WithEvents txtEmail As TextBox
    Friend WithEvents lblPhone As Label
    Friend WithEvents mskContact As MaskedTextBox
    Friend WithEvents txtAddress As TextBox
    Friend WithEvents lblAddress As Label
    Friend WithEvents mskDOB As MaskedTextBox
    Friend WithEvents lblDOB As Label
    Friend WithEvents txtName As TextBox
    Friend WithEvents lblName As Label
    Friend WithEvents btnBack As Button
    Friend WithEvents ToolTip1 As ToolTip
    Friend WithEvents txtConfirm As TextBox
    Friend WithEvents lblConfirm As Label
    Friend WithEvents BindingSource1 As BindingSource
    Friend WithEvents CustomerDataSet As CustomerDataSet
    Friend WithEvents TblCustomerInfoTableAdapter As CustomerDataSetTableAdapters.tblCustomerInfoTableAdapter
    Friend WithEvents txtSurname As TextBox
End Class
