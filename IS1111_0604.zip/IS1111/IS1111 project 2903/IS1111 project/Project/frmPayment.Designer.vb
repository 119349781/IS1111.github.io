﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmPayment
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmPayment))
        Me.txtAddress = New System.Windows.Forms.TextBox()
        Me.txtCustomer = New System.Windows.Forms.TextBox()
        Me.mskPhone = New System.Windows.Forms.MaskedTextBox()
        Me.lblContact = New System.Windows.Forms.Label()
        Me.lblAddress = New System.Windows.Forms.Label()
        Me.lblCustomer = New System.Windows.Forms.Label()
        Me.lblOrder = New System.Windows.Forms.Label()
        Me.mskCvv = New System.Windows.Forms.MaskedTextBox()
        Me.lblCvv = New System.Windows.Forms.Label()
        Me.mskExpiry = New System.Windows.Forms.MaskedTextBox()
        Me.lblExpiry = New System.Windows.Forms.Label()
        Me.mskNumber = New System.Windows.Forms.MaskedTextBox()
        Me.lblNumber = New System.Windows.Forms.Label()
        Me.txtName = New System.Windows.Forms.TextBox()
        Me.lblName = New System.Windows.Forms.Label()
        Me.btnPay = New System.Windows.Forms.Button()
        Me.lblDetails = New System.Windows.Forms.Label()
        Me.txtTotal = New System.Windows.Forms.TextBox()
        Me.lblTotal = New System.Windows.Forms.Label()
        Me.btnBack = New System.Windows.Forms.Button()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.ShopToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MensToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.WomensToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TrackOrderToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ContactUsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.HelpToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.LogoutToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'txtAddress
        '
        Me.txtAddress.Location = New System.Drawing.Point(176, 523)
        Me.txtAddress.Name = "txtAddress"
        Me.txtAddress.Size = New System.Drawing.Size(188, 26)
        Me.txtAddress.TabIndex = 38
        '
        'txtCustomer
        '
        Me.txtCustomer.Location = New System.Drawing.Point(176, 477)
        Me.txtCustomer.Name = "txtCustomer"
        Me.txtCustomer.Size = New System.Drawing.Size(188, 26)
        Me.txtCustomer.TabIndex = 37
        '
        'mskPhone
        '
        Me.mskPhone.Location = New System.Drawing.Point(176, 580)
        Me.mskPhone.Mask = "(999) 000-0000"
        Me.mskPhone.Name = "mskPhone"
        Me.mskPhone.Size = New System.Drawing.Size(188, 26)
        Me.mskPhone.TabIndex = 41
        '
        'lblContact
        '
        Me.lblContact.AutoSize = True
        Me.lblContact.BackColor = System.Drawing.Color.Transparent
        Me.lblContact.Location = New System.Drawing.Point(26, 580)
        Me.lblContact.Name = "lblContact"
        Me.lblContact.Size = New System.Drawing.Size(129, 20)
        Me.lblContact.TabIndex = 44
        Me.lblContact.Text = "Contact Number:"
        '
        'lblAddress
        '
        Me.lblAddress.AutoSize = True
        Me.lblAddress.BackColor = System.Drawing.Color.Transparent
        Me.lblAddress.Location = New System.Drawing.Point(26, 529)
        Me.lblAddress.Name = "lblAddress"
        Me.lblAddress.Size = New System.Drawing.Size(145, 20)
        Me.lblAddress.TabIndex = 43
        Me.lblAddress.Text = "Customer Address:"
        '
        'lblCustomer
        '
        Me.lblCustomer.AutoSize = True
        Me.lblCustomer.BackColor = System.Drawing.Color.Transparent
        Me.lblCustomer.Location = New System.Drawing.Point(26, 483)
        Me.lblCustomer.Name = "lblCustomer"
        Me.lblCustomer.Size = New System.Drawing.Size(128, 20)
        Me.lblCustomer.TabIndex = 40
        Me.lblCustomer.Text = "Customer Name:"
        '
        'lblOrder
        '
        Me.lblOrder.AutoSize = True
        Me.lblOrder.BackColor = System.Drawing.Color.Transparent
        Me.lblOrder.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblOrder.Location = New System.Drawing.Point(183, 414)
        Me.lblOrder.Name = "lblOrder"
        Me.lblOrder.Size = New System.Drawing.Size(246, 36)
        Me.lblOrder.TabIndex = 39
        Me.lblOrder.Text = "Order Information"
        '
        'mskCvv
        '
        Me.mskCvv.Location = New System.Drawing.Point(189, 374)
        Me.mskCvv.Mask = "000"
        Me.mskCvv.Name = "mskCvv"
        Me.mskCvv.Size = New System.Drawing.Size(62, 26)
        Me.mskCvv.TabIndex = 36
        '
        'lblCvv
        '
        Me.lblCvv.AutoSize = True
        Me.lblCvv.BackColor = System.Drawing.Color.Transparent
        Me.lblCvv.Location = New System.Drawing.Point(21, 380)
        Me.lblCvv.Name = "lblCvv"
        Me.lblCvv.Size = New System.Drawing.Size(46, 20)
        Me.lblCvv.TabIndex = 35
        Me.lblCvv.Text = "CVV:"
        '
        'mskExpiry
        '
        Me.mskExpiry.Location = New System.Drawing.Point(189, 335)
        Me.mskExpiry.Mask = "00/0000"
        Me.mskExpiry.Name = "mskExpiry"
        Me.mskExpiry.Size = New System.Drawing.Size(94, 26)
        Me.mskExpiry.TabIndex = 34
        '
        'lblExpiry
        '
        Me.lblExpiry.AutoSize = True
        Me.lblExpiry.BackColor = System.Drawing.Color.Transparent
        Me.lblExpiry.Location = New System.Drawing.Point(21, 342)
        Me.lblExpiry.Name = "lblExpiry"
        Me.lblExpiry.Size = New System.Drawing.Size(94, 20)
        Me.lblExpiry.TabIndex = 33
        Me.lblExpiry.Text = "Expiry Date:"
        '
        'mskNumber
        '
        Me.mskNumber.Location = New System.Drawing.Point(189, 292)
        Me.mskNumber.Mask = "0000-0000-0000-0000"
        Me.mskNumber.Name = "mskNumber"
        Me.mskNumber.Size = New System.Drawing.Size(176, 26)
        Me.mskNumber.TabIndex = 32
        '
        'lblNumber
        '
        Me.lblNumber.AutoSize = True
        Me.lblNumber.BackColor = System.Drawing.Color.Transparent
        Me.lblNumber.Location = New System.Drawing.Point(21, 298)
        Me.lblNumber.Name = "lblNumber"
        Me.lblNumber.Size = New System.Drawing.Size(107, 20)
        Me.lblNumber.TabIndex = 31
        Me.lblNumber.Text = "Card Number:"
        '
        'txtName
        '
        Me.txtName.Location = New System.Drawing.Point(189, 246)
        Me.txtName.Name = "txtName"
        Me.txtName.Size = New System.Drawing.Size(176, 26)
        Me.txtName.TabIndex = 30
        '
        'lblName
        '
        Me.lblName.AutoSize = True
        Me.lblName.BackColor = System.Drawing.Color.Transparent
        Me.lblName.Location = New System.Drawing.Point(21, 252)
        Me.lblName.Name = "lblName"
        Me.lblName.Size = New System.Drawing.Size(158, 20)
        Me.lblName.TabIndex = 29
        Me.lblName.Text = "Name of CardHolder:"
        '
        'btnPay
        '
        Me.btnPay.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnPay.Location = New System.Drawing.Point(656, 335)
        Me.btnPay.Name = "btnPay"
        Me.btnPay.Size = New System.Drawing.Size(122, 51)
        Me.btnPay.TabIndex = 42
        Me.btnPay.Text = "&Pay Now"
        Me.btnPay.UseVisualStyleBackColor = True
        '
        'lblDetails
        '
        Me.lblDetails.AutoSize = True
        Me.lblDetails.BackColor = System.Drawing.Color.Transparent
        Me.lblDetails.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDetails.Location = New System.Drawing.Point(183, 191)
        Me.lblDetails.Name = "lblDetails"
        Me.lblDetails.Size = New System.Drawing.Size(426, 36)
        Me.lblDetails.TabIndex = 28
        Me.lblDetails.Text = "Please Enter Your Card Details"
        '
        'txtTotal
        '
        Me.txtTotal.BackColor = System.Drawing.Color.White
        Me.txtTotal.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtTotal.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtTotal.Location = New System.Drawing.Point(301, 96)
        Me.txtTotal.Name = "txtTotal"
        Me.txtTotal.ReadOnly = True
        Me.txtTotal.Size = New System.Drawing.Size(246, 34)
        Me.txtTotal.TabIndex = 27
        '
        'lblTotal
        '
        Me.lblTotal.AutoSize = True
        Me.lblTotal.BackColor = System.Drawing.Color.Transparent
        Me.lblTotal.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTotal.Location = New System.Drawing.Point(183, 101)
        Me.lblTotal.Name = "lblTotal"
        Me.lblTotal.Size = New System.Drawing.Size(95, 36)
        Me.lblTotal.TabIndex = 26
        Me.lblTotal.Text = "Total:"
        '
        'btnBack
        '
        Me.btnBack.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnBack.ForeColor = System.Drawing.Color.Red
        Me.btnBack.Location = New System.Drawing.Point(657, 465)
        Me.btnBack.Name = "btnBack"
        Me.btnBack.Size = New System.Drawing.Size(118, 49)
        Me.btnBack.TabIndex = 45
        Me.btnBack.Text = "&Back"
        Me.btnBack.UseVisualStyleBackColor = True
        '
        'MenuStrip1
        '
        Me.MenuStrip1.BackColor = System.Drawing.Color.Transparent
        Me.MenuStrip1.ImageScalingSize = New System.Drawing.Size(24, 24)
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ShopToolStripMenuItem, Me.TrackOrderToolStripMenuItem, Me.ContactUsToolStripMenuItem, Me.HelpToolStripMenuItem, Me.LogoutToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(1200, 33)
        Me.MenuStrip1.TabIndex = 46
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'ShopToolStripMenuItem
        '
        Me.ShopToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.MensToolStripMenuItem, Me.WomensToolStripMenuItem})
        Me.ShopToolStripMenuItem.Name = "ShopToolStripMenuItem"
        Me.ShopToolStripMenuItem.Size = New System.Drawing.Size(66, 29)
        Me.ShopToolStripMenuItem.Text = "&Shop"
        '
        'MensToolStripMenuItem
        '
        Me.MensToolStripMenuItem.Name = "MensToolStripMenuItem"
        Me.MensToolStripMenuItem.Size = New System.Drawing.Size(166, 30)
        Me.MensToolStripMenuItem.Text = "Mens"
        '
        'WomensToolStripMenuItem
        '
        Me.WomensToolStripMenuItem.Name = "WomensToolStripMenuItem"
        Me.WomensToolStripMenuItem.Size = New System.Drawing.Size(166, 30)
        Me.WomensToolStripMenuItem.Text = "Womens"
        '
        'TrackOrderToolStripMenuItem
        '
        Me.TrackOrderToolStripMenuItem.Name = "TrackOrderToolStripMenuItem"
        Me.TrackOrderToolStripMenuItem.Size = New System.Drawing.Size(114, 29)
        Me.TrackOrderToolStripMenuItem.Text = "&Track Order"
        '
        'ContactUsToolStripMenuItem
        '
        Me.ContactUsToolStripMenuItem.Name = "ContactUsToolStripMenuItem"
        Me.ContactUsToolStripMenuItem.Size = New System.Drawing.Size(99, 29)
        Me.ContactUsToolStripMenuItem.Text = "About &Us"
        '
        'HelpToolStripMenuItem
        '
        Me.HelpToolStripMenuItem.Name = "HelpToolStripMenuItem"
        Me.HelpToolStripMenuItem.Size = New System.Drawing.Size(61, 29)
        Me.HelpToolStripMenuItem.Text = "&Help"
        '
        'LogoutToolStripMenuItem
        '
        Me.LogoutToolStripMenuItem.Name = "LogoutToolStripMenuItem"
        Me.LogoutToolStripMenuItem.Size = New System.Drawing.Size(81, 29)
        Me.LogoutToolStripMenuItem.Text = "&Logout"
        '
        'frmPayment
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = Global.Project.My.Resources.Resources.background
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(1200, 692)
        Me.Controls.Add(Me.txtAddress)
        Me.Controls.Add(Me.txtCustomer)
        Me.Controls.Add(Me.mskPhone)
        Me.Controls.Add(Me.lblContact)
        Me.Controls.Add(Me.lblAddress)
        Me.Controls.Add(Me.lblCustomer)
        Me.Controls.Add(Me.lblOrder)
        Me.Controls.Add(Me.mskCvv)
        Me.Controls.Add(Me.lblCvv)
        Me.Controls.Add(Me.mskExpiry)
        Me.Controls.Add(Me.lblExpiry)
        Me.Controls.Add(Me.mskNumber)
        Me.Controls.Add(Me.lblNumber)
        Me.Controls.Add(Me.txtName)
        Me.Controls.Add(Me.lblName)
        Me.Controls.Add(Me.btnPay)
        Me.Controls.Add(Me.lblDetails)
        Me.Controls.Add(Me.txtTotal)
        Me.Controls.Add(Me.lblTotal)
        Me.Controls.Add(Me.btnBack)
        Me.Controls.Add(Me.MenuStrip1)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Name = "frmPayment"
        Me.Text = "frmPayment"
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents txtAddress As TextBox
    Friend WithEvents txtCustomer As TextBox
    Friend WithEvents mskPhone As MaskedTextBox
    Friend WithEvents lblContact As Label
    Friend WithEvents lblAddress As Label
    Friend WithEvents lblCustomer As Label
    Friend WithEvents lblOrder As Label
    Friend WithEvents mskCvv As MaskedTextBox
    Friend WithEvents lblCvv As Label
    Friend WithEvents mskExpiry As MaskedTextBox
    Friend WithEvents lblExpiry As Label
    Friend WithEvents mskNumber As MaskedTextBox
    Friend WithEvents lblNumber As Label
    Friend WithEvents txtName As TextBox
    Friend WithEvents lblName As Label
    Friend WithEvents btnPay As Button
    Friend WithEvents lblDetails As Label
    Friend WithEvents txtTotal As TextBox
    Friend WithEvents lblTotal As Label
    Friend WithEvents btnBack As Button
    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents ShopToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents MensToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents WomensToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents TrackOrderToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ContactUsToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents LogoutToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents HelpToolStripMenuItem As ToolStripMenuItem
End Class
