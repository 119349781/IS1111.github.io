﻿Public Class frmStaffCreate
    Private Sub frmStaffCreate_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'StaffCreateDataSet.tblStaffLogin' table. You can move, or remove it, as needed.
        Me.TblStaffLoginTableAdapter.Fill(Me.StaffCreateDataSet.tblStaffLogin)

    End Sub


    Private Sub btnUpdate_Click(sender As Object, e As EventArgs) Handles btnUpdate.Click
        Try
            Me.Validate()
            BindingSource1.EndEdit()
            TblStaffLoginTableAdapter.Update(Me.StaffCreateDataSet.tblStaffLogin)
            MsgBox("Data Saved", "Status Update")
        Catch ex As Exception
            MsgBox("Error Saving Data")
        End Try
    End Sub

    Private Sub btnBack_Click(sender As Object, e As EventArgs) Handles btnBack.Click
        frmStaffLogin.Show()
        Me.Hide()
    End Sub
End Class