﻿Public Class frmAccount
    Private Sub btnNew_Click(sender As Object, e As EventArgs) Handles btnNew.Click
        'Brings customer to order form
        Me.Hide()
        frmOrder.Show()
    End Sub

    Private Sub btnLogout_Click(sender As Object, e As EventArgs) Handles btnLogout.Click
        'brings customer back to login page 
        Dim DialogResult As DialogResult
        DialogResult = MessageBox.Show("Are you sure you want to logout?", "Shoes Ltd.",
                                       MessageBoxButtons.YesNo,
                                       MessageBoxIcon.Question,
                                       MessageBoxDefaultButton.Button2)
        If DialogResult = DialogResult.Yes Then
            Me.Hide()
            frmCustomer.Show()
        End If
    End Sub

    Private Sub frmAccount_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim strName As String
        If frmCustomer.txtUsername.Text = "" Then
            strName = frmCustomer.txtUser.Text
            lblWelcome.Text = ("Welcome " & strName & " !")
        ElseIf frmCustomer.txtUser.Text = "" Then
            strName = frmCustomer.txtUsername.Text
            lblWelcome.Text = ("Welcome " & strName & " !")
        End If
    End Sub

    Private Sub btnTrack_Click(sender As Object, e As EventArgs) Handles btnTrack.Click
        'brings customer to track order form
        Me.Hide()
        frmTrack.Show()
    End Sub

    Private Sub btnHelp_Click(sender As Object, e As EventArgs) Handles btnHelp.Click
        'brings customer to user manual
        Me.Close()
        frmUserManual.Show()
    End Sub
End Class