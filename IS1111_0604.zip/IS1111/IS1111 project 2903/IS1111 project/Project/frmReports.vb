﻿Public Class frmReports
    Private Sub btnDisplay_Click(sender As Object, e As EventArgs) Handles btnDisplay.Click

    End Sub

    Private Sub btnPrint_Click(sender As Object, e As EventArgs) Handles btnPrint.Click
        MsgBox("How many copies? ")
    End Sub
End Class