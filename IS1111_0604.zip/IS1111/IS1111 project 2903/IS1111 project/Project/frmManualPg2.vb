﻿Public Class frmManualPg2
    Private Sub btnBack_Click(sender As Object, e As EventArgs) Handles btnBack.Click
        'brings user back first page of user manual
        Me.Hide()
        frmUserManual.Show()
    End Sub

    Private Sub LogoutToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles LogoutToolStripMenuItem.Click
        'brings customer back to login page 
        Dim DialogResult As DialogResult
        DialogResult = MessageBox.Show("Are you sure you want to logout?", "Shoes Ltd.",
                                       MessageBoxButtons.YesNo,
                                       MessageBoxIcon.Question,
                                       MessageBoxDefaultButton.Button2)
        If DialogResult = DialogResult.Yes Then
            Me.Hide()
            frmCustomer.Show()
        End If
    End Sub

    Private Sub MensToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles MensToolStripMenuItem.Click
        'brings customer to order form
        Me.Close()
        frmOrder.Show()
    End Sub

    Private Sub WomensToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles WomensToolStripMenuItem.Click
        'brings customer to order form
        Me.Close()
        frmOrder.Show()
    End Sub

    Private Sub TrackOrderToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles TrackOrderToolStripMenuItem.Click
        'brings customer to track order form
        Me.Close()
        frmTrack.Show()
    End Sub

    Private Sub AboutUsToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AboutUsToolStripMenuItem.Click
        'brings user to about us form
        Me.Close()
        frmAboutUs.Show()
    End Sub

    Private Sub HelpToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles HelpToolStripMenuItem.Click
        'brings user to first page of customer user manual
        Me.Close()
        frmUserManual.Show()
    End Sub
End Class