﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmConfirmation
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmConfirmation))
        Me.lblOrder = New System.Windows.Forms.Label()
        Me.btnReceipt = New System.Windows.Forms.Button()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.ShopToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MensShoesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.WomensShoesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TrackOrsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ContactUsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.HelpToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.LogoutToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PrintPreviewDialog1 = New System.Windows.Forms.PrintPreviewDialog()
        Me.PrintDocument1 = New System.Drawing.Printing.PrintDocument()
        Me.BindingSource1 = New System.Windows.Forms.BindingSource(Me.components)
        Me.TrackOrderDataSet = New Project.TrackOrderDataSet()
        Me.TblOrdersTableAdapter = New Project.TrackOrderDataSetTableAdapters.tblOrdersTableAdapter()
        Me.lblInfo = New System.Windows.Forms.Label()
        Me.lblDate = New System.Windows.Forms.Label()
        Me.lblToday = New System.Windows.Forms.Label()
        Me.lblOrders = New System.Windows.Forms.Label()
        Me.lblNo = New System.Windows.Forms.Label()
        Me.lblCustomer = New System.Windows.Forms.Label()
        Me.lblName = New System.Windows.Forms.Label()
        Me.lblAdd = New System.Windows.Forms.Label()
        Me.lblAddress = New System.Windows.Forms.Label()
        Me.lblPhone = New System.Windows.Forms.Label()
        Me.lblNum = New System.Windows.Forms.Label()
        Me.lblcustomized = New System.Windows.Forms.Label()
        Me.lblCustom = New System.Windows.Forms.Label()
        Me.lblLogo = New System.Windows.Forms.Label()
        Me.lblPic = New System.Windows.Forms.Label()
        Me.lblDes = New System.Windows.Forms.Label()
        Me.lblQuarter = New System.Windows.Forms.Label()
        Me.lblVamp = New System.Windows.Forms.Label()
        Me.lblEye = New System.Windows.Forms.Label()
        Me.lblLaces = New System.Windows.Forms.Label()
        Me.lblBack = New System.Windows.Forms.Label()
        Me.lblText = New System.Windows.Forms.Label()
        Me.lblSize = New System.Windows.Forms.Label()
        Me.lblShoeS = New System.Windows.Forms.Label()
        Me.lblVat = New System.Windows.Forms.Label()
        Me.lblVatat = New System.Windows.Forms.Label()
        Me.lblTotal = New System.Windows.Forms.Label()
        Me.lblTot = New System.Windows.Forms.Label()
        Me.lblQuantity = New System.Windows.Forms.Label()
        Me.lblQuant = New System.Windows.Forms.Label()
        Me.lblDiscount = New System.Windows.Forms.Label()
        Me.lblDis = New System.Windows.Forms.Label()
        Me.lblGrand = New System.Windows.Forms.Label()
        Me.lblGrandTot = New System.Windows.Forms.Label()
        Me.MenuStrip1.SuspendLayout()
        CType(Me.BindingSource1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TrackOrderDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'lblOrder
        '
        Me.lblOrder.AutoSize = True
        Me.lblOrder.BackColor = System.Drawing.Color.Transparent
        Me.lblOrder.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblOrder.Location = New System.Drawing.Point(202, 42)
        Me.lblOrder.Name = "lblOrder"
        Me.lblOrder.Size = New System.Drawing.Size(351, 29)
        Me.lblOrder.TabIndex = 60
        Me.lblOrder.Text = "Order was Successfully Placed!"
        '
        'btnReceipt
        '
        Me.btnReceipt.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnReceipt.Location = New System.Drawing.Point(690, 607)
        Me.btnReceipt.Name = "btnReceipt"
        Me.btnReceipt.Size = New System.Drawing.Size(138, 68)
        Me.btnReceipt.TabIndex = 59
        Me.btnReceipt.Text = "&Print Receipt"
        Me.btnReceipt.UseVisualStyleBackColor = True
        '
        'MenuStrip1
        '
        Me.MenuStrip1.BackColor = System.Drawing.Color.Transparent
        Me.MenuStrip1.ImageScalingSize = New System.Drawing.Size(24, 24)
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ShopToolStripMenuItem, Me.TrackOrsToolStripMenuItem, Me.ContactUsToolStripMenuItem, Me.HelpToolStripMenuItem, Me.LogoutToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(867, 33)
        Me.MenuStrip1.TabIndex = 58
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'ShopToolStripMenuItem
        '
        Me.ShopToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.MensShoesToolStripMenuItem, Me.WomensShoesToolStripMenuItem})
        Me.ShopToolStripMenuItem.Name = "ShopToolStripMenuItem"
        Me.ShopToolStripMenuItem.Size = New System.Drawing.Size(66, 29)
        Me.ShopToolStripMenuItem.Text = "&Shop"
        '
        'MensShoesToolStripMenuItem
        '
        Me.MensShoesToolStripMenuItem.Name = "MensShoesToolStripMenuItem"
        Me.MensShoesToolStripMenuItem.Size = New System.Drawing.Size(219, 30)
        Me.MensShoesToolStripMenuItem.Text = "Mens Shoes"
        '
        'WomensShoesToolStripMenuItem
        '
        Me.WomensShoesToolStripMenuItem.Name = "WomensShoesToolStripMenuItem"
        Me.WomensShoesToolStripMenuItem.Size = New System.Drawing.Size(219, 30)
        Me.WomensShoesToolStripMenuItem.Text = "Womens Shoes"
        '
        'TrackOrsToolStripMenuItem
        '
        Me.TrackOrsToolStripMenuItem.Name = "TrackOrsToolStripMenuItem"
        Me.TrackOrsToolStripMenuItem.Size = New System.Drawing.Size(114, 29)
        Me.TrackOrsToolStripMenuItem.Text = "&Track Order"
        '
        'ContactUsToolStripMenuItem
        '
        Me.ContactUsToolStripMenuItem.Name = "ContactUsToolStripMenuItem"
        Me.ContactUsToolStripMenuItem.Size = New System.Drawing.Size(99, 29)
        Me.ContactUsToolStripMenuItem.Text = "About &Us"
        '
        'HelpToolStripMenuItem
        '
        Me.HelpToolStripMenuItem.Name = "HelpToolStripMenuItem"
        Me.HelpToolStripMenuItem.Size = New System.Drawing.Size(61, 29)
        Me.HelpToolStripMenuItem.Text = "&Help"
        '
        'LogoutToolStripMenuItem
        '
        Me.LogoutToolStripMenuItem.Name = "LogoutToolStripMenuItem"
        Me.LogoutToolStripMenuItem.Size = New System.Drawing.Size(81, 29)
        Me.LogoutToolStripMenuItem.Text = "&Logout"
        '
        'PrintPreviewDialog1
        '
        Me.PrintPreviewDialog1.AutoScrollMargin = New System.Drawing.Size(0, 0)
        Me.PrintPreviewDialog1.AutoScrollMinSize = New System.Drawing.Size(0, 0)
        Me.PrintPreviewDialog1.ClientSize = New System.Drawing.Size(400, 300)
        Me.PrintPreviewDialog1.Document = Me.PrintDocument1
        Me.PrintPreviewDialog1.Enabled = True
        Me.PrintPreviewDialog1.Icon = CType(resources.GetObject("PrintPreviewDialog1.Icon"), System.Drawing.Icon)
        Me.PrintPreviewDialog1.Name = "PrintPreviewDialog1"
        Me.PrintPreviewDialog1.Visible = False
        '
        'PrintDocument1
        '
        Me.PrintDocument1.DocumentName = "Order_Receipt"
        '
        'BindingSource1
        '
        Me.BindingSource1.DataMember = "tblOrders"
        Me.BindingSource1.DataSource = Me.TrackOrderDataSet
        '
        'TrackOrderDataSet
        '
        Me.TrackOrderDataSet.DataSetName = "TrackOrderDataSet"
        Me.TrackOrderDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'TblOrdersTableAdapter
        '
        Me.TblOrdersTableAdapter.ClearBeforeFill = True
        '
        'lblInfo
        '
        Me.lblInfo.AutoSize = True
        Me.lblInfo.BackColor = System.Drawing.Color.Transparent
        Me.lblInfo.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblInfo.Location = New System.Drawing.Point(266, 71)
        Me.lblInfo.Name = "lblInfo"
        Me.lblInfo.Size = New System.Drawing.Size(221, 75)
        Me.lblInfo.TabIndex = 116
        Me.lblInfo.Text = "Shoes Ltd. " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "1234 Oliver Plunkett St. " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "021-3847742"
        Me.lblInfo.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'lblDate
        '
        Me.lblDate.AutoSize = True
        Me.lblDate.BackColor = System.Drawing.Color.Transparent
        Me.lblDate.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDate.Location = New System.Drawing.Point(132, 151)
        Me.lblDate.Name = "lblDate"
        Me.lblDate.Size = New System.Drawing.Size(53, 20)
        Me.lblDate.TabIndex = 117
        Me.lblDate.Text = "Date:"
        '
        'lblToday
        '
        Me.lblToday.AutoSize = True
        Me.lblToday.BackColor = System.Drawing.Color.Transparent
        Me.lblToday.Location = New System.Drawing.Point(207, 151)
        Me.lblToday.Name = "lblToday"
        Me.lblToday.Size = New System.Drawing.Size(0, 20)
        Me.lblToday.TabIndex = 118
        '
        'lblOrders
        '
        Me.lblOrders.AutoSize = True
        Me.lblOrders.BackColor = System.Drawing.Color.Transparent
        Me.lblOrders.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblOrders.Location = New System.Drawing.Point(358, 151)
        Me.lblOrders.Name = "lblOrders"
        Me.lblOrders.Size = New System.Drawing.Size(86, 20)
        Me.lblOrders.TabIndex = 119
        Me.lblOrders.Text = "Order No."
        '
        'lblNo
        '
        Me.lblNo.AutoSize = True
        Me.lblNo.BackColor = System.Drawing.Color.Transparent
        Me.lblNo.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TrackOrderDataSet, "tblOrders.Order ID", True))
        Me.lblNo.Location = New System.Drawing.Point(450, 151)
        Me.lblNo.Name = "lblNo"
        Me.lblNo.Size = New System.Drawing.Size(0, 20)
        Me.lblNo.TabIndex = 120
        '
        'lblCustomer
        '
        Me.lblCustomer.AutoSize = True
        Me.lblCustomer.BackColor = System.Drawing.Color.Transparent
        Me.lblCustomer.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCustomer.Location = New System.Drawing.Point(132, 180)
        Me.lblCustomer.Name = "lblCustomer"
        Me.lblCustomer.Size = New System.Drawing.Size(142, 20)
        Me.lblCustomer.TabIndex = 121
        Me.lblCustomer.Text = "Customer Name:"
        '
        'lblName
        '
        Me.lblName.AutoSize = True
        Me.lblName.BackColor = System.Drawing.Color.Transparent
        Me.lblName.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TrackOrderDataSet, "tblOrders.Name", True))
        Me.lblName.Location = New System.Drawing.Point(366, 180)
        Me.lblName.Name = "lblName"
        Me.lblName.Size = New System.Drawing.Size(0, 20)
        Me.lblName.TabIndex = 122
        '
        'lblAdd
        '
        Me.lblAdd.AutoSize = True
        Me.lblAdd.BackColor = System.Drawing.Color.Transparent
        Me.lblAdd.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblAdd.Location = New System.Drawing.Point(132, 211)
        Me.lblAdd.Name = "lblAdd"
        Me.lblAdd.Size = New System.Drawing.Size(162, 20)
        Me.lblAdd.TabIndex = 123
        Me.lblAdd.Text = "Customer Address:"
        '
        'lblAddress
        '
        Me.lblAddress.AutoSize = True
        Me.lblAddress.BackColor = System.Drawing.Color.Transparent
        Me.lblAddress.Location = New System.Drawing.Point(364, 211)
        Me.lblAddress.Name = "lblAddress"
        Me.lblAddress.Size = New System.Drawing.Size(0, 20)
        Me.lblAddress.TabIndex = 124
        '
        'lblPhone
        '
        Me.lblPhone.AutoSize = True
        Me.lblPhone.BackColor = System.Drawing.Color.Transparent
        Me.lblPhone.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPhone.Location = New System.Drawing.Point(132, 247)
        Me.lblPhone.Name = "lblPhone"
        Me.lblPhone.Size = New System.Drawing.Size(214, 20)
        Me.lblPhone.TabIndex = 125
        Me.lblPhone.Text = "Customer Phone Number:"
        '
        'lblNum
        '
        Me.lblNum.AutoSize = True
        Me.lblNum.BackColor = System.Drawing.Color.Transparent
        Me.lblNum.Location = New System.Drawing.Point(364, 247)
        Me.lblNum.Name = "lblNum"
        Me.lblNum.Size = New System.Drawing.Size(0, 20)
        Me.lblNum.TabIndex = 126
        '
        'lblcustomized
        '
        Me.lblcustomized.AutoSize = True
        Me.lblcustomized.BackColor = System.Drawing.Color.Transparent
        Me.lblcustomized.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblcustomized.Location = New System.Drawing.Point(132, 276)
        Me.lblcustomized.Name = "lblcustomized"
        Me.lblcustomized.Size = New System.Drawing.Size(198, 20)
        Me.lblcustomized.TabIndex = 127
        Me.lblcustomized.Text = "Shoe to be customized:"
        '
        'lblCustom
        '
        Me.lblCustom.AutoSize = True
        Me.lblCustom.BackColor = System.Drawing.Color.Transparent
        Me.lblCustom.Location = New System.Drawing.Point(369, 276)
        Me.lblCustom.Name = "lblCustom"
        Me.lblCustom.Size = New System.Drawing.Size(0, 20)
        Me.lblCustom.TabIndex = 128
        '
        'lblLogo
        '
        Me.lblLogo.AutoSize = True
        Me.lblLogo.BackColor = System.Drawing.Color.Transparent
        Me.lblLogo.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblLogo.Location = New System.Drawing.Point(132, 446)
        Me.lblLogo.Name = "lblLogo"
        Me.lblLogo.Size = New System.Drawing.Size(115, 20)
        Me.lblLogo.TabIndex = 129
        Me.lblLogo.Text = "Logo/Picture:"
        '
        'lblPic
        '
        Me.lblPic.AutoSize = True
        Me.lblPic.BackColor = System.Drawing.Color.Transparent
        Me.lblPic.Location = New System.Drawing.Point(372, 437)
        Me.lblPic.Name = "lblPic"
        Me.lblPic.Size = New System.Drawing.Size(0, 20)
        Me.lblPic.TabIndex = 130
        '
        'lblDes
        '
        Me.lblDes.AutoSize = True
        Me.lblDes.BackColor = System.Drawing.Color.Transparent
        Me.lblDes.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDes.Location = New System.Drawing.Point(132, 308)
        Me.lblDes.Name = "lblDes"
        Me.lblDes.Size = New System.Drawing.Size(224, 20)
        Me.lblDes.TabIndex = 131
        Me.lblDes.Text = "Customization Description:"
        '
        'lblQuarter
        '
        Me.lblQuarter.AutoSize = True
        Me.lblQuarter.BackColor = System.Drawing.Color.Transparent
        Me.lblQuarter.Location = New System.Drawing.Point(371, 308)
        Me.lblQuarter.Name = "lblQuarter"
        Me.lblQuarter.Size = New System.Drawing.Size(0, 20)
        Me.lblQuarter.TabIndex = 132
        '
        'lblVamp
        '
        Me.lblVamp.AutoSize = True
        Me.lblVamp.BackColor = System.Drawing.Color.Transparent
        Me.lblVamp.Location = New System.Drawing.Point(370, 328)
        Me.lblVamp.Name = "lblVamp"
        Me.lblVamp.Size = New System.Drawing.Size(0, 20)
        Me.lblVamp.TabIndex = 133
        '
        'lblEye
        '
        Me.lblEye.AutoSize = True
        Me.lblEye.BackColor = System.Drawing.Color.Transparent
        Me.lblEye.Location = New System.Drawing.Point(370, 348)
        Me.lblEye.Name = "lblEye"
        Me.lblEye.Size = New System.Drawing.Size(0, 20)
        Me.lblEye.TabIndex = 134
        '
        'lblLaces
        '
        Me.lblLaces.AutoSize = True
        Me.lblLaces.BackColor = System.Drawing.Color.Transparent
        Me.lblLaces.Location = New System.Drawing.Point(370, 368)
        Me.lblLaces.Name = "lblLaces"
        Me.lblLaces.Size = New System.Drawing.Size(0, 20)
        Me.lblLaces.TabIndex = 135
        '
        'lblBack
        '
        Me.lblBack.AutoSize = True
        Me.lblBack.BackColor = System.Drawing.Color.Transparent
        Me.lblBack.Location = New System.Drawing.Point(370, 388)
        Me.lblBack.Name = "lblBack"
        Me.lblBack.Size = New System.Drawing.Size(0, 20)
        Me.lblBack.TabIndex = 136
        '
        'lblText
        '
        Me.lblText.AutoSize = True
        Me.lblText.BackColor = System.Drawing.Color.Transparent
        Me.lblText.Location = New System.Drawing.Point(370, 408)
        Me.lblText.Name = "lblText"
        Me.lblText.Size = New System.Drawing.Size(0, 20)
        Me.lblText.TabIndex = 137
        '
        'lblSize
        '
        Me.lblSize.AutoSize = True
        Me.lblSize.BackColor = System.Drawing.Color.Transparent
        Me.lblSize.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblSize.Location = New System.Drawing.Point(132, 475)
        Me.lblSize.Name = "lblSize"
        Me.lblSize.Size = New System.Drawing.Size(96, 20)
        Me.lblSize.TabIndex = 138
        Me.lblSize.Text = "Shoe Size:"
        '
        'lblShoeS
        '
        Me.lblShoeS.AutoSize = True
        Me.lblShoeS.BackColor = System.Drawing.Color.Transparent
        Me.lblShoeS.Location = New System.Drawing.Point(372, 475)
        Me.lblShoeS.Name = "lblShoeS"
        Me.lblShoeS.Size = New System.Drawing.Size(0, 20)
        Me.lblShoeS.TabIndex = 139
        '
        'lblVat
        '
        Me.lblVat.AutoSize = True
        Me.lblVat.BackColor = System.Drawing.Color.Transparent
        Me.lblVat.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblVat.Location = New System.Drawing.Point(136, 510)
        Me.lblVat.Name = "lblVat"
        Me.lblVat.Size = New System.Drawing.Size(105, 20)
        Me.lblVat.TabIndex = 140
        Me.lblVat.Text = "VAT @ 23%"
        '
        'lblVatat
        '
        Me.lblVatat.AutoSize = True
        Me.lblVatat.BackColor = System.Drawing.Color.Transparent
        Me.lblVatat.Location = New System.Drawing.Point(371, 509)
        Me.lblVatat.Name = "lblVatat"
        Me.lblVatat.Size = New System.Drawing.Size(0, 20)
        Me.lblVatat.TabIndex = 141
        '
        'lblTotal
        '
        Me.lblTotal.AutoSize = True
        Me.lblTotal.BackColor = System.Drawing.Color.Transparent
        Me.lblTotal.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTotal.Location = New System.Drawing.Point(132, 546)
        Me.lblTotal.Name = "lblTotal"
        Me.lblTotal.Size = New System.Drawing.Size(49, 20)
        Me.lblTotal.TabIndex = 142
        Me.lblTotal.Text = "Total"
        '
        'lblTot
        '
        Me.lblTot.AutoSize = True
        Me.lblTot.BackColor = System.Drawing.Color.Transparent
        Me.lblTot.Location = New System.Drawing.Point(368, 546)
        Me.lblTot.Name = "lblTot"
        Me.lblTot.Size = New System.Drawing.Size(0, 20)
        Me.lblTot.TabIndex = 143
        '
        'lblQuantity
        '
        Me.lblQuantity.AutoSize = True
        Me.lblQuantity.BackColor = System.Drawing.Color.Transparent
        Me.lblQuantity.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblQuantity.Location = New System.Drawing.Point(136, 585)
        Me.lblQuantity.Name = "lblQuantity"
        Me.lblQuantity.Size = New System.Drawing.Size(146, 20)
        Me.lblQuantity.TabIndex = 144
        Me.lblQuantity.Text = "Quantity Ordered"
        '
        'lblQuant
        '
        Me.lblQuant.AutoSize = True
        Me.lblQuant.BackColor = System.Drawing.Color.Transparent
        Me.lblQuant.Location = New System.Drawing.Point(376, 584)
        Me.lblQuant.Name = "lblQuant"
        Me.lblQuant.Size = New System.Drawing.Size(0, 20)
        Me.lblQuant.TabIndex = 145
        '
        'lblDiscount
        '
        Me.lblDiscount.AutoSize = True
        Me.lblDiscount.BackColor = System.Drawing.Color.Transparent
        Me.lblDiscount.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDiscount.Location = New System.Drawing.Point(136, 619)
        Me.lblDiscount.Name = "lblDiscount"
        Me.lblDiscount.Size = New System.Drawing.Size(91, 20)
        Me.lblDiscount.TabIndex = 146
        Me.lblDiscount.Text = "- Discount"
        '
        'lblDis
        '
        Me.lblDis.AutoSize = True
        Me.lblDis.BackColor = System.Drawing.Color.Transparent
        Me.lblDis.Location = New System.Drawing.Point(367, 619)
        Me.lblDis.Name = "lblDis"
        Me.lblDis.Size = New System.Drawing.Size(0, 20)
        Me.lblDis.TabIndex = 147
        '
        'lblGrand
        '
        Me.lblGrand.AutoSize = True
        Me.lblGrand.BackColor = System.Drawing.Color.Transparent
        Me.lblGrand.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblGrand.Location = New System.Drawing.Point(136, 655)
        Me.lblGrand.Name = "lblGrand"
        Me.lblGrand.Size = New System.Drawing.Size(104, 20)
        Me.lblGrand.TabIndex = 148
        Me.lblGrand.Text = "Grand Total"
        '
        'lblGrandTot
        '
        Me.lblGrandTot.AutoSize = True
        Me.lblGrandTot.BackColor = System.Drawing.Color.Transparent
        Me.lblGrandTot.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TrackOrderDataSet, "tblOrders.Price", True))
        Me.lblGrandTot.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblGrandTot.Location = New System.Drawing.Point(367, 655)
        Me.lblGrandTot.Name = "lblGrandTot"
        Me.lblGrandTot.Size = New System.Drawing.Size(0, 20)
        Me.lblGrandTot.TabIndex = 149
        '
        'frmConfirmation
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = Global.Project.My.Resources.Resources.background
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(867, 698)
        Me.Controls.Add(Me.lblGrandTot)
        Me.Controls.Add(Me.lblGrand)
        Me.Controls.Add(Me.lblDis)
        Me.Controls.Add(Me.lblDiscount)
        Me.Controls.Add(Me.lblQuant)
        Me.Controls.Add(Me.lblQuantity)
        Me.Controls.Add(Me.lblTot)
        Me.Controls.Add(Me.lblTotal)
        Me.Controls.Add(Me.lblVatat)
        Me.Controls.Add(Me.lblVat)
        Me.Controls.Add(Me.lblShoeS)
        Me.Controls.Add(Me.lblSize)
        Me.Controls.Add(Me.lblText)
        Me.Controls.Add(Me.lblBack)
        Me.Controls.Add(Me.lblLaces)
        Me.Controls.Add(Me.lblEye)
        Me.Controls.Add(Me.lblVamp)
        Me.Controls.Add(Me.lblQuarter)
        Me.Controls.Add(Me.lblDes)
        Me.Controls.Add(Me.lblPic)
        Me.Controls.Add(Me.lblLogo)
        Me.Controls.Add(Me.lblCustom)
        Me.Controls.Add(Me.lblcustomized)
        Me.Controls.Add(Me.lblNum)
        Me.Controls.Add(Me.lblPhone)
        Me.Controls.Add(Me.lblAddress)
        Me.Controls.Add(Me.lblAdd)
        Me.Controls.Add(Me.lblName)
        Me.Controls.Add(Me.lblCustomer)
        Me.Controls.Add(Me.lblNo)
        Me.Controls.Add(Me.lblOrders)
        Me.Controls.Add(Me.lblToday)
        Me.Controls.Add(Me.lblDate)
        Me.Controls.Add(Me.lblInfo)
        Me.Controls.Add(Me.lblOrder)
        Me.Controls.Add(Me.btnReceipt)
        Me.Controls.Add(Me.MenuStrip1)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Name = "frmConfirmation"
        Me.Text = "frmConfirmation"
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        CType(Me.BindingSource1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TrackOrderDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents lblOrder As Label
    Friend WithEvents btnReceipt As Button
    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents ShopToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents MensShoesToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents WomensShoesToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents TrackOrsToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ContactUsToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents LogoutToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents PrintPreviewDialog1 As PrintPreviewDialog
    Friend WithEvents PrintDocument1 As Printing.PrintDocument
    Friend WithEvents BindingSource1 As BindingSource
    Friend WithEvents TrackOrderDataSet As TrackOrderDataSet
    Friend WithEvents TblOrdersTableAdapter As TrackOrderDataSetTableAdapters.tblOrdersTableAdapter
    Friend WithEvents HelpToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents lblInfo As Label
    Friend WithEvents lblDate As Label
    Friend WithEvents lblToday As Label
    Friend WithEvents lblOrders As Label
    Friend WithEvents lblNo As Label
    Friend WithEvents lblCustomer As Label
    Friend WithEvents lblName As Label
    Friend WithEvents lblAdd As Label
    Friend WithEvents lblAddress As Label
    Friend WithEvents lblPhone As Label
    Friend WithEvents lblNum As Label
    Friend WithEvents lblcustomized As Label
    Friend WithEvents lblCustom As Label
    Friend WithEvents lblLogo As Label
    Friend WithEvents lblPic As Label
    Friend WithEvents lblDes As Label
    Friend WithEvents lblQuarter As Label
    Friend WithEvents lblVamp As Label
    Friend WithEvents lblEye As Label
    Friend WithEvents lblLaces As Label
    Friend WithEvents lblBack As Label
    Friend WithEvents lblText As Label
    Friend WithEvents lblSize As Label
    Friend WithEvents lblShoeS As Label
    Friend WithEvents lblVat As Label
    Friend WithEvents lblVatat As Label
    Friend WithEvents lblTotal As Label
    Friend WithEvents lblTot As Label
    Friend WithEvents lblQuantity As Label
    Friend WithEvents lblQuant As Label
    Friend WithEvents lblDiscount As Label
    Friend WithEvents lblDis As Label
    Friend WithEvents lblGrand As Label
    Friend WithEvents lblGrandTot As Label
End Class
