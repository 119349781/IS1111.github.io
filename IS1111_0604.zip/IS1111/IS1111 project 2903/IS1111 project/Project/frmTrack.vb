﻿Public Class frmTrack
    Private Sub frmTrack_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'TrackOrderDataSet.tblOrders' table. You can move, or remove it, as needed.
        Me.TblOrdersTableAdapter.Fill(Me.TrackOrderDataSet.tblOrders)

    End Sub

    Private Sub LogoutToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles LogoutToolStripMenuItem.Click
        'brings customer back to login page 
        Dim DialogResult As DialogResult
        DialogResult = MessageBox.Show("Are you sure you want to logout?", "Shoes Ltd.",
                                       MessageBoxButtons.YesNo,
                                       MessageBoxIcon.Question,
                                       MessageBoxDefaultButton.Button2)
        If DialogResult = DialogResult.Yes Then
            Me.Close()
            frmCustomer.Show()
        End If
    End Sub

    Private Sub MensToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles MensToolStripMenuItem.Click
        'Brings customer to order form
        Me.Close()
        frmOrder.Show()
    End Sub

    Private Sub WomensToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles WomensToolStripMenuItem.Click
        'Brings customer to order form
        Me.Close()
        frmOrder.Show()
    End Sub

    Private Sub AboutUsToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AboutUsToolStripMenuItem.Click
        'brings user to Abous Us form
        Me.Close()
        frmAboutUs.Show()
    End Sub

    Private Sub TrackOrderToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles TrackOrderToolStripMenuItem.Click
        'refreshes the page
        Me.Refresh()
    End Sub

    Private Sub btnTrack_Click(sender As Object, e As EventArgs) Handles btnTrack.Click
        'shows the order status if it exists
        Dim query1 = From order In TrackOrderDataSet.tblOrders
                     Where order.Order_ID = txtOrder.Text
                     Select order.Order_ID, order.Name, order.Price, order.Status

        If query1.Count = 1 Then
            dgvOrder.DataSource = query1.ToList
            dgvOrder.CurrentCell = Nothing
        Else
            MessageBox.Show("Invalid order ID. Please try again", "Shoes Ltd.",
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Error)
            txtOrder.Text = ""
            txtOrder.Focus()
        End If
    End Sub

    Private Sub HelpToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles HelpToolStripMenuItem.Click
        'brings cuustomer to user manual form
        Me.Close()
        frmUserManual.Show()
    End Sub
End Class