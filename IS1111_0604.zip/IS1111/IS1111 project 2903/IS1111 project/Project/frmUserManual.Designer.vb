﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmUserManual
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmUserManual))
        Me.picUsers = New System.Windows.Forms.PictureBox()
        Me.lblLogin = New System.Windows.Forms.Label()
        Me.lblOne = New System.Windows.Forms.Label()
        Me.lblTwo = New System.Windows.Forms.Label()
        Me.picHome = New System.Windows.Forms.PictureBox()
        Me.lblThree = New System.Windows.Forms.Label()
        Me.lblFour = New System.Windows.Forms.Label()
        Me.picTrack = New System.Windows.Forms.PictureBox()
        Me.lblFive = New System.Windows.Forms.Label()
        Me.picMenu = New System.Windows.Forms.PictureBox()
        Me.lblSix = New System.Windows.Forms.Label()
        Me.lblSeven = New System.Windows.Forms.Label()
        Me.picBrowse = New System.Windows.Forms.PictureBox()
        Me.picSample = New System.Windows.Forms.PictureBox()
        Me.btnNext = New System.Windows.Forms.Button()
        Me.picClear = New System.Windows.Forms.PictureBox()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.ShopToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MensToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.WomensToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TrackOrderToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AboutUsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.HelpToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.LogoutToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.lblCustomer = New System.Windows.Forms.Label()
        Me.lblButtons = New System.Windows.Forms.Label()
        Me.lblLogout = New System.Windows.Forms.Label()
        Me.lblTrack = New System.Windows.Forms.Label()
        Me.lblMenu = New System.Windows.Forms.Label()
        Me.lblOrder = New System.Windows.Forms.Label()
        Me.lblLogo = New System.Windows.Forms.Label()
        CType(Me.picUsers, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picHome, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picTrack, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picMenu, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picBrowse, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picSample, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picClear, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'picUsers
        '
        Me.picUsers.Image = CType(resources.GetObject("picUsers.Image"), System.Drawing.Image)
        Me.picUsers.Location = New System.Drawing.Point(288, 54)
        Me.picUsers.Name = "picUsers"
        Me.picUsers.Size = New System.Drawing.Size(163, 180)
        Me.picUsers.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picUsers.TabIndex = 1
        Me.picUsers.TabStop = False
        '
        'lblLogin
        '
        Me.lblLogin.AutoSize = True
        Me.lblLogin.BackColor = System.Drawing.Color.Transparent
        Me.lblLogin.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblLogin.Location = New System.Drawing.Point(32, 40)
        Me.lblLogin.Name = "lblLogin"
        Me.lblLogin.Size = New System.Drawing.Size(181, 25)
        Me.lblLogin.TabIndex = 2
        Me.lblLogin.Text = "Customer Report:"
        '
        'lblOne
        '
        Me.lblOne.AutoSize = True
        Me.lblOne.BackColor = System.Drawing.Color.Transparent
        Me.lblOne.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblOne.Location = New System.Drawing.Point(-1, 79)
        Me.lblOne.Name = "lblOne"
        Me.lblOne.Size = New System.Drawing.Size(31, 25)
        Me.lblOne.TabIndex = 4
        Me.lblOne.Text = "1:"
        '
        'lblTwo
        '
        Me.lblTwo.AutoSize = True
        Me.lblTwo.BackColor = System.Drawing.Color.Transparent
        Me.lblTwo.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTwo.Location = New System.Drawing.Point(-1, 274)
        Me.lblTwo.Name = "lblTwo"
        Me.lblTwo.Size = New System.Drawing.Size(31, 25)
        Me.lblTwo.TabIndex = 5
        Me.lblTwo.Text = "2:"
        '
        'picHome
        '
        Me.picHome.Image = CType(resources.GetObject("picHome.Image"), System.Drawing.Image)
        Me.picHome.Location = New System.Drawing.Point(253, 263)
        Me.picHome.Name = "picHome"
        Me.picHome.Size = New System.Drawing.Size(290, 98)
        Me.picHome.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picHome.TabIndex = 6
        Me.picHome.TabStop = False
        '
        'lblThree
        '
        Me.lblThree.AutoSize = True
        Me.lblThree.BackColor = System.Drawing.Color.Transparent
        Me.lblThree.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblThree.Location = New System.Drawing.Point(4, 397)
        Me.lblThree.Name = "lblThree"
        Me.lblThree.Size = New System.Drawing.Size(31, 25)
        Me.lblThree.TabIndex = 7
        Me.lblThree.Text = "3:"
        '
        'lblFour
        '
        Me.lblFour.AutoSize = True
        Me.lblFour.BackColor = System.Drawing.Color.Transparent
        Me.lblFour.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblFour.Location = New System.Drawing.Point(4, 525)
        Me.lblFour.Name = "lblFour"
        Me.lblFour.Size = New System.Drawing.Size(31, 25)
        Me.lblFour.TabIndex = 9
        Me.lblFour.Text = "4:"
        '
        'picTrack
        '
        Me.picTrack.Image = CType(resources.GetObject("picTrack.Image"), System.Drawing.Image)
        Me.picTrack.Location = New System.Drawing.Point(318, 470)
        Me.picTrack.Name = "picTrack"
        Me.picTrack.Size = New System.Drawing.Size(127, 172)
        Me.picTrack.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picTrack.TabIndex = 11
        Me.picTrack.TabStop = False
        '
        'lblFive
        '
        Me.lblFive.AutoSize = True
        Me.lblFive.BackColor = System.Drawing.Color.Transparent
        Me.lblFive.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblFive.Location = New System.Drawing.Point(494, 55)
        Me.lblFive.Name = "lblFive"
        Me.lblFive.Size = New System.Drawing.Size(31, 25)
        Me.lblFive.TabIndex = 12
        Me.lblFive.Text = "5:"
        '
        'picMenu
        '
        Me.picMenu.Image = CType(resources.GetObject("picMenu.Image"), System.Drawing.Image)
        Me.picMenu.Location = New System.Drawing.Point(693, 68)
        Me.picMenu.Name = "picMenu"
        Me.picMenu.Size = New System.Drawing.Size(259, 29)
        Me.picMenu.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picMenu.TabIndex = 14
        Me.picMenu.TabStop = False
        '
        'lblSix
        '
        Me.lblSix.AutoSize = True
        Me.lblSix.BackColor = System.Drawing.Color.Transparent
        Me.lblSix.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblSix.Location = New System.Drawing.Point(499, 172)
        Me.lblSix.Name = "lblSix"
        Me.lblSix.Size = New System.Drawing.Size(31, 25)
        Me.lblSix.TabIndex = 15
        Me.lblSix.Text = "6:"
        '
        'lblSeven
        '
        Me.lblSeven.AutoSize = True
        Me.lblSeven.BackColor = System.Drawing.Color.Transparent
        Me.lblSeven.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblSeven.Location = New System.Drawing.Point(433, 397)
        Me.lblSeven.Name = "lblSeven"
        Me.lblSeven.Size = New System.Drawing.Size(31, 25)
        Me.lblSeven.TabIndex = 17
        Me.lblSeven.Text = "7:"
        '
        'picBrowse
        '
        Me.picBrowse.Image = CType(resources.GetObject("picBrowse.Image"), System.Drawing.Image)
        Me.picBrowse.Location = New System.Drawing.Point(704, 350)
        Me.picBrowse.Name = "picBrowse"
        Me.picBrowse.Size = New System.Drawing.Size(127, 41)
        Me.picBrowse.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picBrowse.TabIndex = 19
        Me.picBrowse.TabStop = False
        '
        'picSample
        '
        Me.picSample.Image = CType(resources.GetObject("picSample.Image"), System.Drawing.Image)
        Me.picSample.Location = New System.Drawing.Point(704, 397)
        Me.picSample.Name = "picSample"
        Me.picSample.Size = New System.Drawing.Size(190, 92)
        Me.picSample.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picSample.TabIndex = 20
        Me.picSample.TabStop = False
        '
        'btnNext
        '
        Me.btnNext.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.btnNext.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnNext.Location = New System.Drawing.Point(811, 569)
        Me.btnNext.Name = "btnNext"
        Me.btnNext.Size = New System.Drawing.Size(155, 73)
        Me.btnNext.TabIndex = 24
        Me.btnNext.Text = "&Next Page"
        Me.btnNext.UseVisualStyleBackColor = False
        '
        'picClear
        '
        Me.picClear.Image = CType(resources.GetObject("picClear.Image"), System.Drawing.Image)
        Me.picClear.Location = New System.Drawing.Point(704, 500)
        Me.picClear.Name = "picClear"
        Me.picClear.Size = New System.Drawing.Size(100, 50)
        Me.picClear.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picClear.TabIndex = 25
        Me.picClear.TabStop = False
        '
        'MenuStrip1
        '
        Me.MenuStrip1.BackColor = System.Drawing.Color.Transparent
        Me.MenuStrip1.ImageScalingSize = New System.Drawing.Size(24, 24)
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ShopToolStripMenuItem, Me.TrackOrderToolStripMenuItem, Me.AboutUsToolStripMenuItem, Me.HelpToolStripMenuItem, Me.LogoutToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(998, 33)
        Me.MenuStrip1.TabIndex = 26
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'ShopToolStripMenuItem
        '
        Me.ShopToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.MensToolStripMenuItem, Me.WomensToolStripMenuItem})
        Me.ShopToolStripMenuItem.Name = "ShopToolStripMenuItem"
        Me.ShopToolStripMenuItem.Size = New System.Drawing.Size(66, 29)
        Me.ShopToolStripMenuItem.Text = "&Shop"
        '
        'MensToolStripMenuItem
        '
        Me.MensToolStripMenuItem.Name = "MensToolStripMenuItem"
        Me.MensToolStripMenuItem.Size = New System.Drawing.Size(166, 30)
        Me.MensToolStripMenuItem.Text = "Mens"
        '
        'WomensToolStripMenuItem
        '
        Me.WomensToolStripMenuItem.Name = "WomensToolStripMenuItem"
        Me.WomensToolStripMenuItem.Size = New System.Drawing.Size(166, 30)
        Me.WomensToolStripMenuItem.Text = "Womens"
        '
        'TrackOrderToolStripMenuItem
        '
        Me.TrackOrderToolStripMenuItem.Name = "TrackOrderToolStripMenuItem"
        Me.TrackOrderToolStripMenuItem.Size = New System.Drawing.Size(114, 29)
        Me.TrackOrderToolStripMenuItem.Text = "&Track Order"
        '
        'AboutUsToolStripMenuItem
        '
        Me.AboutUsToolStripMenuItem.Name = "AboutUsToolStripMenuItem"
        Me.AboutUsToolStripMenuItem.Size = New System.Drawing.Size(99, 29)
        Me.AboutUsToolStripMenuItem.Text = "About &Us"
        '
        'HelpToolStripMenuItem
        '
        Me.HelpToolStripMenuItem.Name = "HelpToolStripMenuItem"
        Me.HelpToolStripMenuItem.Size = New System.Drawing.Size(61, 29)
        Me.HelpToolStripMenuItem.Text = "&Help"
        '
        'LogoutToolStripMenuItem
        '
        Me.LogoutToolStripMenuItem.Name = "LogoutToolStripMenuItem"
        Me.LogoutToolStripMenuItem.Size = New System.Drawing.Size(81, 29)
        Me.LogoutToolStripMenuItem.Text = "&Logout"
        '
        'lblCustomer
        '
        Me.lblCustomer.AutoSize = True
        Me.lblCustomer.BackColor = System.Drawing.Color.Transparent
        Me.lblCustomer.Location = New System.Drawing.Point(33, 79)
        Me.lblCustomer.Name = "lblCustomer"
        Me.lblCustomer.Size = New System.Drawing.Size(239, 100)
        Me.lblCustomer.TabIndex = 27
        Me.lblCustomer.Text = "To login in as a user there are a " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "few accounts, one for example is" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & " aosuilliva" &
    "n.The username and" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & " password are identical. You can" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & " also create a new account" &
    ". "
        '
        'lblButtons
        '
        Me.lblButtons.AutoSize = True
        Me.lblButtons.BackColor = System.Drawing.Color.Transparent
        Me.lblButtons.Location = New System.Drawing.Point(37, 274)
        Me.lblButtons.Name = "lblButtons"
        Me.lblButtons.Size = New System.Drawing.Size(205, 80)
        Me.lblButtons.TabIndex = 28
        Me.lblButtons.Text = "You are then brought to the" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "home page, where you can" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "make a new order, track an" &
    "" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & " existing order or logout" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        '
        'lblLogout
        '
        Me.lblLogout.AutoSize = True
        Me.lblLogout.BackColor = System.Drawing.Color.Transparent
        Me.lblLogout.Location = New System.Drawing.Point(37, 397)
        Me.lblLogout.Name = "lblLogout"
        Me.lblLogout.Size = New System.Drawing.Size(220, 40)
        Me.lblLogout.TabIndex = 29
        Me.lblLogout.Text = "If you click logout you will be " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "brought back to the login form"
        '
        'lblTrack
        '
        Me.lblTrack.AutoSize = True
        Me.lblTrack.BackColor = System.Drawing.Color.Transparent
        Me.lblTrack.Location = New System.Drawing.Point(33, 525)
        Me.lblTrack.Name = "lblTrack"
        Me.lblTrack.Size = New System.Drawing.Size(279, 80)
        Me.lblTrack.TabIndex = 30
        Me.lblTrack.Text = "If you click track order you will be " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "brought to the track order form," & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "where yo" &
    "u can enter your order no. " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "to track. Here are some sample orders"
        '
        'lblMenu
        '
        Me.lblMenu.AutoSize = True
        Me.lblMenu.BackColor = System.Drawing.Color.Transparent
        Me.lblMenu.Location = New System.Drawing.Point(531, 60)
        Me.lblMenu.Name = "lblMenu"
        Me.lblMenu.Size = New System.Drawing.Size(160, 60)
        Me.lblMenu.TabIndex = 31
        Me.lblMenu.Text = "There is a menu strip " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "at the top of all forms" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & " for easy navigation"
        '
        'lblOrder
        '
        Me.lblOrder.AutoSize = True
        Me.lblOrder.BackColor = System.Drawing.Color.Transparent
        Me.lblOrder.Location = New System.Drawing.Point(531, 172)
        Me.lblOrder.Name = "lblOrder"
        Me.lblOrder.Size = New System.Drawing.Size(221, 80)
        Me.lblOrder.TabIndex = 32
        Me.lblOrder.Text = "When ordering shoes," & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "the option you choose" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "from the drop down will" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "make the re" &
    "lated image visible"
        '
        'lblLogo
        '
        Me.lblLogo.AutoSize = True
        Me.lblLogo.BackColor = System.Drawing.Color.Transparent
        Me.lblLogo.Location = New System.Drawing.Point(471, 397)
        Me.lblLogo.Name = "lblLogo"
        Me.lblLogo.Size = New System.Drawing.Size(214, 220)
        Me.lblLogo.TabIndex = 33
        Me.lblLogo.Text = resources.GetString("lblLogo.Text")
        '
        'frmUserManual
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = Global.Project.My.Resources.Resources.background
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(998, 666)
        Me.Controls.Add(Me.lblLogo)
        Me.Controls.Add(Me.lblOrder)
        Me.Controls.Add(Me.lblMenu)
        Me.Controls.Add(Me.lblTrack)
        Me.Controls.Add(Me.lblLogout)
        Me.Controls.Add(Me.lblButtons)
        Me.Controls.Add(Me.lblCustomer)
        Me.Controls.Add(Me.picClear)
        Me.Controls.Add(Me.btnNext)
        Me.Controls.Add(Me.picSample)
        Me.Controls.Add(Me.picBrowse)
        Me.Controls.Add(Me.lblSeven)
        Me.Controls.Add(Me.lblSix)
        Me.Controls.Add(Me.picMenu)
        Me.Controls.Add(Me.lblFive)
        Me.Controls.Add(Me.picTrack)
        Me.Controls.Add(Me.lblFour)
        Me.Controls.Add(Me.lblThree)
        Me.Controls.Add(Me.picHome)
        Me.Controls.Add(Me.lblTwo)
        Me.Controls.Add(Me.lblOne)
        Me.Controls.Add(Me.lblLogin)
        Me.Controls.Add(Me.picUsers)
        Me.Controls.Add(Me.MenuStrip1)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "frmUserManual"
        Me.Text = "User Manual"
        CType(Me.picUsers, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picHome, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picTrack, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picMenu, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picBrowse, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picSample, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picClear, System.ComponentModel.ISupportInitialize).EndInit()
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents picUsers As PictureBox
    Friend WithEvents lblLogin As Label
    Friend WithEvents lblOne As Label
    Friend WithEvents lblTwo As Label
    Friend WithEvents picHome As PictureBox
    Friend WithEvents lblThree As Label
    Friend WithEvents lblFour As Label
    Friend WithEvents picTrack As PictureBox
    Friend WithEvents lblFive As Label
    Friend WithEvents picMenu As PictureBox
    Friend WithEvents lblSix As Label
    Friend WithEvents lblSeven As Label
    Friend WithEvents picBrowse As PictureBox
    Friend WithEvents picSample As PictureBox
    Friend WithEvents btnNext As Button
    Friend WithEvents picClear As PictureBox
    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents ShopToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents MensToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents WomensToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents TrackOrderToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents AboutUsToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents HelpToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents LogoutToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents lblCustomer As Label
    Friend WithEvents lblButtons As Label
    Friend WithEvents lblLogout As Label
    Friend WithEvents lblTrack As Label
    Friend WithEvents lblMenu As Label
    Friend WithEvents lblOrder As Label
    Friend WithEvents lblLogo As Label
End Class
