﻿Public Class frmUserManual
    Private Sub btnNext_Click(sender As Object, e As EventArgs) Handles btnNext.Click
        'brings user to page 2 of user manual for customer
        Me.Hide()
        frmManualPg2.Show()
    End Sub

    Private Sub MensToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles MensToolStripMenuItem.Click
        'brings customer to order form
        Me.Close()
        frmOrder.Show()
    End Sub

    Private Sub WomensToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles WomensToolStripMenuItem.Click
        'brings customer to order form
        Me.Close()
        frmOrder.Show()
    End Sub

    Private Sub TrackOrderToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles TrackOrderToolStripMenuItem.Click
        'brings user to tracking form
        Me.Close()
        frmTrack.Show()
    End Sub

    Private Sub AboutUsToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AboutUsToolStripMenuItem.Click
        'brings customer to About Us form
        Me.Close()
        frmAboutUs.Show()
    End Sub

    Private Sub HelpToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles HelpToolStripMenuItem.Click
        'refreshes page
        Me.Refresh()
    End Sub

    Private Sub LogoutToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles LogoutToolStripMenuItem.Click
        'brings customer back to login page 
        Dim DialogResult As DialogResult
        DialogResult = MessageBox.Show("Are you sure you want to logout?", "Shoes Ltd.",
                                       MessageBoxButtons.YesNo,
                                       MessageBoxIcon.Question,
                                       MessageBoxDefaultButton.Button2)
        If DialogResult = DialogResult.Yes Then
            Me.Close()
            frmCustomer.Show()
        End If
    End Sub
End Class