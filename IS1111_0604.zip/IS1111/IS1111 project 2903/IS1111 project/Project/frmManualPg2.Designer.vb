﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmManualPg2
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmManualPg2))
        Me.btnBack = New System.Windows.Forms.Button()
        Me.picDiscount = New System.Windows.Forms.PictureBox()
        Me.lblEight = New System.Windows.Forms.Label()
        Me.lblNine = New System.Windows.Forms.Label()
        Me.picProceed = New System.Windows.Forms.PictureBox()
        Me.lblTen = New System.Windows.Forms.Label()
        Me.picPay = New System.Windows.Forms.PictureBox()
        Me.lblConfirm = New System.Windows.Forms.Label()
        Me.picConfirm = New System.Windows.Forms.PictureBox()
        Me.picMenu = New System.Windows.Forms.PictureBox()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.ShopToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MensToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.WomensToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TrackOrderToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AboutUsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.HelpToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.LogoutToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.lblDiscount = New System.Windows.Forms.Label()
        Me.lblPayment = New System.Windows.Forms.Label()
        Me.lblPaynow = New System.Windows.Forms.Label()
        Me.lblPrint = New System.Windows.Forms.Label()
        Me.lblTwelve = New System.Windows.Forms.Label()
        Me.lblAboutUs = New System.Windows.Forms.Label()
        Me.picAbout = New System.Windows.Forms.PictureBox()
        CType(Me.picDiscount, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picProceed, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picPay, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picConfirm, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picMenu, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.MenuStrip1.SuspendLayout()
        CType(Me.picAbout, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'btnBack
        '
        Me.btnBack.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.btnBack.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnBack.Location = New System.Drawing.Point(711, 365)
        Me.btnBack.Name = "btnBack"
        Me.btnBack.Size = New System.Drawing.Size(179, 95)
        Me.btnBack.TabIndex = 0
        Me.btnBack.Text = "&Back"
        Me.btnBack.UseVisualStyleBackColor = False
        '
        'picDiscount
        '
        Me.picDiscount.Image = CType(resources.GetObject("picDiscount.Image"), System.Drawing.Image)
        Me.picDiscount.Location = New System.Drawing.Point(233, 40)
        Me.picDiscount.Name = "picDiscount"
        Me.picDiscount.Size = New System.Drawing.Size(244, 64)
        Me.picDiscount.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picDiscount.TabIndex = 26
        Me.picDiscount.TabStop = False
        '
        'lblEight
        '
        Me.lblEight.AutoSize = True
        Me.lblEight.BackColor = System.Drawing.Color.Transparent
        Me.lblEight.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblEight.Location = New System.Drawing.Point(12, 46)
        Me.lblEight.Name = "lblEight"
        Me.lblEight.Size = New System.Drawing.Size(31, 25)
        Me.lblEight.TabIndex = 24
        Me.lblEight.Text = "8:"
        '
        'lblNine
        '
        Me.lblNine.AutoSize = True
        Me.lblNine.BackColor = System.Drawing.Color.Transparent
        Me.lblNine.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblNine.Location = New System.Drawing.Point(12, 139)
        Me.lblNine.Name = "lblNine"
        Me.lblNine.Size = New System.Drawing.Size(31, 25)
        Me.lblNine.TabIndex = 27
        Me.lblNine.Text = "9:"
        '
        'picProceed
        '
        Me.picProceed.Image = CType(resources.GetObject("picProceed.Image"), System.Drawing.Image)
        Me.picProceed.Location = New System.Drawing.Point(234, 153)
        Me.picProceed.Name = "picProceed"
        Me.picProceed.Size = New System.Drawing.Size(202, 50)
        Me.picProceed.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picProceed.TabIndex = 29
        Me.picProceed.TabStop = False
        '
        'lblTen
        '
        Me.lblTen.AutoSize = True
        Me.lblTen.BackColor = System.Drawing.Color.Transparent
        Me.lblTen.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTen.Location = New System.Drawing.Point(12, 268)
        Me.lblTen.Name = "lblTen"
        Me.lblTen.Size = New System.Drawing.Size(43, 25)
        Me.lblTen.TabIndex = 30
        Me.lblTen.Text = "10:"
        '
        'picPay
        '
        Me.picPay.Image = CType(resources.GetObject("picPay.Image"), System.Drawing.Image)
        Me.picPay.Location = New System.Drawing.Point(254, 268)
        Me.picPay.Name = "picPay"
        Me.picPay.Size = New System.Drawing.Size(144, 113)
        Me.picPay.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picPay.TabIndex = 32
        Me.picPay.TabStop = False
        '
        'lblConfirm
        '
        Me.lblConfirm.AutoSize = True
        Me.lblConfirm.BackColor = System.Drawing.Color.Transparent
        Me.lblConfirm.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblConfirm.Location = New System.Drawing.Point(12, 412)
        Me.lblConfirm.Name = "lblConfirm"
        Me.lblConfirm.Size = New System.Drawing.Size(43, 25)
        Me.lblConfirm.TabIndex = 33
        Me.lblConfirm.Text = "11:"
        '
        'picConfirm
        '
        Me.picConfirm.Image = CType(resources.GetObject("picConfirm.Image"), System.Drawing.Image)
        Me.picConfirm.Location = New System.Drawing.Point(397, 412)
        Me.picConfirm.Name = "picConfirm"
        Me.picConfirm.Size = New System.Drawing.Size(124, 61)
        Me.picConfirm.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picConfirm.TabIndex = 35
        Me.picConfirm.TabStop = False
        '
        'picMenu
        '
        Me.picMenu.Image = CType(resources.GetObject("picMenu.Image"), System.Drawing.Image)
        Me.picMenu.Location = New System.Drawing.Point(397, 482)
        Me.picMenu.Name = "picMenu"
        Me.picMenu.Size = New System.Drawing.Size(332, 50)
        Me.picMenu.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picMenu.TabIndex = 36
        Me.picMenu.TabStop = False
        '
        'MenuStrip1
        '
        Me.MenuStrip1.BackColor = System.Drawing.Color.Transparent
        Me.MenuStrip1.ImageScalingSize = New System.Drawing.Size(24, 24)
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ShopToolStripMenuItem, Me.TrackOrderToolStripMenuItem, Me.AboutUsToolStripMenuItem, Me.HelpToolStripMenuItem, Me.LogoutToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(926, 33)
        Me.MenuStrip1.TabIndex = 38
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'ShopToolStripMenuItem
        '
        Me.ShopToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.MensToolStripMenuItem, Me.WomensToolStripMenuItem})
        Me.ShopToolStripMenuItem.Name = "ShopToolStripMenuItem"
        Me.ShopToolStripMenuItem.Size = New System.Drawing.Size(66, 29)
        Me.ShopToolStripMenuItem.Text = "&Shop"
        '
        'MensToolStripMenuItem
        '
        Me.MensToolStripMenuItem.Name = "MensToolStripMenuItem"
        Me.MensToolStripMenuItem.Size = New System.Drawing.Size(166, 30)
        Me.MensToolStripMenuItem.Text = "Mens"
        '
        'WomensToolStripMenuItem
        '
        Me.WomensToolStripMenuItem.Name = "WomensToolStripMenuItem"
        Me.WomensToolStripMenuItem.Size = New System.Drawing.Size(166, 30)
        Me.WomensToolStripMenuItem.Text = "Womens"
        '
        'TrackOrderToolStripMenuItem
        '
        Me.TrackOrderToolStripMenuItem.Name = "TrackOrderToolStripMenuItem"
        Me.TrackOrderToolStripMenuItem.Size = New System.Drawing.Size(114, 29)
        Me.TrackOrderToolStripMenuItem.Text = "&Track Order"
        '
        'AboutUsToolStripMenuItem
        '
        Me.AboutUsToolStripMenuItem.Name = "AboutUsToolStripMenuItem"
        Me.AboutUsToolStripMenuItem.Size = New System.Drawing.Size(99, 29)
        Me.AboutUsToolStripMenuItem.Text = "About &Us"
        '
        'HelpToolStripMenuItem
        '
        Me.HelpToolStripMenuItem.Name = "HelpToolStripMenuItem"
        Me.HelpToolStripMenuItem.Size = New System.Drawing.Size(61, 29)
        Me.HelpToolStripMenuItem.Text = "&Help"
        '
        'LogoutToolStripMenuItem
        '
        Me.LogoutToolStripMenuItem.Name = "LogoutToolStripMenuItem"
        Me.LogoutToolStripMenuItem.Size = New System.Drawing.Size(81, 29)
        Me.LogoutToolStripMenuItem.Text = "&Logout"
        '
        'lblDiscount
        '
        Me.lblDiscount.AutoSize = True
        Me.lblDiscount.BackColor = System.Drawing.Color.Transparent
        Me.lblDiscount.Location = New System.Drawing.Point(45, 40)
        Me.lblDiscount.Name = "lblDiscount"
        Me.lblDiscount.Size = New System.Drawing.Size(156, 60)
        Me.lblDiscount.TabIndex = 39
        Me.lblDiscount.Text = "the user gets a 15% " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "discount if they enter" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & " the line 'get15'"
        '
        'lblPayment
        '
        Me.lblPayment.AutoSize = True
        Me.lblPayment.BackColor = System.Drawing.Color.Transparent
        Me.lblPayment.Location = New System.Drawing.Point(49, 139)
        Me.lblPayment.Name = "lblPayment"
        Me.lblPayment.Size = New System.Drawing.Size(167, 80)
        Me.lblPayment.TabIndex = 40
        Me.lblPayment.Text = "To click the procced to" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & " next page button to " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "view the total and to " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "pay for t" &
    "he shoes"
        '
        'lblPaynow
        '
        Me.lblPaynow.AutoSize = True
        Me.lblPaynow.BackColor = System.Drawing.Color.Transparent
        Me.lblPaynow.Location = New System.Drawing.Point(49, 268)
        Me.lblPaynow.Name = "lblPaynow"
        Me.lblPaynow.Size = New System.Drawing.Size(188, 100)
        Me.lblPaynow.TabIndex = 41
        Me.lblPaynow.Text = "You must fill out all" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & " textboxes before the" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & " order can be paid for. Or " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "you ca" &
    "n press 'back' to" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & " return to the order form "
        '
        'lblPrint
        '
        Me.lblPrint.AutoSize = True
        Me.lblPrint.BackColor = System.Drawing.Color.Transparent
        Me.lblPrint.Location = New System.Drawing.Point(53, 412)
        Me.lblPrint.Name = "lblPrint"
        Me.lblPrint.Size = New System.Drawing.Size(311, 120)
        Me.lblPrint.TabIndex = 42
        Me.lblPrint.Text = resources.GetString("lblPrint.Text")
        '
        'lblTwelve
        '
        Me.lblTwelve.AutoSize = True
        Me.lblTwelve.BackColor = System.Drawing.Color.Transparent
        Me.lblTwelve.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTwelve.Location = New System.Drawing.Point(516, 40)
        Me.lblTwelve.Name = "lblTwelve"
        Me.lblTwelve.Size = New System.Drawing.Size(43, 25)
        Me.lblTwelve.TabIndex = 43
        Me.lblTwelve.Text = "12:"
        '
        'lblAboutUs
        '
        Me.lblAboutUs.AutoSize = True
        Me.lblAboutUs.BackColor = System.Drawing.Color.Transparent
        Me.lblAboutUs.Location = New System.Drawing.Point(565, 40)
        Me.lblAboutUs.Name = "lblAboutUs"
        Me.lblAboutUs.Size = New System.Drawing.Size(184, 80)
        Me.lblAboutUs.TabIndex = 44
        Me.lblAboutUs.Text = "The About Us option in" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "the menu strip brings the" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "user to a form that gives " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "yo" &
    "u info on the company"
        '
        'picAbout
        '
        Me.picAbout.Image = CType(resources.GetObject("picAbout.Image"), System.Drawing.Image)
        Me.picAbout.Location = New System.Drawing.Point(569, 124)
        Me.picAbout.Name = "picAbout"
        Me.picAbout.Size = New System.Drawing.Size(308, 183)
        Me.picAbout.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picAbout.TabIndex = 45
        Me.picAbout.TabStop = False
        '
        'frmManualPg2
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = Global.Project.My.Resources.Resources.background
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(926, 544)
        Me.Controls.Add(Me.picAbout)
        Me.Controls.Add(Me.lblAboutUs)
        Me.Controls.Add(Me.lblTwelve)
        Me.Controls.Add(Me.lblPrint)
        Me.Controls.Add(Me.lblPaynow)
        Me.Controls.Add(Me.lblPayment)
        Me.Controls.Add(Me.lblDiscount)
        Me.Controls.Add(Me.picMenu)
        Me.Controls.Add(Me.picConfirm)
        Me.Controls.Add(Me.lblConfirm)
        Me.Controls.Add(Me.picPay)
        Me.Controls.Add(Me.lblTen)
        Me.Controls.Add(Me.picProceed)
        Me.Controls.Add(Me.lblNine)
        Me.Controls.Add(Me.picDiscount)
        Me.Controls.Add(Me.lblEight)
        Me.Controls.Add(Me.btnBack)
        Me.Controls.Add(Me.MenuStrip1)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "frmManualPg2"
        Me.Text = "Manual Pg2"
        CType(Me.picDiscount, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picProceed, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picPay, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picConfirm, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picMenu, System.ComponentModel.ISupportInitialize).EndInit()
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        CType(Me.picAbout, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btnBack As Button
    Friend WithEvents picDiscount As PictureBox
    Friend WithEvents lblEight As Label
    Friend WithEvents lblNine As Label
    Friend WithEvents picProceed As PictureBox
    Friend WithEvents lblTen As Label
    Friend WithEvents picPay As PictureBox
    Friend WithEvents lblConfirm As Label
    Friend WithEvents picConfirm As PictureBox
    Friend WithEvents picMenu As PictureBox
    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents ShopToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents MensToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents WomensToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents TrackOrderToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents AboutUsToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents HelpToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents LogoutToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents lblDiscount As Label
    Friend WithEvents lblPayment As Label
    Friend WithEvents lblPaynow As Label
    Friend WithEvents lblPrint As Label
    Friend WithEvents lblTwelve As Label
    Friend WithEvents lblAboutUs As Label
    Friend WithEvents picAbout As PictureBox
End Class
