﻿Public Class frmOrder
    'declaring constants
    Const decCLASSIC As Decimal = 54.49D
    Const decRETRO As Decimal = 49.5D
    Const decVINTAGE As Decimal = 44.99D
    Private Sub cmbShoeType_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbShoeType.SelectedIndexChanged
        'setting which picture will appear
        If cmbShoeType.SelectedItem = "Classic" Then
            picClassic.Visible = True
            picRetro.Visible = False
            picVintage.Visible = False
            decSubTotal = decCLASSIC
        ElseIf cmbShoeType.SelectedItem = "Retro" Then
            picRetro.Visible = True
            picClassic.Visible = False
            picVintage.Visible = False
            decSubTotal = decRETRO
        ElseIf cmbShoeType.SelectedItem = "Vintage" Then
            picVintage.Visible = True
            picRetro.Visible = False
            picClassic.Visible = False
            lblHeel.Visible = False
            decSubTotal = decVINTAGE
        End If
    End Sub

    Private Sub btnBack_Click(sender As Object, e As EventArgs) Handles btnBack.Click
        'brings customer back to their account page
        Me.Close()
        frmAccount.Show()
    End Sub

    Private Sub btnBrowse_Click(sender As Object, e As EventArgs) Handles btnBrowse.Click
        'Showing logo preview in picture box 
        'some sample images in the IS1111 folder
        'ref https://www.vbtutor.net/vb2017/vb2017_lesson7.html 
        If OFGSelectImage.ShowDialog = DialogResult.OK Then
            picLogo.Image = Image.FromFile(OFGSelectImage.FileName)
        End If
        btnClear.Show()
        picLogo.Show()
    End Sub

    Private Sub cmbQuarter_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbQuarter.SelectedIndexChanged
        'showing the different colours and calculating price of the quarter
        If cmbQuarter.SelectedItem = "White" Then
            picWhite.Show()
            picRed.Hide()
            picOrange.Hide()
            picYellow.Hide()
            picPink.Hide()
            picPurple.Hide()
            picBlue.Hide()
            picGreen.Hide()
            picBrown.Hide()
            picBlack.Hide()
            picGrey.Hide()
            decQuarter = 0D
        ElseIf cmbQuarter.SelectedItem = "Red" Then
            picRed.Show()
            picWhite.Hide()
            picOrange.Hide()
            picYellow.Hide()
            picPink.Hide()
            picPurple.Hide()
            picBlue.Hide()
            picGreen.Hide()
            picBrown.Hide()
            picBlack.Hide()
            picGrey.Hide()
            decQuarter = 8.99D
        ElseIf cmbQuarter.SelectedItem = "Orange" Then
            picOrange.Show()
            picRed.Hide()
            picWhite.Hide()
            picYellow.Hide()
            picPink.Hide()
            picPurple.Hide()
            picBlue.Hide()
            picGreen.Hide()
            picBrown.Hide()
            picBlack.Hide()
            picGrey.Hide()
            decQuarter = 8.99D
        ElseIf cmbQuarter.SelectedItem = "Yellow" Then
            picYellow.Show()
            picRed.Hide()
            picWhite.Hide()
            picOrange.Hide()
            picPink.Hide()
            picPurple.Hide()
            picBlue.Hide()
            picGreen.Hide()
            picBrown.Hide()
            picBlack.Hide()
            picGrey.Hide()
            decQuarter = 8.99D
        ElseIf cmbQuarter.SelectedItem = "Pink" Then
            picPink.Show()
            picRed.Hide()
            picWhite.Hide()
            picYellow.Hide()
            picOrange.Hide()
            picPurple.Hide()
            picBlue.Hide()
            picGreen.Hide()
            picBrown.Hide()
            picBlack.Hide()
            picGrey.Hide()
            decQuarter = 8.99D
        ElseIf cmbQuarter.SelectedItem = "Purple" Then
            picPurple.Show()
            picRed.Hide()
            picWhite.Hide()
            picYellow.Hide()
            picPink.Hide()
            picOrange.Hide()
            picBlue.Hide()
            picGreen.Hide()
            picBrown.Hide()
            picBlack.Hide()
            picGrey.Hide()
            decQuarter = 8.99D
        ElseIf cmbQuarter.SelectedItem = "Blue" Then
            picBlue.Show()
            picRed.Hide()
            picWhite.Hide()
            picYellow.Hide()
            picPink.Hide()
            picPurple.Hide()
            picOrange.Hide()
            picGreen.Hide()
            picBrown.Hide()
            picBlack.Hide()
            picGrey.Hide()
            decQuarter = 8.99D
        ElseIf cmbQuarter.SelectedItem = "Green" Then
            picGreen.Show()
            picRed.Hide()
            picWhite.Hide()
            picYellow.Hide()
            picPink.Hide()
            picPurple.Hide()
            picBlue.Hide()
            picOrange.Hide()
            picBrown.Hide()
            picBlack.Hide()
            picGrey.Hide()
            decQuarter = 8.99D
        ElseIf cmbQuarter.SelectedItem = "Brown" Then
            picBrown.Show()
            picRed.Hide()
            picWhite.Hide()
            picYellow.Hide()
            picPink.Hide()
            picPurple.Hide()
            picBlue.Hide()
            picGreen.Hide()
            picOrange.Hide()
            picBlack.Hide()
            picGrey.Hide()
            decQuarter = 8.99D
        ElseIf cmbQuarter.SelectedItem = "Black" Then
            picBlack.Show()
            picRed.Hide()
            picWhite.Hide()
            picYellow.Hide()
            picPink.Hide()
            picPurple.Hide()
            picBlue.Hide()
            picGreen.Hide()
            picBrown.Hide()
            picOrange.Hide()
            picGrey.Hide()
            decQuarter = 8.99D
        ElseIf cmbQuarter.SelectedItem = "Grey" Then
            picGrey.Show()
            picRed.Hide()
            picWhite.Hide()
            picYellow.Hide()
            picPink.Hide()
            picPurple.Hide()
            picBlue.Hide()
            picGreen.Hide()
            picBrown.Hide()
            picBlack.Hide()
            picOrange.Hide()
            decQuarter = 8.99D
        End If
    End Sub

    Private Sub cmbLaces_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbLaces.SelectedIndexChanged
        'calculating the price of the laces
        If cmbLaces.SelectedItem = "White" Then
            decLaces = 0D
        Else
            decLaces = 4D
        End If
    End Sub

    Private Sub cmbVamp_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbVamp.SelectedIndexChanged
        'calculating the price of the vamp
        If cmbVamp.SelectedItem = "White" Then
            decVamp = 0D
        Else
            decVamp = 14.99D
        End If
    End Sub

    Private Sub cmbEyestay_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbEyestay.SelectedIndexChanged
        'calcuating the price of the eye stay
        If cmbEyestay.SelectedItem = "White" Then
            decEye = 0D
        Else
            decEye = 5D
        End If
    End Sub

    Private Sub cmbHeel_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbHeel.SelectedIndexChanged
        'calculating the price of the heel tab
        If cmbHeel.SelectedItem = "White" Then
            decHeel = 0D
        Else
            decHeel = 4.99D
        End If
    End Sub

    Private Sub cmbBack_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbBack.SelectedIndexChanged
        'calculating the price of back tab
        If cmbBack.SelectedItem = "White" Then
            decBack = 0D
        Else
            decBack = 6.49D
        End If
    End Sub

    Private Sub picLogo_Click(sender As Object, e As EventArgs) Handles picLogo.Click
        'calculating the price of the logo
        If picLogo.ImageLocation = "" Then
            decLogo = 0D
        Else
            decLogo = Math.Round(decCustom * 0.18, 2)

        End If
    End Sub

    Private Sub txtText_TextChanged(sender As Object, e As EventArgs) Handles txtText.TextChanged
        'Calculating the price of the text
        If txtText.Text = "" Then
            decText = 0D
            decExtra = 0D
        ElseIf Len(txtText.Text) <= 10 Then
            decText = 0.45D
            decExtra = 0D
        ElseIf Len(txtText.Text) > 10 Then
            decText = 0.45D
            decExtra = (Len(txtText.Text) - 10) * 0.05
        End If
    End Sub

    Private Sub nudQuantity_ValueChanged(sender As Object, e As EventArgs) Handles nudQuantity.ValueChanged
        'setting variable equal to number selected
        dblQuantity = CDbl(nudQuantity.Value)
    End Sub

    Private Sub btnPayment_Click(sender As Object, e As EventArgs) Handles btnPayment.Click
        'validating the form and calculating total
        If cmbShoeType.SelectedItem = "" Then
            MessageBox.Show("Please Select a Shoe Type", "Shoes Ltd.",
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Error)
        ElseIf cmbQuarter.SelectedItem = "" Then
            MessageBox.Show("Please Select a Colour for the Quarter", "Shoes Ltd.",
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Error)
        ElseIf cmbVamp.SelectedItem = "" Then
            MessageBox.Show("Please Select a Colour for the Vamp", "Shoes Ltd.",
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Error)
        ElseIf cmbLaces.SelectedItem = "" Then
            MessageBox.Show("Please Select a Colour for the Laces", "Shoes Ltd.",
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Error)
        ElseIf cmbEyestay.SelectedItem = "" Then
            MessageBox.Show("Please Select a Colour for the Eyestay", "Shoes Ltd.",
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Error)
        ElseIf cmbHeel.SelectedItem = "" Then
            MessageBox.Show("Please Select a Colour for the Heel Tab", "Shoes Ltd.",
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Error)
        ElseIf cmbBack.SelectedItem = "" Then
            MessageBox.Show("Please Select a Colour for the Back Counter", "Shoes Ltd.",
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Error)
        ElseIf cmbSize.SelectedItem = "" Then
            MessageBox.Show("Please Select a Shoe Size", "Shoes Ltd.",
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Error)
        ElseIf nudQuantity.Value < 1 Then
            MessageBox.Show("Please Select a Quantity", "Shoes Ltd.",
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Error)
        Else
            decCustom = decQuarter + decVamp + decEye + decHeel + decBack _
                + decText + decExtra

            decTotal = decSubTotal + decCustom + decLaces + decLogo
            decVat = Math.Round((decTotal / 2) * 0.23, 2)
            decGrandTotal = decTotal + decVat
            decOverallTotal = (decGrandTotal - decDiscount) * dblQuantity
            'brings customer to payment page
            Me.Hide()
            frmPayment.Show()
        End If
    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        'clears the logo/image selected
        Dim DialogResult As DialogResult
        DialogResult = MessageBox.Show("Are you sure you want to remove the image?", "Shoes Ltd.",
                                       MessageBoxButtons.YesNo,
                                       MessageBoxIcon.Question,
                                       MessageBoxDefaultButton.Button2)
        If DialogResult = DialogResult.Yes Then
            picLogo.Image = Nothing
        End If
    End Sub

    Private Sub btnApply_Click(sender As Object, e As EventArgs) Handles btnApply.Click
        'a discount code of 15% will be applied if the customer enters the word 'GET15'
        txtDiscount.Text = txtDiscount.Text.ToUpper
        If txtDiscount.Text = "GET15" Then
            decDiscount = Math.Round(decGrandTotal * 0.15, 2)
            MessageBox.Show("Discount of 15% has been applied!", "Shoes Ltd.",
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Exclamation)
        Else decDiscount = 0
            MessageBox.Show("Invaild Code. Please try again.", "Shoes Ltd.",
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Error)
        End If
    End Sub

    Private Sub MensToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles MensToolStripMenuItem.Click
        'refreshes the page
        Dim DialogResult As DialogResult
        DialogResult = MessageBox.Show("Are you sure you want to leave the page? Your order will be lost.", "Shoes Ltd.",
                                   MessageBoxButtons.YesNo,
                                   MessageBoxIcon.Question,
                                   MessageBoxDefaultButton.Button2)
        If DialogResult = DialogResult.Yes Then
            Me.Refresh()
        End If
    End Sub

    Private Sub LogoutToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles LogoutToolStripMenuItem.Click
        'logs user out and brings back to login page
        Dim DialogResult As DialogResult
        DialogResult = MessageBox.Show("Are you sure you want to logout?", "Shoes Ltd.",
                                   MessageBoxButtons.YesNo,
                                   MessageBoxIcon.Question,
                                   MessageBoxDefaultButton.Button2)
        If DialogResult = DialogResult.Yes Then
            Me.Close()
            frmCustomer.Show()
        End If
    End Sub

    Private Sub WomensToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles WomensToolStripMenuItem.Click
        'refreshes the page
        Dim DialogResult As DialogResult
        DialogResult = MessageBox.Show("Are you sure you want to leave the age? Your order will be lost.", "Shoes Ltd.",
                                   MessageBoxButtons.YesNo,
                                   MessageBoxIcon.Question,
                                   MessageBoxDefaultButton.Button2)
        If DialogResult = DialogResult.Yes Then
            Me.Refresh()
        End If
    End Sub

    Private Sub ContactUsToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ContactUsToolStripMenuItem.Click
        'brings user to About us form
        Dim DialogResult As DialogResult
        DialogResult = MessageBox.Show("Are you sure you want to leave the page? Your order will be lost.", "Shoes Ltd.",
                                   MessageBoxButtons.YesNo,
                                   MessageBoxIcon.Question,
                                   MessageBoxDefaultButton.Button2)
        If DialogResult = DialogResult.Yes Then
            Me.Close()
            frmAboutUs.Show()
        End If
    End Sub

    Private Sub TrackOrderToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles TrackOrderToolStripMenuItem.Click
        'brings customer to track order form
        Dim DialogResult As DialogResult
        DialogResult = MessageBox.Show("Are you sure you want to leave the page? Your order will be lost.", "Shoes Ltd.",
                                   MessageBoxButtons.YesNo,
                                   MessageBoxIcon.Question,
                                   MessageBoxDefaultButton.Button2)
        If DialogResult = DialogResult.Yes Then
            Me.Close()
            frmTrack.Show()
        End If
    End Sub

    Private Sub HelpToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles HelpToolStripMenuItem.Click
        'brings customer to user manual
        Me.Close()
        frmUserManual.Show()
    End Sub
End Class