﻿Public Class frmCustomer
    Private Sub frmCustomer_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'IS1111DataSet1.tblCustomer' table. You can move, or remove it, as needed.
        Me.TblCustomerTableAdapter.Fill(Me.IS1111DataSet1.tblCustomer)

    End Sub
    Private Sub btnBack_Click(sender As Object, e As EventArgs) Handles btnBack.Click
        'brings the user back to the start up page 
        Me.Hide()
        frmStartPage.Show()
    End Sub

    Private Sub btnCreate_Click(sender As Object, e As EventArgs) Handles btnCreate.Click
        'validating the form
        strUser = txtUser.Text
        Dim intMinLen As Integer = 14
        Dim intMin As Integer = 10
        Dim intPassMin As Integer = 8
        Dim intPassMax As Integer = 20
        If txtName.Text = ("") Then
            MessageBox.Show("Please Enter Your Name", "Your Style Ltd.",
                            MessageBoxButtons.OK,
                             MessageBoxIcon.Error)
            txtName.Focus()
        ElseIf txtSurname.Text = ("") Then
            MessageBox.Show("Please Enter your Surname", "Your Style Ltd.",
                            MessageBoxButtons.OK,
                             MessageBoxIcon.Error)
            txtSurname.Focus()
        ElseIf mskDOB.Text = ("  /  /    ") Then
            MessageBox.Show("Please Enter your Date of Birth", "Your Style Ltd.",
            MessageBoxButtons.OK,
            MessageBoxIcon.Error)
            mskDOB.Focus()
        ElseIf Len(mskDOB.Text) < intMin Then
            MessageBox.Show("Please Enter your Date Of Birth in the format MM/DD/YYYY", "Your Style Ltd.",
                                MessageBoxButtons.OK,
                                 MessageBoxIcon.Error)

        ElseIf txtAddress.Text = ("") Then
            MessageBox.Show("Please Enter your Address", "Your Style Ltd.",
                            MessageBoxButtons.OK,
                             MessageBoxIcon.Error)
            txtAddress.Focus()
        ElseIf mskContact.Text = ("(   )    -") Then
            MessageBox.Show("Please Enter your Phone Number", "Your Style Ltd.",
                            MessageBoxButtons.OK,
                             MessageBoxIcon.Error)
            mskContact.Focus()
        ElseIf Len(mskContact.Text) < intMinLen Then
            MessageBox.Show("Phone Number must be 10 digits", "Your Style Ltd.",
                                MessageBoxButtons.OK,
                                 MessageBoxIcon.Error)
        ElseIf txtEmail.Text = ("") Then
            MessageBox.Show("Please Enter your Email Address", "Your Style Ltd.",
                            MessageBoxButtons.OK,
                             MessageBoxIcon.Error)
            txtEmail.Focus()
        ElseIf txtUser.Text = ("") Then
            MessageBox.Show("Please Enter a Username", "Your Style Ltd.",
                            MessageBoxButtons.OK,
                             MessageBoxIcon.Error)
            txtUser.Focus()
        ElseIf txtPass.Text = "" Then
            MessageBox.Show("Please Enter a Password", "Your Style Ltd.",
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Error)
            txtPass.Focus()
        ElseIf Len(txtPass.Text) < intPassMin Or Len(txtPass.Text) > intPassMax Then
            MessageBox.Show("Password Must Be Between 8 and 20 characters", "Your Style Ltd.",
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Error)
        ElseIf txtConfirm.Text <> txtPass.Text Then
            MessageBox.Show("Passwords don't match", "Your Style Ltd.",
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Error)
        Else
            ' If all information Is correctly entered Then the customer will be brought
            'to their account page 
            BindingSource1.AddNew()
            Try
                BindingSource1.EndEdit()
                TblCustomerTableAdapter.Update(Me.IS1111DataSet1.tblCustomer)
                MessageBox.Show("Account Successfully Created!", "Your Style Ltd.",
                    MessageBoxButtons.OK)
                Me.Close()
                frmAccount.Show()
            Catch ex As Exception
                MessageBox.Show("Error Creating Account", "Your Style Ltd.",
                MessageBoxButtons.OK,
                MessageBoxIcon.Error)
            End Try
        End If

    End Sub

    Private Sub btnReset_Click(sender As Object, e As EventArgs) Handles btnReset.Click
        'clears the form
        Dim DialogResult As DialogResult
        DialogResult = MessageBox.Show("Clear the form?", "Your Style Ltd.",
                                       MessageBoxButtons.YesNo,
                                       MessageBoxIcon.Question,
                                       MessageBoxDefaultButton.Button2)
        If DialogResult = DialogResult.Yes Then
            txtName.Clear()
            mskDOB.Clear()
            txtAddress.Clear()
            txtSurname.Clear()
            mskContact.Clear()
            txtEmail.Clear()
            txtUser.Clear()
            txtPass.Clear()
            txtName.Focus()
        End If
    End Sub

    Private Sub radExisting_CheckedChanged(sender As Object, e As EventArgs) Handles radExisting.CheckedChanged
        'showing the appropriate group box to the customer
        If radNew.Checked Then
            grbExisting.Visible = False
            grbNew.Visible = True
        Else
            grbExisting.Visible = True
            grbNew.Visible = False
        End If
    End Sub

    Private Sub radNew_CheckedChanged(sender As Object, e As EventArgs) Handles radNew.CheckedChanged
        'showing the appropriate group box to the customer
        If radNew.Checked Then
            grbExisting.Visible = False
            grbNew.Visible = True
        Else
            grbExisting.Visible = True
            grbNew.Visible = False
        End If
    End Sub

    Private Sub txtPassword_TextChanged(sender As Object, e As EventArgs) Handles txtPassword.TextChanged
        'using the password symbol to hide password
        txtPassword.UseSystemPasswordChar = True
    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        'clears the form
        Dim DialogResult As DialogResult
        DialogResult = MessageBox.Show("Clear the form?", "Your Style Ltd.",
                                       MessageBoxButtons.YesNo,
                                       MessageBoxIcon.Question,
                                       MessageBoxDefaultButton.Button2)
        If DialogResult = DialogResult.Yes Then
            txtUsername.Clear()
            txtPassword.Clear()
            txtUsername.Focus()
        End If
    End Sub

    Private Sub btnLogin_Click(sender As Object, e As EventArgs) Handles btnLogin.Click
        'if the login information is correct the user will be brought
        'to their account page
        txtUsername.Text = strUser

        Dim query = From customer In IS1111DataSet1.tblCustomer
                    Where customer.IsUsernameNull = strUser And customer.IsPasswordNull = txtPassword.Text
                    Select customer.Customer_ID, customer.First_Name, customer.Surname, customer.Address, customer.Phone_Number, customer.Email

        If query.Count > 0 Then
            frmAccount.Show()
            Me.Close()
        Else
            MessageBox.Show("Incorrect Username or Password. Please try again.", "Your Style Ltd.",
                           MessageBoxButtons.OK,
                           MessageBoxIcon.Error)
            txtUsername.Clear()
            txtPassword.Clear()
            txtUsername.Focus()
        End If


    End Sub

End Class
