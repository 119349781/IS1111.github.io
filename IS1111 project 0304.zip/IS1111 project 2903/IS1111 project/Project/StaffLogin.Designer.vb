﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmStaffLogin
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.btnLogin = New System.Windows.Forms.Button()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.btnNewUser = New System.Windows.Forms.Button()
        Me.btnBack = New System.Windows.Forms.Button()
        Me.gbxLogin = New System.Windows.Forms.GroupBox()
        Me.lblPassword = New System.Windows.Forms.Label()
        Me.lblUsername = New System.Windows.Forms.Label()
        Me.txtPassword = New System.Windows.Forms.TextBox()
        Me.txtUsername = New System.Windows.Forms.TextBox()
        Me.rdoLogin = New System.Windows.Forms.RadioButton()
        Me.rdoAddUser = New System.Windows.Forms.RadioButton()
        Me.gbxAddUser = New System.Windows.Forms.GroupBox()
        Me.btnClearUser = New System.Windows.Forms.Button()
        Me.lblConfirm = New System.Windows.Forms.Label()
        Me.lblPasswordNew = New System.Windows.Forms.Label()
        Me.lblUsernameNew = New System.Windows.Forms.Label()
        Me.txtConfirm = New System.Windows.Forms.TextBox()
        Me.txtPasswordNew = New System.Windows.Forms.TextBox()
        Me.txtUsernameNew = New System.Windows.Forms.TextBox()
        Me.BindingSource1 = New System.Windows.Forms.BindingSource(Me.components)
        Me.StaffLoginDataSet = New Project.StaffLoginDataSet()
        Me.StaffLoginTableAdapter = New Project.StaffLoginDataSetTableAdapters.StaffLoginTableAdapter()
        Me.btnView = New System.Windows.Forms.Button()
        Me.gbxLogin.SuspendLayout()
        Me.gbxAddUser.SuspendLayout()
        CType(Me.BindingSource1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.StaffLoginDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'btnLogin
        '
        Me.btnLogin.Location = New System.Drawing.Point(27, 369)
        Me.btnLogin.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.btnLogin.Name = "btnLogin"
        Me.btnLogin.Size = New System.Drawing.Size(112, 35)
        Me.btnLogin.TabIndex = 0
        Me.btnLogin.Text = "L&ogin"
        Me.btnLogin.UseVisualStyleBackColor = True
        '
        'btnClear
        '
        Me.btnClear.ForeColor = System.Drawing.Color.Red
        Me.btnClear.Location = New System.Drawing.Point(228, 369)
        Me.btnClear.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(112, 35)
        Me.btnClear.TabIndex = 1
        Me.btnClear.Text = "&Clear"
        Me.btnClear.UseVisualStyleBackColor = True
        '
        'btnNewUser
        '
        Me.btnNewUser.Location = New System.Drawing.Point(34, 369)
        Me.btnNewUser.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.btnNewUser.Name = "btnNewUser"
        Me.btnNewUser.Size = New System.Drawing.Size(112, 35)
        Me.btnNewUser.TabIndex = 2
        Me.btnNewUser.Text = "Add &User"
        Me.btnNewUser.UseVisualStyleBackColor = True
        '
        'btnBack
        '
        Me.btnBack.ForeColor = System.Drawing.Color.Red
        Me.btnBack.Location = New System.Drawing.Point(56, 638)
        Me.btnBack.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.btnBack.Name = "btnBack"
        Me.btnBack.Size = New System.Drawing.Size(112, 35)
        Me.btnBack.TabIndex = 3
        Me.btnBack.Text = "&Back"
        Me.btnBack.UseVisualStyleBackColor = True
        '
        'gbxLogin
        '
        Me.gbxLogin.Controls.Add(Me.lblPassword)
        Me.gbxLogin.Controls.Add(Me.lblUsername)
        Me.gbxLogin.Controls.Add(Me.txtPassword)
        Me.gbxLogin.Controls.Add(Me.txtUsername)
        Me.gbxLogin.Controls.Add(Me.btnLogin)
        Me.gbxLogin.Controls.Add(Me.btnClear)
        Me.gbxLogin.Location = New System.Drawing.Point(120, 148)
        Me.gbxLogin.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.gbxLogin.Name = "gbxLogin"
        Me.gbxLogin.Padding = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.gbxLogin.Size = New System.Drawing.Size(370, 437)
        Me.gbxLogin.TabIndex = 4
        Me.gbxLogin.TabStop = False
        Me.gbxLogin.Text = "Login"
        Me.gbxLogin.Visible = False
        '
        'lblPassword
        '
        Me.lblPassword.AutoSize = True
        Me.lblPassword.Location = New System.Drawing.Point(27, 232)
        Me.lblPassword.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblPassword.Name = "lblPassword"
        Me.lblPassword.Size = New System.Drawing.Size(82, 20)
        Me.lblPassword.TabIndex = 5
        Me.lblPassword.Text = "Password:"
        '
        'lblUsername
        '
        Me.lblUsername.AutoSize = True
        Me.lblUsername.Location = New System.Drawing.Point(27, 109)
        Me.lblUsername.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblUsername.Name = "lblUsername"
        Me.lblUsername.Size = New System.Drawing.Size(91, 20)
        Me.lblUsername.TabIndex = 4
        Me.lblUsername.Text = "Username: "
        '
        'txtPassword
        '
        Me.txtPassword.Location = New System.Drawing.Point(172, 228)
        Me.txtPassword.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.txtPassword.Name = "txtPassword"
        Me.txtPassword.Size = New System.Drawing.Size(148, 26)
        Me.txtPassword.TabIndex = 3
        '
        'txtUsername
        '
        Me.txtUsername.Location = New System.Drawing.Point(172, 100)
        Me.txtUsername.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.txtUsername.Name = "txtUsername"
        Me.txtUsername.Size = New System.Drawing.Size(148, 26)
        Me.txtUsername.TabIndex = 2
        '
        'rdoLogin
        '
        Me.rdoLogin.AutoSize = True
        Me.rdoLogin.Location = New System.Drawing.Point(160, 69)
        Me.rdoLogin.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.rdoLogin.Name = "rdoLogin"
        Me.rdoLogin.Size = New System.Drawing.Size(73, 24)
        Me.rdoLogin.TabIndex = 5
        Me.rdoLogin.TabStop = True
        Me.rdoLogin.Text = "&Login"
        Me.rdoLogin.UseVisualStyleBackColor = True
        '
        'rdoAddUser
        '
        Me.rdoAddUser.AutoSize = True
        Me.rdoAddUser.Location = New System.Drawing.Point(813, 69)
        Me.rdoAddUser.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.rdoAddUser.Name = "rdoAddUser"
        Me.rdoAddUser.Size = New System.Drawing.Size(101, 24)
        Me.rdoAddUser.TabIndex = 6
        Me.rdoAddUser.TabStop = True
        Me.rdoAddUser.Text = "&Add User"
        Me.rdoAddUser.UseVisualStyleBackColor = True
        '
        'gbxAddUser
        '
        Me.gbxAddUser.Controls.Add(Me.btnClearUser)
        Me.gbxAddUser.Controls.Add(Me.lblConfirm)
        Me.gbxAddUser.Controls.Add(Me.lblPasswordNew)
        Me.gbxAddUser.Controls.Add(Me.lblUsernameNew)
        Me.gbxAddUser.Controls.Add(Me.txtConfirm)
        Me.gbxAddUser.Controls.Add(Me.txtPasswordNew)
        Me.gbxAddUser.Controls.Add(Me.txtUsernameNew)
        Me.gbxAddUser.Controls.Add(Me.btnNewUser)
        Me.gbxAddUser.Location = New System.Drawing.Point(640, 148)
        Me.gbxAddUser.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.gbxAddUser.Name = "gbxAddUser"
        Me.gbxAddUser.Padding = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.gbxAddUser.Size = New System.Drawing.Size(414, 437)
        Me.gbxAddUser.TabIndex = 7
        Me.gbxAddUser.TabStop = False
        Me.gbxAddUser.Text = "Add User"
        Me.gbxAddUser.Visible = False
        '
        'btnClearUser
        '
        Me.btnClearUser.BackColor = System.Drawing.SystemColors.Control
        Me.btnClearUser.ForeColor = System.Drawing.Color.Red
        Me.btnClearUser.Location = New System.Drawing.Point(228, 369)
        Me.btnClearUser.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.btnClearUser.Name = "btnClearUser"
        Me.btnClearUser.Size = New System.Drawing.Size(112, 35)
        Me.btnClearUser.TabIndex = 9
        Me.btnClearUser.Text = "Clea&r"
        Me.btnClearUser.UseVisualStyleBackColor = False
        '
        'lblConfirm
        '
        Me.lblConfirm.AutoSize = True
        Me.lblConfirm.Location = New System.Drawing.Point(30, 291)
        Me.lblConfirm.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblConfirm.Name = "lblConfirm"
        Me.lblConfirm.Size = New System.Drawing.Size(145, 20)
        Me.lblConfirm.TabIndex = 8
        Me.lblConfirm.Text = "Confirm Password: "
        '
        'lblPasswordNew
        '
        Me.lblPasswordNew.AutoSize = True
        Me.lblPasswordNew.Location = New System.Drawing.Point(30, 195)
        Me.lblPasswordNew.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblPasswordNew.Name = "lblPasswordNew"
        Me.lblPasswordNew.Size = New System.Drawing.Size(82, 20)
        Me.lblPasswordNew.TabIndex = 7
        Me.lblPasswordNew.Text = "Password:"
        '
        'lblUsernameNew
        '
        Me.lblUsernameNew.AutoSize = True
        Me.lblUsernameNew.Location = New System.Drawing.Point(30, 86)
        Me.lblUsernameNew.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblUsernameNew.Name = "lblUsernameNew"
        Me.lblUsernameNew.Size = New System.Drawing.Size(91, 20)
        Me.lblUsernameNew.TabIndex = 6
        Me.lblUsernameNew.Text = "Username: "
        '
        'txtConfirm
        '
        Me.txtConfirm.Location = New System.Drawing.Point(202, 280)
        Me.txtConfirm.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.txtConfirm.Name = "txtConfirm"
        Me.txtConfirm.Size = New System.Drawing.Size(148, 26)
        Me.txtConfirm.TabIndex = 5
        '
        'txtPasswordNew
        '
        Me.txtPasswordNew.Location = New System.Drawing.Point(202, 191)
        Me.txtPasswordNew.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.txtPasswordNew.Name = "txtPasswordNew"
        Me.txtPasswordNew.Size = New System.Drawing.Size(148, 26)
        Me.txtPasswordNew.TabIndex = 4
        '
        'txtUsernameNew
        '
        Me.txtUsernameNew.Location = New System.Drawing.Point(202, 82)
        Me.txtUsernameNew.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.txtUsernameNew.Name = "txtUsernameNew"
        Me.txtUsernameNew.Size = New System.Drawing.Size(148, 26)
        Me.txtUsernameNew.TabIndex = 3
        '
        'BindingSource1
        '
        Me.BindingSource1.DataMember = "StaffLogin"
        Me.BindingSource1.DataSource = Me.StaffLoginDataSet
        '
        'StaffLoginDataSet
        '
        Me.StaffLoginDataSet.DataSetName = "StaffLoginDataSet"
        Me.StaffLoginDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'StaffLoginTableAdapter
        '
        Me.StaffLoginTableAdapter.ClearBeforeFill = True
        '
        'btnView
        '
        Me.btnView.Location = New System.Drawing.Point(868, 637)
        Me.btnView.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.btnView.Name = "btnView"
        Me.btnView.Size = New System.Drawing.Size(184, 35)
        Me.btnView.TabIndex = 8
        Me.btnView.Text = "&View accounts"
        Me.btnView.UseVisualStyleBackColor = True
        '
        'frmStaffLogin
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1200, 692)
        Me.Controls.Add(Me.btnView)
        Me.Controls.Add(Me.gbxAddUser)
        Me.Controls.Add(Me.rdoAddUser)
        Me.Controls.Add(Me.rdoLogin)
        Me.Controls.Add(Me.gbxLogin)
        Me.Controls.Add(Me.btnBack)
        Me.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Name = "frmStaffLogin"
        Me.Text = "Staff Login"
        Me.gbxLogin.ResumeLayout(False)
        Me.gbxLogin.PerformLayout()
        Me.gbxAddUser.ResumeLayout(False)
        Me.gbxAddUser.PerformLayout()
        CType(Me.BindingSource1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.StaffLoginDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btnLogin As Button
    Friend WithEvents btnClear As Button
    Friend WithEvents btnNewUser As Button
    Friend WithEvents btnBack As Button
    Friend WithEvents gbxLogin As GroupBox
    Friend WithEvents lblPassword As Label
    Friend WithEvents lblUsername As Label
    Friend WithEvents txtPassword As TextBox
    Friend WithEvents txtUsername As TextBox
    Friend WithEvents rdoLogin As RadioButton
    Friend WithEvents rdoAddUser As RadioButton
    Friend WithEvents gbxAddUser As GroupBox
    Friend WithEvents btnClearUser As Button
    Friend WithEvents lblConfirm As Label
    Friend WithEvents lblPasswordNew As Label
    Friend WithEvents lblUsernameNew As Label
    Friend WithEvents txtConfirm As TextBox
    Friend WithEvents txtPasswordNew As TextBox
    Friend WithEvents txtUsernameNew As TextBox
    Friend WithEvents BindingSource1 As BindingSource
    Friend WithEvents StaffLoginDataSet As StaffLoginDataSet
    Friend WithEvents StaffLoginTableAdapter As StaffLoginDataSetTableAdapters.StaffLoginTableAdapter
    Friend WithEvents btnView As Button
End Class
