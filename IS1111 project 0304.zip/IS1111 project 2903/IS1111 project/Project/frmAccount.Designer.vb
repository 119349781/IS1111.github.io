﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmAccount
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.ShopToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MensToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.WomensShoesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TrackOrderToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ContactUsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.LogoutToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.lblHello = New System.Windows.Forms.Label()
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'MenuStrip1
        '
        Me.MenuStrip1.ImageScalingSize = New System.Drawing.Size(24, 24)
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ShopToolStripMenuItem, Me.TrackOrderToolStripMenuItem, Me.ContactUsToolStripMenuItem, Me.LogoutToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(800, 33)
        Me.MenuStrip1.TabIndex = 3
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'ShopToolStripMenuItem
        '
        Me.ShopToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.MensToolStripMenuItem, Me.WomensShoesToolStripMenuItem})
        Me.ShopToolStripMenuItem.Name = "ShopToolStripMenuItem"
        Me.ShopToolStripMenuItem.Size = New System.Drawing.Size(66, 29)
        Me.ShopToolStripMenuItem.Text = "Shop"
        '
        'MensToolStripMenuItem
        '
        Me.MensToolStripMenuItem.Name = "MensToolStripMenuItem"
        Me.MensToolStripMenuItem.Size = New System.Drawing.Size(219, 30)
        Me.MensToolStripMenuItem.Text = "Mens Shoes"
        '
        'WomensShoesToolStripMenuItem
        '
        Me.WomensShoesToolStripMenuItem.Name = "WomensShoesToolStripMenuItem"
        Me.WomensShoesToolStripMenuItem.Size = New System.Drawing.Size(219, 30)
        Me.WomensShoesToolStripMenuItem.Text = "Womens Shoes"
        '
        'TrackOrderToolStripMenuItem
        '
        Me.TrackOrderToolStripMenuItem.Name = "TrackOrderToolStripMenuItem"
        Me.TrackOrderToolStripMenuItem.Size = New System.Drawing.Size(114, 29)
        Me.TrackOrderToolStripMenuItem.Text = "Track Order"
        '
        'ContactUsToolStripMenuItem
        '
        Me.ContactUsToolStripMenuItem.Name = "ContactUsToolStripMenuItem"
        Me.ContactUsToolStripMenuItem.Size = New System.Drawing.Size(110, 29)
        Me.ContactUsToolStripMenuItem.Text = "Contact Us"
        '
        'LogoutToolStripMenuItem
        '
        Me.LogoutToolStripMenuItem.Name = "LogoutToolStripMenuItem"
        Me.LogoutToolStripMenuItem.Size = New System.Drawing.Size(81, 29)
        Me.LogoutToolStripMenuItem.Text = "Logout"
        '
        'lblHello
        '
        Me.lblHello.AutoSize = True
        Me.lblHello.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblHello.Location = New System.Drawing.Point(77, 70)
        Me.lblHello.Name = "lblHello"
        Me.lblHello.Size = New System.Drawing.Size(0, 46)
        Me.lblHello.TabIndex = 4
        '
        'frmAccount
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.lblHello)
        Me.Controls.Add(Me.MenuStrip1)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "frmAccount"
        Me.Text = "Account"
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents ShopToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents MensToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents WomensShoesToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents TrackOrderToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ContactUsToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents LogoutToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents lblHello As Label
End Class
