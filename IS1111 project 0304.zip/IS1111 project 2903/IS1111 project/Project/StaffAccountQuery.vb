﻿Public Class frmStaffAccountQuery
    Private Sub frmStaffAcountQuery_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'StaffAccountsDataSet.StaffLogin' table. You can move, or remove it, as needed.
        Me.StaffLoginTableAdapter.Fill(Me.StaffAccountsDataSet.StaffLogin)

        Dim query = From stafflogin In StaffAccountsDataSet.StaffLogin
                    Order By stafflogin.Username Ascending
                    Select stafflogin.Username


        lstAccounts.DataSource = query.ToList

    End Sub

    Private Sub btnBack_Click(sender As Object, e As EventArgs) Handles btnBack.Click
        'Closing the current form and opening frmStaffLogin when btnBack is clicked
        Me.Hide()
        frmStaffLogin.Show()
    End Sub

End Class