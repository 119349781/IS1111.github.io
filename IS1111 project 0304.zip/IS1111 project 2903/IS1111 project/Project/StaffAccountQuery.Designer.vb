﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmStaffAccountQuery
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.btnBack = New System.Windows.Forms.Button()
        Me.lstAccounts = New System.Windows.Forms.ListBox()
        Me.StaffLoginTableAdapter = New Project.StaffAccountsDataSetTableAdapters.StaffLoginTableAdapter()
        Me.StaffAccountsDataSet = New Project.StaffAccountsDataSet()
        Me.BindingSource1 = New System.Windows.Forms.BindingSource(Me.components)
        CType(Me.StaffAccountsDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.BindingSource1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'btnBack
        '
        Me.btnBack.ForeColor = System.Drawing.Color.Red
        Me.btnBack.Location = New System.Drawing.Point(41, 395)
        Me.btnBack.Name = "btnBack"
        Me.btnBack.Size = New System.Drawing.Size(75, 23)
        Me.btnBack.TabIndex = 1
        Me.btnBack.Text = "&Back"
        Me.btnBack.UseVisualStyleBackColor = True
        '
        'lstAccounts
        '
        Me.lstAccounts.FormattingEnabled = True
        Me.lstAccounts.Location = New System.Drawing.Point(226, 78)
        Me.lstAccounts.Name = "lstAccounts"
        Me.lstAccounts.Size = New System.Drawing.Size(340, 290)
        Me.lstAccounts.TabIndex = 2
        '
        'StaffLoginTableAdapter
        '
        Me.StaffLoginTableAdapter.ClearBeforeFill = True
        '
        'StaffAccountsDataSet
        '
        Me.StaffAccountsDataSet.DataSetName = "StaffAccountsDataSet"
        Me.StaffAccountsDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'BindingSource1
        '
        Me.BindingSource1.DataMember = "StaffLogin"
        Me.BindingSource1.DataSource = Me.StaffAccountsDataSet
        '
        'frmStaffAccountQuery
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.lstAccounts)
        Me.Controls.Add(Me.btnBack)
        Me.Name = "frmStaffAccountQuery"
        Me.Text = "StaffAccountQuery"
        CType(Me.StaffAccountsDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.BindingSource1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents btnBack As Button
    Friend WithEvents lstAccounts As ListBox
    Friend WithEvents StaffLoginTableAdapter As StaffAccountsDataSetTableAdapters.StaffLoginTableAdapter
    Friend WithEvents StaffAccountsDataSet As StaffAccountsDataSet
    Friend WithEvents BindingSource1 As BindingSource
End Class
