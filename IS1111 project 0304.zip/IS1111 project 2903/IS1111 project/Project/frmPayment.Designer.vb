﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmPayment
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.btnBack = New System.Windows.Forms.Button()
        Me.lblTotal = New System.Windows.Forms.Label()
        Me.txtTotal = New System.Windows.Forms.TextBox()
        Me.lblDetails = New System.Windows.Forms.Label()
        Me.mskCvv = New System.Windows.Forms.MaskedTextBox()
        Me.lblCvv = New System.Windows.Forms.Label()
        Me.mskExpiry = New System.Windows.Forms.MaskedTextBox()
        Me.lblExpiry = New System.Windows.Forms.Label()
        Me.mskNumber = New System.Windows.Forms.MaskedTextBox()
        Me.lblNumber = New System.Windows.Forms.Label()
        Me.txtName = New System.Windows.Forms.TextBox()
        Me.lblName = New System.Windows.Forms.Label()
        Me.btnPay = New System.Windows.Forms.Button()
        Me.lblOrder = New System.Windows.Forms.Label()
        Me.lblCustomer = New System.Windows.Forms.Label()
        Me.lblAddress = New System.Windows.Forms.Label()
        Me.lblContact = New System.Windows.Forms.Label()
        Me.mskPhone = New System.Windows.Forms.MaskedTextBox()
        Me.txtCustomer = New System.Windows.Forms.TextBox()
        Me.txtAddress = New System.Windows.Forms.TextBox()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.ShopToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MensToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.WomensToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TrackOrderToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ContactUsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.LogoutToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'btnBack
        '
        Me.btnBack.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnBack.ForeColor = System.Drawing.Color.Red
        Me.btnBack.Location = New System.Drawing.Point(657, 382)
        Me.btnBack.Name = "btnBack"
        Me.btnBack.Size = New System.Drawing.Size(119, 50)
        Me.btnBack.TabIndex = 24
        Me.btnBack.Text = "&Back"
        Me.btnBack.UseVisualStyleBackColor = True
        '
        'lblTotal
        '
        Me.lblTotal.AutoSize = True
        Me.lblTotal.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTotal.Location = New System.Drawing.Point(183, 60)
        Me.lblTotal.Name = "lblTotal"
        Me.lblTotal.Size = New System.Drawing.Size(95, 36)
        Me.lblTotal.TabIndex = 5
        Me.lblTotal.Text = "Total:"
        '
        'txtTotal
        '
        Me.txtTotal.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtTotal.Location = New System.Drawing.Point(284, 55)
        Me.txtTotal.Name = "txtTotal"
        Me.txtTotal.ReadOnly = True
        Me.txtTotal.Size = New System.Drawing.Size(245, 41)
        Me.txtTotal.TabIndex = 6
        '
        'lblDetails
        '
        Me.lblDetails.AutoSize = True
        Me.lblDetails.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDetails.Location = New System.Drawing.Point(183, 108)
        Me.lblDetails.Name = "lblDetails"
        Me.lblDetails.Size = New System.Drawing.Size(426, 36)
        Me.lblDetails.TabIndex = 7
        Me.lblDetails.Text = "Please Enter Your Card Details"
        '
        'mskCvv
        '
        Me.mskCvv.Location = New System.Drawing.Point(189, 291)
        Me.mskCvv.Mask = "000"
        Me.mskCvv.Name = "mskCvv"
        Me.mskCvv.Size = New System.Drawing.Size(62, 26)
        Me.mskCvv.TabIndex = 19
        '
        'lblCvv
        '
        Me.lblCvv.AutoSize = True
        Me.lblCvv.Location = New System.Drawing.Point(21, 297)
        Me.lblCvv.Name = "lblCvv"
        Me.lblCvv.Size = New System.Drawing.Size(46, 20)
        Me.lblCvv.TabIndex = 18
        Me.lblCvv.Text = "CVV:"
        '
        'mskExpiry
        '
        Me.mskExpiry.Location = New System.Drawing.Point(189, 253)
        Me.mskExpiry.Mask = "00/0000"
        Me.mskExpiry.Name = "mskExpiry"
        Me.mskExpiry.Size = New System.Drawing.Size(94, 26)
        Me.mskExpiry.TabIndex = 17
        '
        'lblExpiry
        '
        Me.lblExpiry.AutoSize = True
        Me.lblExpiry.Location = New System.Drawing.Point(21, 259)
        Me.lblExpiry.Name = "lblExpiry"
        Me.lblExpiry.Size = New System.Drawing.Size(94, 20)
        Me.lblExpiry.TabIndex = 16
        Me.lblExpiry.Text = "Expiry Date:"
        '
        'mskNumber
        '
        Me.mskNumber.Location = New System.Drawing.Point(189, 209)
        Me.mskNumber.Mask = "0000-0000-0000-0000"
        Me.mskNumber.Name = "mskNumber"
        Me.mskNumber.Size = New System.Drawing.Size(176, 26)
        Me.mskNumber.TabIndex = 15
        '
        'lblNumber
        '
        Me.lblNumber.AutoSize = True
        Me.lblNumber.Location = New System.Drawing.Point(21, 215)
        Me.lblNumber.Name = "lblNumber"
        Me.lblNumber.Size = New System.Drawing.Size(107, 20)
        Me.lblNumber.TabIndex = 14
        Me.lblNumber.Text = "Card Number:"
        '
        'txtName
        '
        Me.txtName.Location = New System.Drawing.Point(189, 163)
        Me.txtName.Name = "txtName"
        Me.txtName.Size = New System.Drawing.Size(176, 26)
        Me.txtName.TabIndex = 13
        '
        'lblName
        '
        Me.lblName.AutoSize = True
        Me.lblName.Location = New System.Drawing.Point(21, 169)
        Me.lblName.Name = "lblName"
        Me.lblName.Size = New System.Drawing.Size(158, 20)
        Me.lblName.TabIndex = 12
        Me.lblName.Text = "Name of CardHolder:"
        '
        'btnPay
        '
        Me.btnPay.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnPay.Location = New System.Drawing.Point(655, 253)
        Me.btnPay.Name = "btnPay"
        Me.btnPay.Size = New System.Drawing.Size(121, 51)
        Me.btnPay.TabIndex = 23
        Me.btnPay.Text = "&Pay Now"
        Me.btnPay.UseVisualStyleBackColor = True
        '
        'lblOrder
        '
        Me.lblOrder.AutoSize = True
        Me.lblOrder.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblOrder.Location = New System.Drawing.Point(183, 331)
        Me.lblOrder.Name = "lblOrder"
        Me.lblOrder.Size = New System.Drawing.Size(246, 36)
        Me.lblOrder.TabIndex = 21
        Me.lblOrder.Text = "Order Information"
        '
        'lblCustomer
        '
        Me.lblCustomer.AutoSize = True
        Me.lblCustomer.Location = New System.Drawing.Point(25, 400)
        Me.lblCustomer.Name = "lblCustomer"
        Me.lblCustomer.Size = New System.Drawing.Size(128, 20)
        Me.lblCustomer.TabIndex = 22
        Me.lblCustomer.Text = "Customer Name:"
        '
        'lblAddress
        '
        Me.lblAddress.AutoSize = True
        Me.lblAddress.Location = New System.Drawing.Point(25, 446)
        Me.lblAddress.Name = "lblAddress"
        Me.lblAddress.Size = New System.Drawing.Size(145, 20)
        Me.lblAddress.TabIndex = 23
        Me.lblAddress.Text = "Customer Address:"
        '
        'lblContact
        '
        Me.lblContact.AutoSize = True
        Me.lblContact.Location = New System.Drawing.Point(25, 497)
        Me.lblContact.Name = "lblContact"
        Me.lblContact.Size = New System.Drawing.Size(129, 20)
        Me.lblContact.TabIndex = 24
        Me.lblContact.Text = "Contact Number:"
        '
        'mskPhone
        '
        Me.mskPhone.Location = New System.Drawing.Point(176, 497)
        Me.mskPhone.Mask = "(999) 000-0000"
        Me.mskPhone.Name = "mskPhone"
        Me.mskPhone.Size = New System.Drawing.Size(189, 26)
        Me.mskPhone.TabIndex = 22
        '
        'txtCustomer
        '
        Me.txtCustomer.Location = New System.Drawing.Point(176, 394)
        Me.txtCustomer.Name = "txtCustomer"
        Me.txtCustomer.Size = New System.Drawing.Size(189, 26)
        Me.txtCustomer.TabIndex = 20
        '
        'txtAddress
        '
        Me.txtAddress.Location = New System.Drawing.Point(176, 440)
        Me.txtAddress.Name = "txtAddress"
        Me.txtAddress.Size = New System.Drawing.Size(189, 26)
        Me.txtAddress.TabIndex = 21
        '
        'MenuStrip1
        '
        Me.MenuStrip1.ImageScalingSize = New System.Drawing.Size(24, 24)
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ShopToolStripMenuItem, Me.TrackOrderToolStripMenuItem, Me.ContactUsToolStripMenuItem, Me.LogoutToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(800, 33)
        Me.MenuStrip1.TabIndex = 25
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'ShopToolStripMenuItem
        '
        Me.ShopToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.MensToolStripMenuItem, Me.WomensToolStripMenuItem})
        Me.ShopToolStripMenuItem.Name = "ShopToolStripMenuItem"
        Me.ShopToolStripMenuItem.Size = New System.Drawing.Size(66, 29)
        Me.ShopToolStripMenuItem.Text = "Shop"
        '
        'MensToolStripMenuItem
        '
        Me.MensToolStripMenuItem.Name = "MensToolStripMenuItem"
        Me.MensToolStripMenuItem.Size = New System.Drawing.Size(252, 30)
        Me.MensToolStripMenuItem.Text = "Mens"
        '
        'WomensToolStripMenuItem
        '
        Me.WomensToolStripMenuItem.Name = "WomensToolStripMenuItem"
        Me.WomensToolStripMenuItem.Size = New System.Drawing.Size(252, 30)
        Me.WomensToolStripMenuItem.Text = "Womens"
        '
        'TrackOrderToolStripMenuItem
        '
        Me.TrackOrderToolStripMenuItem.Name = "TrackOrderToolStripMenuItem"
        Me.TrackOrderToolStripMenuItem.Size = New System.Drawing.Size(114, 29)
        Me.TrackOrderToolStripMenuItem.Text = "Track Order"
        '
        'ContactUsToolStripMenuItem
        '
        Me.ContactUsToolStripMenuItem.Name = "ContactUsToolStripMenuItem"
        Me.ContactUsToolStripMenuItem.Size = New System.Drawing.Size(110, 29)
        Me.ContactUsToolStripMenuItem.Text = "Contact Us"
        '
        'LogoutToolStripMenuItem
        '
        Me.LogoutToolStripMenuItem.Name = "LogoutToolStripMenuItem"
        Me.LogoutToolStripMenuItem.Size = New System.Drawing.Size(81, 29)
        Me.LogoutToolStripMenuItem.Text = "Logout"
        '
        'frmPayment
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 613)
        Me.Controls.Add(Me.txtAddress)
        Me.Controls.Add(Me.txtCustomer)
        Me.Controls.Add(Me.mskPhone)
        Me.Controls.Add(Me.lblContact)
        Me.Controls.Add(Me.lblAddress)
        Me.Controls.Add(Me.lblCustomer)
        Me.Controls.Add(Me.lblOrder)
        Me.Controls.Add(Me.mskCvv)
        Me.Controls.Add(Me.lblCvv)
        Me.Controls.Add(Me.mskExpiry)
        Me.Controls.Add(Me.lblExpiry)
        Me.Controls.Add(Me.mskNumber)
        Me.Controls.Add(Me.lblNumber)
        Me.Controls.Add(Me.txtName)
        Me.Controls.Add(Me.lblName)
        Me.Controls.Add(Me.btnPay)
        Me.Controls.Add(Me.lblDetails)
        Me.Controls.Add(Me.txtTotal)
        Me.Controls.Add(Me.lblTotal)
        Me.Controls.Add(Me.btnBack)
        Me.Controls.Add(Me.MenuStrip1)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "frmPayment"
        Me.Text = "Payment"
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents btnBack As Button
    Friend WithEvents lblTotal As Label
    Friend WithEvents txtTotal As TextBox
    Friend WithEvents lblDetails As Label
    Friend WithEvents mskCvv As MaskedTextBox
    Friend WithEvents lblCvv As Label
    Friend WithEvents mskExpiry As MaskedTextBox
    Friend WithEvents lblExpiry As Label
    Friend WithEvents mskNumber As MaskedTextBox
    Friend WithEvents lblNumber As Label
    Friend WithEvents txtName As TextBox
    Friend WithEvents lblName As Label
    Friend WithEvents btnPay As Button
    Friend WithEvents lblOrder As Label
    Friend WithEvents lblCustomer As Label
    Friend WithEvents lblAddress As Label
    Friend WithEvents lblContact As Label
    Friend WithEvents mskPhone As MaskedTextBox
    Friend WithEvents txtCustomer As TextBox
    Friend WithEvents txtAddress As TextBox
    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents ShopToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents MensToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents WomensToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents TrackOrderToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ContactUsToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents LogoutToolStripMenuItem As ToolStripMenuItem
End Class
