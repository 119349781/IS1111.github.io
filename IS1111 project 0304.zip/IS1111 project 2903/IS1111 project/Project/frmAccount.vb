﻿Public Class frmAccount

    Private Sub LogoutToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles LogoutToolStripMenuItem.Click
        'brings customer back to login page 
        Dim DialogResult As DialogResult
        DialogResult = MessageBox.Show("Are you sure you want to logout?", "Your Style Ltd.",
                                       MessageBoxButtons.YesNo,
                                       MessageBoxIcon.Question,
                                       MessageBoxDefaultButton.Button2)
        If DialogResult = DialogResult.Yes Then
            Me.Hide()
            frmCustomer.Show()
        End If
    End Sub

    Private Sub MensToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles MensToolStripMenuItem.Click
        'Brings customer to order form
        Me.Hide()
        frmOrder.Show()
    End Sub

    Private Sub WomensShoesToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles WomensShoesToolStripMenuItem.Click
        'Brings customer to order form
        Me.Hide()
        frmOrder.Show()
    End Sub

    Private Sub frmAccount_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'displays a welcome message
        lblHello.Text = ("Hello " & strUser & " !")
    End Sub
End Class