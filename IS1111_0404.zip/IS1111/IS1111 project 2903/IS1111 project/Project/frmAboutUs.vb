﻿Public Class frmAboutUs

    Private Sub MensToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles MensToolStripMenuItem.Click
        'brings customer to order form
        Me.Hide()
        frmOrder.Show()
    End Sub

    Private Sub WomensToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles WomensToolStripMenuItem.Click
        'brings customer to order form
        Me.Hide()
        frmOrder.Show()
    End Sub

    Private Sub TrackOrderToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles TrackOrderToolStripMenuItem.Click
        'brings customer to track order form
        Me.Hide()
        frmTrack.Show()
    End Sub

    Private Sub LogoutToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles LogoutToolStripMenuItem.Click
        'logs user out and brings back to login page
        Dim DialogResult As DialogResult
        DialogResult = MessageBox.Show("Are you sure you want to logout?", "Shoes Ltd.",
                                   MessageBoxButtons.YesNo,
                                   MessageBoxIcon.Question,
                                   MessageBoxDefaultButton.Button2)
        If DialogResult = DialogResult.Yes Then
            Me.Close()
            frmCustomer.Show()
        End If
    End Sub
End Class