﻿Public Class frmConfirmation

    Private Sub MensShoesToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles MensShoesToolStripMenuItem.Click
        'Brings customer to order form
        Me.Close()
        frmOrder.Show()
    End Sub

    Private Sub WomensShoesToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles WomensShoesToolStripMenuItem.Click
        'Brings customer to order form
        Me.Close()
        frmOrder.Show()
    End Sub

    Private Sub LogoutToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles LogoutToolStripMenuItem.Click
        'brings customer back to login page 
        Dim DialogResult As DialogResult
        DialogResult = MessageBox.Show("Are you sure you want to logout?", "Shoes Ltd.",
                                       MessageBoxButtons.YesNo,
                                       MessageBoxIcon.Question,
                                       MessageBoxDefaultButton.Button2)
        If DialogResult = DialogResult.Yes Then
            Me.Close()
            frmCustomer.Show()
        End If
    End Sub

    Private Sub btnReceipt_Click(sender As Object, e As EventArgs) Handles btnReceipt.Click
        'prints off the order receipt
        PrintPreviewDialog1.ShowDialog()
        If DialogResult = DialogResult.Yes Then
            PrintDocument1.Print()
        End If
    End Sub


    Private Sub frmConfirmation_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'TrackOrderDataSet.tblOrders' table. You can move, or remove it, as needed.
        Me.TblOrdersTableAdapter.Fill(Me.TrackOrderDataSet.tblOrders)
        'maximises the form when it loads
        Me.WindowState = FormWindowState.Maximized
        Dim strResult
        If decLogo = 0D Then
            strResult = "No"
        Else
            strResult = "Yes"
        End If

        'receipt shows when the form loads
        txtToday.Text = Today()
        Dim rn As New Random
        txtNumber.Text = rn.Next()
        txtName.Text = strUser
        txtAddr.Text = strAddress
        txtContact.Text = strContact
        txtCustom.Text = frmOrder.cmbShoeType.SelectedItem
        txtPicture.Text = strResult
        txtAnswer.Text = strResult
        txtQuarter.Text = ("Quarter: " & frmOrder.cmbQuarter.SelectedItem)
        txtVamp.Text = ("Vamp: " & frmOrder.cmbVamp.SelectedItem)
        txtEye.Text = ("Eyestay: " & frmOrder.cmbEyestay.SelectedItem)
        txtLaces.Text = ("Laces: " & frmOrder.cmbLaces.SelectedItem)
        txtBack.Text = ("Back Counter: " & frmOrder.cmbBack.SelectedItem)
        txtText.Text = ("Text: " & frmOrder.txtText.Text)
        txtShoeS.Text = frmOrder.cmbSize.SelectedItem
        txtMode.Text = FormatCurrency(decSubTotal)
        txtQuart.Text = FormatCurrency(decQuarter)
        txtVamps.Text = FormatCurrency(decVamp)
        txtEyestay.Text = FormatCurrency(decEye)
        txtLacess.Text = FormatCurrency(decLaces)
        txtCounter.Text = FormatCurrency(decBack)
        txtTexts.Text = FormatCurrency(decText + decExtra)
        txtPic.Text = FormatCurrency(decLogo)
        txtPriceShoe.Text = FormatCurrency(decTotal / 2)
        txtVatat.Text = FormatCurrency(decVat)
        txtTot.Text = FormatCurrency(decGrandTotal)
        txtQuant.Text = dblQuantity
        txtDis.Text = FormatCurrency(decDiscount)
        txtTotAmount.Text = FormatCurrency(decOverallTotal)

        'adding order to database 
        BindingSource1.AddNew()
        Try
            BindingSource1.EndEdit()
            TblOrdersTableAdapter.Update(Me.TrackOrderDataSet.tblOrders)
            MessageBox.Show("Order added to database!", "Shoes Ltd.",
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Exclamation)
        Catch ex As Exception
            MessageBox.Show("Error saving order", "Shoes Ltd.",
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub ContactUsToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ContactUsToolStripMenuItem.Click
        'brings user to Abous Us form
        Me.Close()
        frmAboutUs.Show()
    End Sub

    Private Sub TrackOrsToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles TrackOrsToolStripMenuItem.Click
        'brings customer to track order form
        Me.Hide()
        frmTrack.Show()
    End Sub
End Class