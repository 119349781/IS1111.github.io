﻿Public Class frmManualPg2
    Private Sub btnBack_Click(sender As Object, e As EventArgs) Handles btnBack.Click
        'brings user back first page of user manual
        Me.Hide()
        frmUserManual.Show()
    End Sub
End Class