﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmCustomer
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmCustomer))
        Me.radExisting = New System.Windows.Forms.RadioButton()
        Me.radNew = New System.Windows.Forms.RadioButton()
        Me.grbExisting = New System.Windows.Forms.GroupBox()
        Me.btnLogin = New System.Windows.Forms.Button()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.lblPassword = New System.Windows.Forms.Label()
        Me.lblUsername = New System.Windows.Forms.Label()
        Me.txtPassword = New System.Windows.Forms.TextBox()
        Me.txtUsername = New System.Windows.Forms.TextBox()
        Me.grbNew = New System.Windows.Forms.GroupBox()
        Me.txtSurname = New System.Windows.Forms.TextBox()
        Me.btnReset = New System.Windows.Forms.Button()
        Me.btnCreate = New System.Windows.Forms.Button()
        Me.txtUser = New System.Windows.Forms.TextBox()
        Me.lblUser = New System.Windows.Forms.Label()
        Me.txtCity = New System.Windows.Forms.TextBox()
        Me.lblCity = New System.Windows.Forms.Label()
        Me.lblEmail = New System.Windows.Forms.Label()
        Me.txtEmail = New System.Windows.Forms.TextBox()
        Me.lblPhone = New System.Windows.Forms.Label()
        Me.mskContact = New System.Windows.Forms.MaskedTextBox()
        Me.txtAddress = New System.Windows.Forms.TextBox()
        Me.lblAddress = New System.Windows.Forms.Label()
        Me.mskDOB = New System.Windows.Forms.MaskedTextBox()
        Me.lblDOB = New System.Windows.Forms.Label()
        Me.txtName = New System.Windows.Forms.TextBox()
        Me.lblName = New System.Windows.Forms.Label()
        Me.btnBack = New System.Windows.Forms.Button()
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.BindingSource1 = New System.Windows.Forms.BindingSource(Me.components)
        Me.CustomerDataSet = New Project.CustomerDataSet()
        Me.TblCustomerInfoTableAdapter = New Project.CustomerDataSetTableAdapters.tblCustomerInfoTableAdapter()
        Me.grbExisting.SuspendLayout()
        Me.grbNew.SuspendLayout()
        CType(Me.BindingSource1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.CustomerDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'radExisting
        '
        Me.radExisting.AutoSize = True
        Me.radExisting.BackColor = System.Drawing.Color.Transparent
        Me.radExisting.Location = New System.Drawing.Point(154, 45)
        Me.radExisting.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.radExisting.Name = "radExisting"
        Me.radExisting.Size = New System.Drawing.Size(162, 24)
        Me.radExisting.TabIndex = 0
        Me.radExisting.TabStop = True
        Me.radExisting.Text = "Existing Customer"
        Me.radExisting.UseVisualStyleBackColor = False
        '
        'radNew
        '
        Me.radNew.AutoSize = True
        Me.radNew.BackColor = System.Drawing.Color.Transparent
        Me.radNew.Location = New System.Drawing.Point(558, 45)
        Me.radNew.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.radNew.Name = "radNew"
        Me.radNew.Size = New System.Drawing.Size(138, 24)
        Me.radNew.TabIndex = 1
        Me.radNew.TabStop = True
        Me.radNew.Text = "New Customer"
        Me.radNew.UseVisualStyleBackColor = False
        '
        'grbExisting
        '
        Me.grbExisting.BackColor = System.Drawing.Color.Transparent
        Me.grbExisting.Controls.Add(Me.btnLogin)
        Me.grbExisting.Controls.Add(Me.btnClear)
        Me.grbExisting.Controls.Add(Me.lblPassword)
        Me.grbExisting.Controls.Add(Me.lblUsername)
        Me.grbExisting.Controls.Add(Me.txtPassword)
        Me.grbExisting.Controls.Add(Me.txtUsername)
        Me.grbExisting.Location = New System.Drawing.Point(87, 78)
        Me.grbExisting.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.grbExisting.Name = "grbExisting"
        Me.grbExisting.Padding = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.grbExisting.Size = New System.Drawing.Size(372, 297)
        Me.grbExisting.TabIndex = 2
        Me.grbExisting.TabStop = False
        Me.grbExisting.Text = "Existing Customer"
        Me.grbExisting.Visible = False
        '
        'btnLogin
        '
        Me.btnLogin.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnLogin.ForeColor = System.Drawing.Color.Black
        Me.btnLogin.Location = New System.Drawing.Point(196, 225)
        Me.btnLogin.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.btnLogin.Name = "btnLogin"
        Me.btnLogin.Size = New System.Drawing.Size(112, 35)
        Me.btnLogin.TabIndex = 5
        Me.btnLogin.Text = "&Login"
        Me.btnLogin.UseVisualStyleBackColor = True
        '
        'btnClear
        '
        Me.btnClear.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnClear.ForeColor = System.Drawing.Color.Red
        Me.btnClear.Location = New System.Drawing.Point(34, 225)
        Me.btnClear.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(112, 35)
        Me.btnClear.TabIndex = 4
        Me.btnClear.Text = "&Clear"
        Me.btnClear.UseVisualStyleBackColor = True
        '
        'lblPassword
        '
        Me.lblPassword.AutoSize = True
        Me.lblPassword.Location = New System.Drawing.Point(30, 148)
        Me.lblPassword.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblPassword.Name = "lblPassword"
        Me.lblPassword.Size = New System.Drawing.Size(82, 20)
        Me.lblPassword.TabIndex = 3
        Me.lblPassword.Text = "Password:"
        '
        'lblUsername
        '
        Me.lblUsername.AutoSize = True
        Me.lblUsername.Location = New System.Drawing.Point(27, 63)
        Me.lblUsername.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblUsername.Name = "lblUsername"
        Me.lblUsername.Size = New System.Drawing.Size(87, 20)
        Me.lblUsername.TabIndex = 2
        Me.lblUsername.Text = "Username:"
        '
        'txtPassword
        '
        Me.txtPassword.Location = New System.Drawing.Point(159, 143)
        Me.txtPassword.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.txtPassword.Name = "txtPassword"
        Me.txtPassword.Size = New System.Drawing.Size(148, 26)
        Me.txtPassword.TabIndex = 1
        '
        'txtUsername
        '
        Me.txtUsername.Location = New System.Drawing.Point(159, 52)
        Me.txtUsername.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.txtUsername.Name = "txtUsername"
        Me.txtUsername.Size = New System.Drawing.Size(148, 26)
        Me.txtUsername.TabIndex = 0
        '
        'grbNew
        '
        Me.grbNew.BackColor = System.Drawing.Color.Transparent
        Me.grbNew.Controls.Add(Me.txtSurname)
        Me.grbNew.Controls.Add(Me.btnReset)
        Me.grbNew.Controls.Add(Me.btnCreate)
        Me.grbNew.Controls.Add(Me.txtUser)
        Me.grbNew.Controls.Add(Me.lblUser)
        Me.grbNew.Controls.Add(Me.txtCity)
        Me.grbNew.Controls.Add(Me.lblCity)
        Me.grbNew.Controls.Add(Me.lblEmail)
        Me.grbNew.Controls.Add(Me.txtEmail)
        Me.grbNew.Controls.Add(Me.lblPhone)
        Me.grbNew.Controls.Add(Me.mskContact)
        Me.grbNew.Controls.Add(Me.txtAddress)
        Me.grbNew.Controls.Add(Me.lblAddress)
        Me.grbNew.Controls.Add(Me.mskDOB)
        Me.grbNew.Controls.Add(Me.lblDOB)
        Me.grbNew.Controls.Add(Me.txtName)
        Me.grbNew.Controls.Add(Me.lblName)
        Me.grbNew.Location = New System.Drawing.Point(558, 78)
        Me.grbNew.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.grbNew.Name = "grbNew"
        Me.grbNew.Padding = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.grbNew.Size = New System.Drawing.Size(384, 523)
        Me.grbNew.TabIndex = 3
        Me.grbNew.TabStop = False
        Me.grbNew.Text = "New Customer"
        Me.grbNew.Visible = False
        '
        'txtSurname
        '
        Me.txtSurname.Location = New System.Drawing.Point(166, 83)
        Me.txtSurname.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.txtSurname.Name = "txtSurname"
        Me.txtSurname.Size = New System.Drawing.Size(148, 26)
        Me.txtSurname.TabIndex = 18
        '
        'btnReset
        '
        Me.btnReset.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnReset.ForeColor = System.Drawing.Color.Red
        Me.btnReset.Location = New System.Drawing.Point(12, 423)
        Me.btnReset.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.btnReset.Name = "btnReset"
        Me.btnReset.Size = New System.Drawing.Size(112, 58)
        Me.btnReset.TabIndex = 10
        Me.btnReset.Text = "C&lear"
        Me.btnReset.UseVisualStyleBackColor = True
        '
        'btnCreate
        '
        Me.btnCreate.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCreate.Location = New System.Drawing.Point(202, 421)
        Me.btnCreate.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.btnCreate.Name = "btnCreate"
        Me.btnCreate.Size = New System.Drawing.Size(112, 60)
        Me.btnCreate.TabIndex = 9
        Me.btnCreate.Text = "Create &Account"
        Me.btnCreate.UseVisualStyleBackColor = True
        '
        'txtUser
        '
        Me.txtUser.Location = New System.Drawing.Point(166, 358)
        Me.txtUser.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.txtUser.Name = "txtUser"
        Me.txtUser.Size = New System.Drawing.Size(148, 26)
        Me.txtUser.TabIndex = 8
        Me.ToolTip1.SetToolTip(Me.txtUser, "Username will also be your password!")
        '
        'lblUser
        '
        Me.lblUser.AutoSize = True
        Me.lblUser.Location = New System.Drawing.Point(9, 365)
        Me.lblUser.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblUser.Name = "lblUser"
        Me.lblUser.Size = New System.Drawing.Size(87, 20)
        Me.lblUser.TabIndex = 12
        Me.lblUser.Text = "Username:"
        '
        'txtCity
        '
        Me.txtCity.Location = New System.Drawing.Point(166, 205)
        Me.txtCity.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.txtCity.Name = "txtCity"
        Me.txtCity.Size = New System.Drawing.Size(148, 26)
        Me.txtCity.TabIndex = 5
        '
        'lblCity
        '
        Me.lblCity.AutoSize = True
        Me.lblCity.Location = New System.Drawing.Point(9, 192)
        Me.lblCity.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblCity.Name = "lblCity"
        Me.lblCity.Size = New System.Drawing.Size(89, 20)
        Me.lblCity.TabIndex = 10
        Me.lblCity.Text = "City / Town:"
        '
        'lblEmail
        '
        Me.lblEmail.AutoSize = True
        Me.lblEmail.Location = New System.Drawing.Point(10, 308)
        Me.lblEmail.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblEmail.Name = "lblEmail"
        Me.lblEmail.Size = New System.Drawing.Size(52, 20)
        Me.lblEmail.TabIndex = 9
        Me.lblEmail.Text = "Email:"
        '
        'txtEmail
        '
        Me.txtEmail.Location = New System.Drawing.Point(166, 302)
        Me.txtEmail.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.txtEmail.Name = "txtEmail"
        Me.txtEmail.Size = New System.Drawing.Size(148, 26)
        Me.txtEmail.TabIndex = 7
        '
        'lblPhone
        '
        Me.lblPhone.AutoSize = True
        Me.lblPhone.Location = New System.Drawing.Point(9, 251)
        Me.lblPhone.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblPhone.Name = "lblPhone"
        Me.lblPhone.Size = New System.Drawing.Size(119, 20)
        Me.lblPhone.TabIndex = 7
        Me.lblPhone.Text = "Phone Number:"
        '
        'mskContact
        '
        Me.mskContact.Location = New System.Drawing.Point(166, 245)
        Me.mskContact.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.mskContact.Mask = "(999) 000-0000"
        Me.mskContact.Name = "mskContact"
        Me.mskContact.Size = New System.Drawing.Size(148, 26)
        Me.mskContact.TabIndex = 6
        '
        'txtAddress
        '
        Me.txtAddress.Location = New System.Drawing.Point(166, 165)
        Me.txtAddress.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.txtAddress.Name = "txtAddress"
        Me.txtAddress.Size = New System.Drawing.Size(148, 26)
        Me.txtAddress.TabIndex = 4
        '
        'lblAddress
        '
        Me.lblAddress.AutoSize = True
        Me.lblAddress.Location = New System.Drawing.Point(8, 134)
        Me.lblAddress.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblAddress.Name = "lblAddress"
        Me.lblAddress.Size = New System.Drawing.Size(72, 20)
        Me.lblAddress.TabIndex = 4
        Me.lblAddress.Text = "Address:"
        '
        'mskDOB
        '
        Me.mskDOB.Location = New System.Drawing.Point(166, 123)
        Me.mskDOB.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.mskDOB.Mask = "00/00/0000"
        Me.mskDOB.Name = "mskDOB"
        Me.mskDOB.Size = New System.Drawing.Size(148, 26)
        Me.mskDOB.TabIndex = 3
        Me.mskDOB.ValidatingType = GetType(Date)
        '
        'lblDOB
        '
        Me.lblDOB.AutoSize = True
        Me.lblDOB.Location = New System.Drawing.Point(8, 78)
        Me.lblDOB.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblDOB.Name = "lblDOB"
        Me.lblDOB.Size = New System.Drawing.Size(56, 20)
        Me.lblDOB.TabIndex = 2
        Me.lblDOB.Text = "D.O.B:"
        '
        'txtName
        '
        Me.txtName.Location = New System.Drawing.Point(166, 29)
        Me.txtName.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.txtName.Name = "txtName"
        Me.txtName.Size = New System.Drawing.Size(148, 26)
        Me.txtName.TabIndex = 2
        '
        'lblName
        '
        Me.lblName.AutoSize = True
        Me.lblName.Location = New System.Drawing.Point(10, 31)
        Me.lblName.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblName.Name = "lblName"
        Me.lblName.Size = New System.Drawing.Size(55, 20)
        Me.lblName.TabIndex = 0
        Me.lblName.Text = "Name:"
        '
        'btnBack
        '
        Me.btnBack.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnBack.ForeColor = System.Drawing.Color.FromArgb(CType(CType(245, Byte), Integer), CType(CType(5, Byte), Integer), CType(CType(12, Byte), Integer))
        Me.btnBack.Location = New System.Drawing.Point(87, 578)
        Me.btnBack.Name = "btnBack"
        Me.btnBack.Size = New System.Drawing.Size(112, 35)
        Me.btnBack.TabIndex = 20
        Me.btnBack.Text = "&Back"
        Me.btnBack.UseVisualStyleBackColor = True
        '
        'ToolTip1
        '
        Me.ToolTip1.ToolTipIcon = System.Windows.Forms.ToolTipIcon.Info
        '
        'BindingSource1
        '
        Me.BindingSource1.DataMember = "tblCustomerInfo"
        Me.BindingSource1.DataSource = Me.CustomerDataSet
        '
        'CustomerDataSet
        '
        Me.CustomerDataSet.DataSetName = "CustomerDataSet"
        Me.CustomerDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'TblCustomerInfoTableAdapter
        '
        Me.TblCustomerInfoTableAdapter.ClearBeforeFill = True
        '
        'frmCustomer
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = Global.Project.My.Resources.Resources.background
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(1012, 638)
        Me.Controls.Add(Me.btnBack)
        Me.Controls.Add(Me.grbNew)
        Me.Controls.Add(Me.grbExisting)
        Me.Controls.Add(Me.radNew)
        Me.Controls.Add(Me.radExisting)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Name = "frmCustomer"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Customer"
        Me.grbExisting.ResumeLayout(False)
        Me.grbExisting.PerformLayout()
        Me.grbNew.ResumeLayout(False)
        Me.grbNew.PerformLayout()
        CType(Me.BindingSource1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.CustomerDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents radExisting As RadioButton
    Friend WithEvents radNew As RadioButton
    Friend WithEvents grbExisting As GroupBox
    Friend WithEvents lblPassword As Label
    Friend WithEvents lblUsername As Label
    Friend WithEvents txtPassword As TextBox
    Friend WithEvents txtUsername As TextBox
    Friend WithEvents grbNew As GroupBox
    Friend WithEvents btnLogin As Button
    Friend WithEvents btnClear As Button
    Friend WithEvents btnReset As Button
    Friend WithEvents btnCreate As Button
    Friend WithEvents txtUser As TextBox
    Friend WithEvents lblUser As Label
    Friend WithEvents txtCity As TextBox
    Friend WithEvents lblCity As Label
    Friend WithEvents lblEmail As Label
    Friend WithEvents txtEmail As TextBox
    Friend WithEvents lblPhone As Label
    Friend WithEvents mskContact As MaskedTextBox
    Friend WithEvents txtAddress As TextBox
    Friend WithEvents lblAddress As Label
    Friend WithEvents mskDOB As MaskedTextBox
    Friend WithEvents lblDOB As Label
    Friend WithEvents txtName As TextBox
    Friend WithEvents lblName As Label
    Friend WithEvents btnBack As Button
    Friend WithEvents ToolTip1 As ToolTip
    Friend WithEvents BindingSource1 As BindingSource
    Friend WithEvents CustomerDataSet As CustomerDataSet
    Friend WithEvents TblCustomerInfoTableAdapter As CustomerDataSetTableAdapters.tblCustomerInfoTableAdapter
    Friend WithEvents txtSurname As TextBox
End Class
