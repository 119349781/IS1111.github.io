﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmConfirmation
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmConfirmation))
        Me.txtDis = New System.Windows.Forms.TextBox()
        Me.txtDiscount = New System.Windows.Forms.TextBox()
        Me.txtTotAmount = New System.Windows.Forms.TextBox()
        Me.txtQuant = New System.Windows.Forms.TextBox()
        Me.txtTot = New System.Windows.Forms.TextBox()
        Me.txtVatat = New System.Windows.Forms.TextBox()
        Me.txtPriceShoe = New System.Windows.Forms.TextBox()
        Me.txtPic = New System.Windows.Forms.TextBox()
        Me.txtTexts = New System.Windows.Forms.TextBox()
        Me.txtCounter = New System.Windows.Forms.TextBox()
        Me.txtLacess = New System.Windows.Forms.TextBox()
        Me.txtEyestay = New System.Windows.Forms.TextBox()
        Me.txtVamps = New System.Windows.Forms.TextBox()
        Me.txtQuart = New System.Windows.Forms.TextBox()
        Me.txtMode = New System.Windows.Forms.TextBox()
        Me.txtLace = New System.Windows.Forms.TextBox()
        Me.txtCount = New System.Windows.Forms.TextBox()
        Me.txtTxt = New System.Windows.Forms.TextBox()
        Me.txtLog = New System.Windows.Forms.TextBox()
        Me.txtPrice = New System.Windows.Forms.TextBox()
        Me.txtVat = New System.Windows.Forms.TextBox()
        Me.txtTotal = New System.Windows.Forms.TextBox()
        Me.txtQuantity = New System.Windows.Forms.TextBox()
        Me.txtTotAmt = New System.Windows.Forms.TextBox()
        Me.txtStay = New System.Windows.Forms.TextBox()
        Me.txtVam = New System.Windows.Forms.TextBox()
        Me.txtQuar = New System.Windows.Forms.TextBox()
        Me.txtMod = New System.Windows.Forms.TextBox()
        Me.txtCharge = New System.Windows.Forms.TextBox()
        Me.txtShoeS = New System.Windows.Forms.TextBox()
        Me.txtSize = New System.Windows.Forms.TextBox()
        Me.txtText = New System.Windows.Forms.TextBox()
        Me.txtBack = New System.Windows.Forms.TextBox()
        Me.txtLaces = New System.Windows.Forms.TextBox()
        Me.txtEye = New System.Windows.Forms.TextBox()
        Me.txtVamp = New System.Windows.Forms.TextBox()
        Me.txtQuarter = New System.Windows.Forms.TextBox()
        Me.txtDescription = New System.Windows.Forms.TextBox()
        Me.txtAnswer = New System.Windows.Forms.TextBox()
        Me.txtProvided = New System.Windows.Forms.TextBox()
        Me.txtPicture = New System.Windows.Forms.TextBox()
        Me.txtLogo = New System.Windows.Forms.TextBox()
        Me.txtCustom = New System.Windows.Forms.TextBox()
        Me.txtShoe = New System.Windows.Forms.TextBox()
        Me.txtContact = New System.Windows.Forms.TextBox()
        Me.txtPhone = New System.Windows.Forms.TextBox()
        Me.TextBox9 = New System.Windows.Forms.TextBox()
        Me.txtName = New System.Windows.Forms.TextBox()
        Me.txtAddr = New System.Windows.Forms.TextBox()
        Me.txtCustomer = New System.Windows.Forms.TextBox()
        Me.txtOrder = New System.Windows.Forms.TextBox()
        Me.txtNumber = New System.Windows.Forms.TextBox()
        Me.txtToday = New System.Windows.Forms.TextBox()
        Me.txtDate = New System.Windows.Forms.TextBox()
        Me.txtYourStyle = New System.Windows.Forms.TextBox()
        Me.lblOrder = New System.Windows.Forms.Label()
        Me.btnReceipt = New System.Windows.Forms.Button()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.ShopToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MensShoesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.WomensShoesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TrackOrsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ContactUsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.LogoutToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PrintPreviewDialog1 = New System.Windows.Forms.PrintPreviewDialog()
        Me.PrintDocument1 = New System.Drawing.Printing.PrintDocument()
        Me.BindingSource1 = New System.Windows.Forms.BindingSource(Me.components)
        Me.TrackOrderDataSet = New Project.TrackOrderDataSet()
        Me.TblOrdersTableAdapter = New Project.TrackOrderDataSetTableAdapters.tblOrdersTableAdapter()
        Me.MenuStrip1.SuspendLayout()
        CType(Me.BindingSource1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TrackOrderDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'txtDis
        '
        Me.txtDis.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.txtDis.Location = New System.Drawing.Point(508, 938)
        Me.txtDis.Name = "txtDis"
        Me.txtDis.ReadOnly = True
        Me.txtDis.Size = New System.Drawing.Size(138, 26)
        Me.txtDis.TabIndex = 115
        '
        'txtDiscount
        '
        Me.txtDiscount.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.txtDiscount.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtDiscount.Location = New System.Drawing.Point(364, 938)
        Me.txtDiscount.Name = "txtDiscount"
        Me.txtDiscount.ReadOnly = True
        Me.txtDiscount.Size = New System.Drawing.Size(138, 26)
        Me.txtDiscount.TabIndex = 114
        Me.txtDiscount.Text = "- Discount"
        Me.txtDiscount.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtTotAmount
        '
        Me.txtTotAmount.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.txtTotAmount.Location = New System.Drawing.Point(508, 968)
        Me.txtTotAmount.Name = "txtTotAmount"
        Me.txtTotAmount.ReadOnly = True
        Me.txtTotAmount.Size = New System.Drawing.Size(139, 26)
        Me.txtTotAmount.TabIndex = 113
        '
        'txtQuant
        '
        Me.txtQuant.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.txtQuant.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtQuant.Location = New System.Drawing.Point(508, 905)
        Me.txtQuant.Name = "txtQuant"
        Me.txtQuant.ReadOnly = True
        Me.txtQuant.Size = New System.Drawing.Size(139, 26)
        Me.txtQuant.TabIndex = 112
        '
        'txtTot
        '
        Me.txtTot.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.txtTot.Location = New System.Drawing.Point(508, 875)
        Me.txtTot.Name = "txtTot"
        Me.txtTot.ReadOnly = True
        Me.txtTot.Size = New System.Drawing.Size(138, 26)
        Me.txtTot.TabIndex = 111
        '
        'txtVatat
        '
        Me.txtVatat.BackColor = System.Drawing.Color.White
        Me.txtVatat.Location = New System.Drawing.Point(508, 842)
        Me.txtVatat.Name = "txtVatat"
        Me.txtVatat.ReadOnly = True
        Me.txtVatat.Size = New System.Drawing.Size(139, 26)
        Me.txtVatat.TabIndex = 110
        '
        'txtPriceShoe
        '
        Me.txtPriceShoe.BackColor = System.Drawing.Color.White
        Me.txtPriceShoe.Location = New System.Drawing.Point(508, 810)
        Me.txtPriceShoe.Name = "txtPriceShoe"
        Me.txtPriceShoe.ReadOnly = True
        Me.txtPriceShoe.Size = New System.Drawing.Size(139, 26)
        Me.txtPriceShoe.TabIndex = 109
        '
        'txtPic
        '
        Me.txtPic.BackColor = System.Drawing.Color.White
        Me.txtPic.Location = New System.Drawing.Point(508, 778)
        Me.txtPic.Name = "txtPic"
        Me.txtPic.ReadOnly = True
        Me.txtPic.Size = New System.Drawing.Size(139, 26)
        Me.txtPic.TabIndex = 108
        '
        'txtTexts
        '
        Me.txtTexts.BackColor = System.Drawing.Color.White
        Me.txtTexts.Location = New System.Drawing.Point(508, 747)
        Me.txtTexts.Name = "txtTexts"
        Me.txtTexts.ReadOnly = True
        Me.txtTexts.Size = New System.Drawing.Size(139, 26)
        Me.txtTexts.TabIndex = 107
        '
        'txtCounter
        '
        Me.txtCounter.BackColor = System.Drawing.Color.White
        Me.txtCounter.Location = New System.Drawing.Point(508, 715)
        Me.txtCounter.Name = "txtCounter"
        Me.txtCounter.ReadOnly = True
        Me.txtCounter.Size = New System.Drawing.Size(139, 26)
        Me.txtCounter.TabIndex = 106
        '
        'txtLacess
        '
        Me.txtLacess.BackColor = System.Drawing.Color.White
        Me.txtLacess.Location = New System.Drawing.Point(508, 682)
        Me.txtLacess.Name = "txtLacess"
        Me.txtLacess.ReadOnly = True
        Me.txtLacess.Size = New System.Drawing.Size(139, 26)
        Me.txtLacess.TabIndex = 105
        '
        'txtEyestay
        '
        Me.txtEyestay.BackColor = System.Drawing.Color.White
        Me.txtEyestay.Location = New System.Drawing.Point(508, 650)
        Me.txtEyestay.Name = "txtEyestay"
        Me.txtEyestay.ReadOnly = True
        Me.txtEyestay.Size = New System.Drawing.Size(139, 26)
        Me.txtEyestay.TabIndex = 104
        '
        'txtVamps
        '
        Me.txtVamps.BackColor = System.Drawing.Color.White
        Me.txtVamps.Location = New System.Drawing.Point(508, 618)
        Me.txtVamps.Name = "txtVamps"
        Me.txtVamps.ReadOnly = True
        Me.txtVamps.Size = New System.Drawing.Size(139, 26)
        Me.txtVamps.TabIndex = 103
        '
        'txtQuart
        '
        Me.txtQuart.BackColor = System.Drawing.Color.White
        Me.txtQuart.Location = New System.Drawing.Point(508, 587)
        Me.txtQuart.Name = "txtQuart"
        Me.txtQuart.ReadOnly = True
        Me.txtQuart.Size = New System.Drawing.Size(139, 26)
        Me.txtQuart.TabIndex = 102
        '
        'txtMode
        '
        Me.txtMode.BackColor = System.Drawing.Color.White
        Me.txtMode.Location = New System.Drawing.Point(508, 555)
        Me.txtMode.Name = "txtMode"
        Me.txtMode.ReadOnly = True
        Me.txtMode.Size = New System.Drawing.Size(139, 26)
        Me.txtMode.TabIndex = 101
        '
        'txtLace
        '
        Me.txtLace.BackColor = System.Drawing.Color.White
        Me.txtLace.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtLace.Location = New System.Drawing.Point(362, 682)
        Me.txtLace.Name = "txtLace"
        Me.txtLace.ReadOnly = True
        Me.txtLace.Size = New System.Drawing.Size(139, 26)
        Me.txtLace.TabIndex = 100
        Me.txtLace.Text = "Laces:"
        '
        'txtCount
        '
        Me.txtCount.BackColor = System.Drawing.Color.White
        Me.txtCount.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtCount.Location = New System.Drawing.Point(362, 715)
        Me.txtCount.Name = "txtCount"
        Me.txtCount.ReadOnly = True
        Me.txtCount.Size = New System.Drawing.Size(139, 26)
        Me.txtCount.TabIndex = 99
        Me.txtCount.Text = "Back Counter:"
        '
        'txtTxt
        '
        Me.txtTxt.BackColor = System.Drawing.Color.White
        Me.txtTxt.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtTxt.Location = New System.Drawing.Point(362, 747)
        Me.txtTxt.Name = "txtTxt"
        Me.txtTxt.ReadOnly = True
        Me.txtTxt.Size = New System.Drawing.Size(140, 26)
        Me.txtTxt.TabIndex = 98
        Me.txtTxt.Text = "Text:"
        '
        'txtLog
        '
        Me.txtLog.BackColor = System.Drawing.Color.White
        Me.txtLog.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtLog.Location = New System.Drawing.Point(362, 778)
        Me.txtLog.Name = "txtLog"
        Me.txtLog.ReadOnly = True
        Me.txtLog.Size = New System.Drawing.Size(139, 26)
        Me.txtLog.TabIndex = 97
        Me.txtLog.Text = "Logo:"
        '
        'txtPrice
        '
        Me.txtPrice.BackColor = System.Drawing.Color.White
        Me.txtPrice.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtPrice.Location = New System.Drawing.Point(362, 810)
        Me.txtPrice.Name = "txtPrice"
        Me.txtPrice.ReadOnly = True
        Me.txtPrice.Size = New System.Drawing.Size(139, 26)
        Me.txtPrice.TabIndex = 96
        Me.txtPrice.Text = "Price per Shoe:"
        Me.txtPrice.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtVat
        '
        Me.txtVat.BackColor = System.Drawing.Color.White
        Me.txtVat.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtVat.Location = New System.Drawing.Point(362, 842)
        Me.txtVat.Name = "txtVat"
        Me.txtVat.ReadOnly = True
        Me.txtVat.Size = New System.Drawing.Size(140, 26)
        Me.txtVat.TabIndex = 95
        Me.txtVat.Text = "VAT @ 23%"
        Me.txtVat.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtTotal
        '
        Me.txtTotal.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.txtTotal.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtTotal.Location = New System.Drawing.Point(362, 875)
        Me.txtTotal.Name = "txtTotal"
        Me.txtTotal.ReadOnly = True
        Me.txtTotal.Size = New System.Drawing.Size(140, 26)
        Me.txtTotal.TabIndex = 94
        Me.txtTotal.Text = "Total per Shoe"
        Me.txtTotal.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtQuantity
        '
        Me.txtQuantity.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.txtQuantity.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.7!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtQuantity.Location = New System.Drawing.Point(363, 907)
        Me.txtQuantity.Name = "txtQuantity"
        Me.txtQuantity.ReadOnly = True
        Me.txtQuantity.Size = New System.Drawing.Size(140, 25)
        Me.txtQuantity.TabIndex = 93
        Me.txtQuantity.Text = "Quantity Ordered"
        Me.txtQuantity.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtTotAmt
        '
        Me.txtTotAmt.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.txtTotAmt.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtTotAmt.Location = New System.Drawing.Point(364, 968)
        Me.txtTotAmt.Name = "txtTotAmt"
        Me.txtTotAmt.ReadOnly = True
        Me.txtTotAmt.Size = New System.Drawing.Size(140, 26)
        Me.txtTotAmt.TabIndex = 92
        Me.txtTotAmt.Text = "Total Amount"
        Me.txtTotAmt.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtStay
        '
        Me.txtStay.BackColor = System.Drawing.Color.White
        Me.txtStay.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtStay.Location = New System.Drawing.Point(362, 650)
        Me.txtStay.Name = "txtStay"
        Me.txtStay.ReadOnly = True
        Me.txtStay.Size = New System.Drawing.Size(139, 26)
        Me.txtStay.TabIndex = 91
        Me.txtStay.Text = "Eyestay:"
        '
        'txtVam
        '
        Me.txtVam.BackColor = System.Drawing.Color.White
        Me.txtVam.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtVam.Location = New System.Drawing.Point(362, 618)
        Me.txtVam.Name = "txtVam"
        Me.txtVam.ReadOnly = True
        Me.txtVam.Size = New System.Drawing.Size(139, 26)
        Me.txtVam.TabIndex = 90
        Me.txtVam.Text = "Vamp:"
        '
        'txtQuar
        '
        Me.txtQuar.BackColor = System.Drawing.Color.White
        Me.txtQuar.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtQuar.Location = New System.Drawing.Point(364, 587)
        Me.txtQuar.Name = "txtQuar"
        Me.txtQuar.ReadOnly = True
        Me.txtQuar.Size = New System.Drawing.Size(140, 26)
        Me.txtQuar.TabIndex = 89
        Me.txtQuar.Text = "Quarter:"
        '
        'txtMod
        '
        Me.txtMod.BackColor = System.Drawing.Color.White
        Me.txtMod.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtMod.Location = New System.Drawing.Point(364, 555)
        Me.txtMod.Name = "txtMod"
        Me.txtMod.ReadOnly = True
        Me.txtMod.Size = New System.Drawing.Size(139, 26)
        Me.txtMod.TabIndex = 88
        Me.txtMod.Text = "Model:"
        '
        'txtCharge
        '
        Me.txtCharge.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.txtCharge.Location = New System.Drawing.Point(100, 555)
        Me.txtCharge.Multiline = True
        Me.txtCharge.Name = "txtCharge"
        Me.txtCharge.ReadOnly = True
        Me.txtCharge.Size = New System.Drawing.Size(256, 439)
        Me.txtCharge.TabIndex = 87
        Me.txtCharge.Text = "Customization Charge:"
        '
        'txtShoeS
        '
        Me.txtShoeS.BackColor = System.Drawing.Color.White
        Me.txtShoeS.Location = New System.Drawing.Point(362, 522)
        Me.txtShoeS.Name = "txtShoeS"
        Me.txtShoeS.ReadOnly = True
        Me.txtShoeS.Size = New System.Drawing.Size(288, 26)
        Me.txtShoeS.TabIndex = 86
        '
        'txtSize
        '
        Me.txtSize.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.txtSize.Location = New System.Drawing.Point(102, 524)
        Me.txtSize.Name = "txtSize"
        Me.txtSize.ReadOnly = True
        Me.txtSize.Size = New System.Drawing.Size(256, 26)
        Me.txtSize.TabIndex = 85
        Me.txtSize.Text = "Shoe Size:"
        '
        'txtText
        '
        Me.txtText.BackColor = System.Drawing.Color.White
        Me.txtText.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtText.Location = New System.Drawing.Point(362, 498)
        Me.txtText.Name = "txtText"
        Me.txtText.ReadOnly = True
        Me.txtText.Size = New System.Drawing.Size(284, 19)
        Me.txtText.TabIndex = 84
        '
        'txtBack
        '
        Me.txtBack.BackColor = System.Drawing.Color.White
        Me.txtBack.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtBack.Location = New System.Drawing.Point(363, 471)
        Me.txtBack.Name = "txtBack"
        Me.txtBack.ReadOnly = True
        Me.txtBack.Size = New System.Drawing.Size(284, 19)
        Me.txtBack.TabIndex = 83
        '
        'txtLaces
        '
        Me.txtLaces.BackColor = System.Drawing.Color.White
        Me.txtLaces.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtLaces.Location = New System.Drawing.Point(363, 447)
        Me.txtLaces.Name = "txtLaces"
        Me.txtLaces.ReadOnly = True
        Me.txtLaces.Size = New System.Drawing.Size(282, 19)
        Me.txtLaces.TabIndex = 82
        '
        'txtEye
        '
        Me.txtEye.BackColor = System.Drawing.Color.White
        Me.txtEye.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtEye.Location = New System.Drawing.Point(363, 422)
        Me.txtEye.Name = "txtEye"
        Me.txtEye.ReadOnly = True
        Me.txtEye.Size = New System.Drawing.Size(284, 19)
        Me.txtEye.TabIndex = 81
        '
        'txtVamp
        '
        Me.txtVamp.BackColor = System.Drawing.Color.White
        Me.txtVamp.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtVamp.Location = New System.Drawing.Point(363, 398)
        Me.txtVamp.Name = "txtVamp"
        Me.txtVamp.ReadOnly = True
        Me.txtVamp.Size = New System.Drawing.Size(284, 19)
        Me.txtVamp.TabIndex = 80
        '
        'txtQuarter
        '
        Me.txtQuarter.BackColor = System.Drawing.Color.White
        Me.txtQuarter.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtQuarter.Location = New System.Drawing.Point(364, 374)
        Me.txtQuarter.Name = "txtQuarter"
        Me.txtQuarter.ReadOnly = True
        Me.txtQuarter.Size = New System.Drawing.Size(284, 19)
        Me.txtQuarter.TabIndex = 79
        '
        'txtDescription
        '
        Me.txtDescription.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.txtDescription.Location = New System.Drawing.Point(102, 371)
        Me.txtDescription.Multiline = True
        Me.txtDescription.Name = "txtDescription"
        Me.txtDescription.ReadOnly = True
        Me.txtDescription.Size = New System.Drawing.Size(256, 146)
        Me.txtDescription.TabIndex = 78
        Me.txtDescription.Text = "Customization Description:"
        '
        'txtAnswer
        '
        Me.txtAnswer.BackColor = System.Drawing.Color.White
        Me.txtAnswer.Location = New System.Drawing.Point(364, 341)
        Me.txtAnswer.Name = "txtAnswer"
        Me.txtAnswer.ReadOnly = True
        Me.txtAnswer.Size = New System.Drawing.Size(284, 26)
        Me.txtAnswer.TabIndex = 77
        '
        'txtProvided
        '
        Me.txtProvided.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.txtProvided.Location = New System.Drawing.Point(102, 341)
        Me.txtProvided.Name = "txtProvided"
        Me.txtProvided.ReadOnly = True
        Me.txtProvided.Size = New System.Drawing.Size(256, 26)
        Me.txtProvided.TabIndex = 76
        Me.txtProvided.Text = "Provided when ordering?"
        '
        'txtPicture
        '
        Me.txtPicture.BackColor = System.Drawing.Color.White
        Me.txtPicture.Location = New System.Drawing.Point(364, 308)
        Me.txtPicture.Name = "txtPicture"
        Me.txtPicture.ReadOnly = True
        Me.txtPicture.Size = New System.Drawing.Size(284, 26)
        Me.txtPicture.TabIndex = 75
        '
        'txtLogo
        '
        Me.txtLogo.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.txtLogo.Location = New System.Drawing.Point(102, 308)
        Me.txtLogo.Name = "txtLogo"
        Me.txtLogo.ReadOnly = True
        Me.txtLogo.Size = New System.Drawing.Size(256, 26)
        Me.txtLogo.TabIndex = 74
        Me.txtLogo.Text = "Logo/Picture:"
        '
        'txtCustom
        '
        Me.txtCustom.BackColor = System.Drawing.Color.White
        Me.txtCustom.Location = New System.Drawing.Point(363, 276)
        Me.txtCustom.Name = "txtCustom"
        Me.txtCustom.ReadOnly = True
        Me.txtCustom.Size = New System.Drawing.Size(284, 26)
        Me.txtCustom.TabIndex = 73
        '
        'txtShoe
        '
        Me.txtShoe.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.txtShoe.Location = New System.Drawing.Point(102, 276)
        Me.txtShoe.Name = "txtShoe"
        Me.txtShoe.ReadOnly = True
        Me.txtShoe.Size = New System.Drawing.Size(256, 26)
        Me.txtShoe.TabIndex = 72
        Me.txtShoe.Text = "Shoe to be customized:"
        '
        'txtContact
        '
        Me.txtContact.BackColor = System.Drawing.Color.White
        Me.txtContact.Location = New System.Drawing.Point(363, 244)
        Me.txtContact.Name = "txtContact"
        Me.txtContact.ReadOnly = True
        Me.txtContact.Size = New System.Drawing.Size(284, 26)
        Me.txtContact.TabIndex = 71
        '
        'txtPhone
        '
        Me.txtPhone.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.txtPhone.Location = New System.Drawing.Point(102, 244)
        Me.txtPhone.Name = "txtPhone"
        Me.txtPhone.ReadOnly = True
        Me.txtPhone.Size = New System.Drawing.Size(256, 26)
        Me.txtPhone.TabIndex = 70
        Me.txtPhone.Text = "Customer Phone Number:"
        '
        'TextBox9
        '
        Me.TextBox9.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.TextBox9.Location = New System.Drawing.Point(102, 211)
        Me.TextBox9.Name = "TextBox9"
        Me.TextBox9.ReadOnly = True
        Me.TextBox9.Size = New System.Drawing.Size(256, 26)
        Me.TextBox9.TabIndex = 69
        Me.TextBox9.Text = "Customer Address:"
        '
        'txtName
        '
        Me.txtName.BackColor = System.Drawing.Color.White
        Me.txtName.Location = New System.Drawing.Point(363, 184)
        Me.txtName.Name = "txtName"
        Me.txtName.ReadOnly = True
        Me.txtName.Size = New System.Drawing.Size(284, 26)
        Me.txtName.TabIndex = 68
        '
        'txtAddr
        '
        Me.txtAddr.BackColor = System.Drawing.Color.White
        Me.txtAddr.Location = New System.Drawing.Point(363, 211)
        Me.txtAddr.Name = "txtAddr"
        Me.txtAddr.ReadOnly = True
        Me.txtAddr.Size = New System.Drawing.Size(284, 26)
        Me.txtAddr.TabIndex = 67
        '
        'txtCustomer
        '
        Me.txtCustomer.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.txtCustomer.Location = New System.Drawing.Point(100, 184)
        Me.txtCustomer.Name = "txtCustomer"
        Me.txtCustomer.ReadOnly = True
        Me.txtCustomer.Size = New System.Drawing.Size(256, 26)
        Me.txtCustomer.TabIndex = 66
        Me.txtCustomer.Text = "Customer Name:"
        '
        'txtOrder
        '
        Me.txtOrder.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.txtOrder.Location = New System.Drawing.Point(363, 151)
        Me.txtOrder.Name = "txtOrder"
        Me.txtOrder.ReadOnly = True
        Me.txtOrder.Size = New System.Drawing.Size(100, 26)
        Me.txtOrder.TabIndex = 65
        Me.txtOrder.Text = "Order No."
        '
        'txtNumber
        '
        Me.txtNumber.BackColor = System.Drawing.Color.White
        Me.txtNumber.Location = New System.Drawing.Point(470, 151)
        Me.txtNumber.Name = "txtNumber"
        Me.txtNumber.ReadOnly = True
        Me.txtNumber.Size = New System.Drawing.Size(178, 26)
        Me.txtNumber.TabIndex = 64
        '
        'txtToday
        '
        Me.txtToday.BackColor = System.Drawing.Color.White
        Me.txtToday.Location = New System.Drawing.Point(207, 151)
        Me.txtToday.Name = "txtToday"
        Me.txtToday.ReadOnly = True
        Me.txtToday.Size = New System.Drawing.Size(150, 26)
        Me.txtToday.TabIndex = 63
        '
        'txtDate
        '
        Me.txtDate.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.txtDate.Location = New System.Drawing.Point(100, 151)
        Me.txtDate.Name = "txtDate"
        Me.txtDate.ReadOnly = True
        Me.txtDate.Size = New System.Drawing.Size(100, 26)
        Me.txtDate.TabIndex = 62
        Me.txtDate.Text = "Date:"
        '
        'txtYourStyle
        '
        Me.txtYourStyle.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.txtYourStyle.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtYourStyle.Location = New System.Drawing.Point(100, 75)
        Me.txtYourStyle.Multiline = True
        Me.txtYourStyle.Name = "txtYourStyle"
        Me.txtYourStyle.ReadOnly = True
        Me.txtYourStyle.Size = New System.Drawing.Size(546, 72)
        Me.txtYourStyle.TabIndex = 61
        Me.txtYourStyle.Text = "Shoes Ltd. " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "1234 Oliver Plunkett St. " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "021-3847742" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        Me.txtYourStyle.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'lblOrder
        '
        Me.lblOrder.AutoSize = True
        Me.lblOrder.BackColor = System.Drawing.Color.Transparent
        Me.lblOrder.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblOrder.Location = New System.Drawing.Point(202, 42)
        Me.lblOrder.Name = "lblOrder"
        Me.lblOrder.Size = New System.Drawing.Size(351, 29)
        Me.lblOrder.TabIndex = 60
        Me.lblOrder.Text = "Order was Successfully Placed!"
        '
        'btnReceipt
        '
        Me.btnReceipt.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnReceipt.Location = New System.Drawing.Point(704, 926)
        Me.btnReceipt.Name = "btnReceipt"
        Me.btnReceipt.Size = New System.Drawing.Size(138, 68)
        Me.btnReceipt.TabIndex = 59
        Me.btnReceipt.Text = "&Print Receipt"
        Me.btnReceipt.UseVisualStyleBackColor = True
        '
        'MenuStrip1
        '
        Me.MenuStrip1.BackColor = System.Drawing.Color.Transparent
        Me.MenuStrip1.ImageScalingSize = New System.Drawing.Size(24, 24)
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ShopToolStripMenuItem, Me.TrackOrsToolStripMenuItem, Me.ContactUsToolStripMenuItem, Me.LogoutToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(867, 33)
        Me.MenuStrip1.TabIndex = 58
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'ShopToolStripMenuItem
        '
        Me.ShopToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.MensShoesToolStripMenuItem, Me.WomensShoesToolStripMenuItem})
        Me.ShopToolStripMenuItem.Name = "ShopToolStripMenuItem"
        Me.ShopToolStripMenuItem.Size = New System.Drawing.Size(66, 29)
        Me.ShopToolStripMenuItem.Text = "Shop"
        '
        'MensShoesToolStripMenuItem
        '
        Me.MensShoesToolStripMenuItem.Name = "MensShoesToolStripMenuItem"
        Me.MensShoesToolStripMenuItem.Size = New System.Drawing.Size(252, 30)
        Me.MensShoesToolStripMenuItem.Text = "Mens Shoes"
        '
        'WomensShoesToolStripMenuItem
        '
        Me.WomensShoesToolStripMenuItem.Name = "WomensShoesToolStripMenuItem"
        Me.WomensShoesToolStripMenuItem.Size = New System.Drawing.Size(252, 30)
        Me.WomensShoesToolStripMenuItem.Text = "Womens Shoes"
        '
        'TrackOrsToolStripMenuItem
        '
        Me.TrackOrsToolStripMenuItem.Name = "TrackOrsToolStripMenuItem"
        Me.TrackOrsToolStripMenuItem.Size = New System.Drawing.Size(114, 29)
        Me.TrackOrsToolStripMenuItem.Text = "Track Order"
        '
        'ContactUsToolStripMenuItem
        '
        Me.ContactUsToolStripMenuItem.Name = "ContactUsToolStripMenuItem"
        Me.ContactUsToolStripMenuItem.Size = New System.Drawing.Size(99, 29)
        Me.ContactUsToolStripMenuItem.Text = "About Us"
        '
        'LogoutToolStripMenuItem
        '
        Me.LogoutToolStripMenuItem.Name = "LogoutToolStripMenuItem"
        Me.LogoutToolStripMenuItem.Size = New System.Drawing.Size(81, 29)
        Me.LogoutToolStripMenuItem.Text = "Logout"
        '
        'PrintPreviewDialog1
        '
        Me.PrintPreviewDialog1.AutoScrollMargin = New System.Drawing.Size(0, 0)
        Me.PrintPreviewDialog1.AutoScrollMinSize = New System.Drawing.Size(0, 0)
        Me.PrintPreviewDialog1.ClientSize = New System.Drawing.Size(400, 300)
        Me.PrintPreviewDialog1.Document = Me.PrintDocument1
        Me.PrintPreviewDialog1.Enabled = True
        Me.PrintPreviewDialog1.Icon = CType(resources.GetObject("PrintPreviewDialog1.Icon"), System.Drawing.Icon)
        Me.PrintPreviewDialog1.Name = "PrintPreviewDialog1"
        Me.PrintPreviewDialog1.Visible = False
        '
        'PrintDocument1
        '
        Me.PrintDocument1.DocumentName = "Order_Receipt"
        '
        'BindingSource1
        '
        Me.BindingSource1.DataMember = "tblOrders"
        Me.BindingSource1.DataSource = Me.TrackOrderDataSet
        '
        'TrackOrderDataSet
        '
        Me.TrackOrderDataSet.DataSetName = "TrackOrderDataSet"
        Me.TrackOrderDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'TblOrdersTableAdapter
        '
        Me.TblOrdersTableAdapter.ClearBeforeFill = True
        '
        'frmConfirmation
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = Global.Project.My.Resources.Resources.background
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(867, 1017)
        Me.Controls.Add(Me.txtDis)
        Me.Controls.Add(Me.txtDiscount)
        Me.Controls.Add(Me.txtTotAmount)
        Me.Controls.Add(Me.txtQuant)
        Me.Controls.Add(Me.txtTot)
        Me.Controls.Add(Me.txtVatat)
        Me.Controls.Add(Me.txtPriceShoe)
        Me.Controls.Add(Me.txtPic)
        Me.Controls.Add(Me.txtTexts)
        Me.Controls.Add(Me.txtCounter)
        Me.Controls.Add(Me.txtLacess)
        Me.Controls.Add(Me.txtEyestay)
        Me.Controls.Add(Me.txtVamps)
        Me.Controls.Add(Me.txtQuart)
        Me.Controls.Add(Me.txtMode)
        Me.Controls.Add(Me.txtLace)
        Me.Controls.Add(Me.txtCount)
        Me.Controls.Add(Me.txtTxt)
        Me.Controls.Add(Me.txtLog)
        Me.Controls.Add(Me.txtPrice)
        Me.Controls.Add(Me.txtVat)
        Me.Controls.Add(Me.txtTotal)
        Me.Controls.Add(Me.txtQuantity)
        Me.Controls.Add(Me.txtTotAmt)
        Me.Controls.Add(Me.txtStay)
        Me.Controls.Add(Me.txtVam)
        Me.Controls.Add(Me.txtQuar)
        Me.Controls.Add(Me.txtMod)
        Me.Controls.Add(Me.txtCharge)
        Me.Controls.Add(Me.txtShoeS)
        Me.Controls.Add(Me.txtSize)
        Me.Controls.Add(Me.txtText)
        Me.Controls.Add(Me.txtBack)
        Me.Controls.Add(Me.txtLaces)
        Me.Controls.Add(Me.txtEye)
        Me.Controls.Add(Me.txtVamp)
        Me.Controls.Add(Me.txtQuarter)
        Me.Controls.Add(Me.txtDescription)
        Me.Controls.Add(Me.txtAnswer)
        Me.Controls.Add(Me.txtProvided)
        Me.Controls.Add(Me.txtPicture)
        Me.Controls.Add(Me.txtLogo)
        Me.Controls.Add(Me.txtCustom)
        Me.Controls.Add(Me.txtShoe)
        Me.Controls.Add(Me.txtContact)
        Me.Controls.Add(Me.txtPhone)
        Me.Controls.Add(Me.TextBox9)
        Me.Controls.Add(Me.txtName)
        Me.Controls.Add(Me.txtAddr)
        Me.Controls.Add(Me.txtCustomer)
        Me.Controls.Add(Me.txtOrder)
        Me.Controls.Add(Me.txtNumber)
        Me.Controls.Add(Me.txtToday)
        Me.Controls.Add(Me.txtDate)
        Me.Controls.Add(Me.txtYourStyle)
        Me.Controls.Add(Me.lblOrder)
        Me.Controls.Add(Me.btnReceipt)
        Me.Controls.Add(Me.MenuStrip1)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Name = "frmConfirmation"
        Me.Text = "frmConfirmation"
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        CType(Me.BindingSource1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TrackOrderDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents txtDis As TextBox
    Friend WithEvents txtDiscount As TextBox
    Friend WithEvents txtTotAmount As TextBox
    Friend WithEvents txtQuant As TextBox
    Friend WithEvents txtTot As TextBox
    Friend WithEvents txtVatat As TextBox
    Friend WithEvents txtPriceShoe As TextBox
    Friend WithEvents txtPic As TextBox
    Friend WithEvents txtTexts As TextBox
    Friend WithEvents txtCounter As TextBox
    Friend WithEvents txtLacess As TextBox
    Friend WithEvents txtEyestay As TextBox
    Friend WithEvents txtVamps As TextBox
    Friend WithEvents txtQuart As TextBox
    Friend WithEvents txtMode As TextBox
    Friend WithEvents txtLace As TextBox
    Friend WithEvents txtCount As TextBox
    Friend WithEvents txtTxt As TextBox
    Friend WithEvents txtLog As TextBox
    Friend WithEvents txtPrice As TextBox
    Friend WithEvents txtVat As TextBox
    Friend WithEvents txtTotal As TextBox
    Friend WithEvents txtQuantity As TextBox
    Friend WithEvents txtTotAmt As TextBox
    Friend WithEvents txtStay As TextBox
    Friend WithEvents txtVam As TextBox
    Friend WithEvents txtQuar As TextBox
    Friend WithEvents txtMod As TextBox
    Friend WithEvents txtCharge As TextBox
    Friend WithEvents txtShoeS As TextBox
    Friend WithEvents txtSize As TextBox
    Friend WithEvents txtText As TextBox
    Friend WithEvents txtBack As TextBox
    Friend WithEvents txtLaces As TextBox
    Friend WithEvents txtEye As TextBox
    Friend WithEvents txtVamp As TextBox
    Friend WithEvents txtQuarter As TextBox
    Friend WithEvents txtDescription As TextBox
    Friend WithEvents txtAnswer As TextBox
    Friend WithEvents txtProvided As TextBox
    Friend WithEvents txtPicture As TextBox
    Friend WithEvents txtLogo As TextBox
    Friend WithEvents txtCustom As TextBox
    Friend WithEvents txtShoe As TextBox
    Friend WithEvents txtContact As TextBox
    Friend WithEvents txtPhone As TextBox
    Friend WithEvents TextBox9 As TextBox
    Friend WithEvents txtName As TextBox
    Friend WithEvents txtAddr As TextBox
    Friend WithEvents txtCustomer As TextBox
    Friend WithEvents txtOrder As TextBox
    Friend WithEvents txtNumber As TextBox
    Friend WithEvents txtToday As TextBox
    Friend WithEvents txtDate As TextBox
    Friend WithEvents txtYourStyle As TextBox
    Friend WithEvents lblOrder As Label
    Friend WithEvents btnReceipt As Button
    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents ShopToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents MensShoesToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents WomensShoesToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents TrackOrsToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ContactUsToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents LogoutToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents PrintPreviewDialog1 As PrintPreviewDialog
    Friend WithEvents PrintDocument1 As Printing.PrintDocument
    Friend WithEvents BindingSource1 As BindingSource
    Friend WithEvents TrackOrderDataSet As TrackOrderDataSet
    Friend WithEvents TblOrdersTableAdapter As TrackOrderDataSetTableAdapters.tblOrdersTableAdapter
End Class
