﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmUserManual
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmUserManual))
        Me.txtLogin = New System.Windows.Forms.TextBox()
        Me.picUsers = New System.Windows.Forms.PictureBox()
        Me.lblLogin = New System.Windows.Forms.Label()
        Me.txtAccount = New System.Windows.Forms.TextBox()
        Me.lblOne = New System.Windows.Forms.Label()
        Me.lblTwo = New System.Windows.Forms.Label()
        Me.picHome = New System.Windows.Forms.PictureBox()
        Me.lblThree = New System.Windows.Forms.Label()
        Me.txtLogout = New System.Windows.Forms.TextBox()
        Me.lblFour = New System.Windows.Forms.Label()
        Me.txtTrack = New System.Windows.Forms.TextBox()
        Me.picTrack = New System.Windows.Forms.PictureBox()
        Me.lblFive = New System.Windows.Forms.Label()
        Me.txtMenu = New System.Windows.Forms.TextBox()
        Me.picMenu = New System.Windows.Forms.PictureBox()
        Me.lblSix = New System.Windows.Forms.Label()
        Me.txtOrder = New System.Windows.Forms.TextBox()
        Me.lblSeven = New System.Windows.Forms.Label()
        Me.txtLogo = New System.Windows.Forms.TextBox()
        Me.picBrowse = New System.Windows.Forms.PictureBox()
        Me.picSample = New System.Windows.Forms.PictureBox()
        Me.btnNext = New System.Windows.Forms.Button()
        Me.picClear = New System.Windows.Forms.PictureBox()
        CType(Me.picUsers, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picHome, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picTrack, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picMenu, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picBrowse, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picSample, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picClear, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'txtLogin
        '
        Me.txtLogin.Location = New System.Drawing.Point(36, 68)
        Me.txtLogin.Multiline = True
        Me.txtLogin.Name = "txtLogin"
        Me.txtLogin.ReadOnly = True
        Me.txtLogin.Size = New System.Drawing.Size(227, 149)
        Me.txtLogin.TabIndex = 0
        Me.txtLogin.Text = "To login in as a user there are a few accounts, one for example is aosuillivan." & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) &
    "The username and password are identical. " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "You can also create a new account. "
        '
        'picUsers
        '
        Me.picUsers.Image = CType(resources.GetObject("picUsers.Image"), System.Drawing.Image)
        Me.picUsers.Location = New System.Drawing.Point(269, 55)
        Me.picUsers.Name = "picUsers"
        Me.picUsers.Size = New System.Drawing.Size(163, 180)
        Me.picUsers.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picUsers.TabIndex = 1
        Me.picUsers.TabStop = False
        '
        'lblLogin
        '
        Me.lblLogin.AutoSize = True
        Me.lblLogin.BackColor = System.Drawing.Color.Transparent
        Me.lblLogin.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblLogin.Location = New System.Drawing.Point(32, 40)
        Me.lblLogin.Name = "lblLogin"
        Me.lblLogin.Size = New System.Drawing.Size(181, 25)
        Me.lblLogin.TabIndex = 2
        Me.lblLogin.Text = "Customer Report:"
        '
        'txtAccount
        '
        Me.txtAccount.Location = New System.Drawing.Point(37, 263)
        Me.txtAccount.Multiline = True
        Me.txtAccount.Name = "txtAccount"
        Me.txtAccount.ReadOnly = True
        Me.txtAccount.Size = New System.Drawing.Size(210, 98)
        Me.txtAccount.TabIndex = 3
        Me.txtAccount.Text = "You are then brought to the home page, where you can" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "make a new order, track an " &
    "existing order or logout"
        '
        'lblOne
        '
        Me.lblOne.AutoSize = True
        Me.lblOne.BackColor = System.Drawing.Color.Transparent
        Me.lblOne.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblOne.Location = New System.Drawing.Point(-1, 79)
        Me.lblOne.Name = "lblOne"
        Me.lblOne.Size = New System.Drawing.Size(31, 25)
        Me.lblOne.TabIndex = 4
        Me.lblOne.Text = "1:"
        '
        'lblTwo
        '
        Me.lblTwo.AutoSize = True
        Me.lblTwo.BackColor = System.Drawing.Color.Transparent
        Me.lblTwo.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTwo.Location = New System.Drawing.Point(-1, 274)
        Me.lblTwo.Name = "lblTwo"
        Me.lblTwo.Size = New System.Drawing.Size(31, 25)
        Me.lblTwo.TabIndex = 5
        Me.lblTwo.Text = "2:"
        '
        'picHome
        '
        Me.picHome.Image = CType(resources.GetObject("picHome.Image"), System.Drawing.Image)
        Me.picHome.Location = New System.Drawing.Point(253, 263)
        Me.picHome.Name = "picHome"
        Me.picHome.Size = New System.Drawing.Size(290, 98)
        Me.picHome.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picHome.TabIndex = 6
        Me.picHome.TabStop = False
        '
        'lblThree
        '
        Me.lblThree.AutoSize = True
        Me.lblThree.BackColor = System.Drawing.Color.Transparent
        Me.lblThree.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblThree.Location = New System.Drawing.Point(4, 397)
        Me.lblThree.Name = "lblThree"
        Me.lblThree.Size = New System.Drawing.Size(31, 25)
        Me.lblThree.TabIndex = 7
        Me.lblThree.Text = "3:"
        '
        'txtLogout
        '
        Me.txtLogout.Location = New System.Drawing.Point(36, 397)
        Me.txtLogout.Multiline = True
        Me.txtLogout.Name = "txtLogout"
        Me.txtLogout.ReadOnly = True
        Me.txtLogout.Size = New System.Drawing.Size(211, 73)
        Me.txtLogout.TabIndex = 8
        Me.txtLogout.Text = "if you click logout you will be brought back to the login form"
        '
        'lblFour
        '
        Me.lblFour.AutoSize = True
        Me.lblFour.BackColor = System.Drawing.Color.Transparent
        Me.lblFour.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblFour.Location = New System.Drawing.Point(4, 525)
        Me.lblFour.Name = "lblFour"
        Me.lblFour.Size = New System.Drawing.Size(31, 25)
        Me.lblFour.TabIndex = 9
        Me.lblFour.Text = "4:"
        '
        'txtTrack
        '
        Me.txtTrack.Location = New System.Drawing.Point(36, 525)
        Me.txtTrack.Multiline = True
        Me.txtTrack.Name = "txtTrack"
        Me.txtTrack.ReadOnly = True
        Me.txtTrack.Size = New System.Drawing.Size(221, 108)
        Me.txtTrack.TabIndex = 10
        Me.txtTrack.Text = "if you click track order you will be brought to the track order form, where you c" &
    "an enter your order no. to track. Here are some sample orders"
        '
        'picTrack
        '
        Me.picTrack.Image = CType(resources.GetObject("picTrack.Image"), System.Drawing.Image)
        Me.picTrack.Location = New System.Drawing.Point(263, 470)
        Me.picTrack.Name = "picTrack"
        Me.picTrack.Size = New System.Drawing.Size(127, 172)
        Me.picTrack.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picTrack.TabIndex = 11
        Me.picTrack.TabStop = False
        '
        'lblFive
        '
        Me.lblFive.AutoSize = True
        Me.lblFive.BackColor = System.Drawing.Color.Transparent
        Me.lblFive.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblFive.Location = New System.Drawing.Point(494, 55)
        Me.lblFive.Name = "lblFive"
        Me.lblFive.Size = New System.Drawing.Size(31, 25)
        Me.lblFive.TabIndex = 12
        Me.lblFive.Text = "5:"
        '
        'txtMenu
        '
        Me.txtMenu.Location = New System.Drawing.Point(531, 54)
        Me.txtMenu.Multiline = True
        Me.txtMenu.Name = "txtMenu"
        Me.txtMenu.ReadOnly = True
        Me.txtMenu.Size = New System.Drawing.Size(156, 71)
        Me.txtMenu.TabIndex = 13
        Me.txtMenu.Text = "There is a menu strip at the top of all forms for easy navigation"
        '
        'picMenu
        '
        Me.picMenu.Image = CType(resources.GetObject("picMenu.Image"), System.Drawing.Image)
        Me.picMenu.Location = New System.Drawing.Point(693, 68)
        Me.picMenu.Name = "picMenu"
        Me.picMenu.Size = New System.Drawing.Size(259, 29)
        Me.picMenu.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picMenu.TabIndex = 14
        Me.picMenu.TabStop = False
        '
        'lblSix
        '
        Me.lblSix.AutoSize = True
        Me.lblSix.BackColor = System.Drawing.Color.Transparent
        Me.lblSix.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblSix.Location = New System.Drawing.Point(499, 172)
        Me.lblSix.Name = "lblSix"
        Me.lblSix.Size = New System.Drawing.Size(31, 25)
        Me.lblSix.TabIndex = 15
        Me.lblSix.Text = "6:"
        '
        'txtOrder
        '
        Me.txtOrder.Location = New System.Drawing.Point(531, 147)
        Me.txtOrder.Multiline = True
        Me.txtOrder.Name = "txtOrder"
        Me.txtOrder.ReadOnly = True
        Me.txtOrder.Size = New System.Drawing.Size(175, 110)
        Me.txtOrder.TabIndex = 16
        Me.txtOrder.Text = "when ordering shoes, the option you choose from the drop down will make the relat" &
    "ed image visible"
        '
        'lblSeven
        '
        Me.lblSeven.AutoSize = True
        Me.lblSeven.BackColor = System.Drawing.Color.Transparent
        Me.lblSeven.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblSeven.Location = New System.Drawing.Point(433, 397)
        Me.lblSeven.Name = "lblSeven"
        Me.lblSeven.Size = New System.Drawing.Size(31, 25)
        Me.lblSeven.TabIndex = 17
        Me.lblSeven.Text = "7:"
        '
        'txtLogo
        '
        Me.txtLogo.Location = New System.Drawing.Point(470, 381)
        Me.txtLogo.Multiline = True
        Me.txtLogo.Name = "txtLogo"
        Me.txtLogo.ReadOnly = True
        Me.txtLogo.Size = New System.Drawing.Size(208, 227)
        Me.txtLogo.TabIndex = 18
        Me.txtLogo.Text = resources.GetString("txtLogo.Text")
        '
        'picBrowse
        '
        Me.picBrowse.Image = CType(resources.GetObject("picBrowse.Image"), System.Drawing.Image)
        Me.picBrowse.Location = New System.Drawing.Point(713, 335)
        Me.picBrowse.Name = "picBrowse"
        Me.picBrowse.Size = New System.Drawing.Size(127, 41)
        Me.picBrowse.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picBrowse.TabIndex = 19
        Me.picBrowse.TabStop = False
        '
        'picSample
        '
        Me.picSample.Image = CType(resources.GetObject("picSample.Image"), System.Drawing.Image)
        Me.picSample.Location = New System.Drawing.Point(704, 397)
        Me.picSample.Name = "picSample"
        Me.picSample.Size = New System.Drawing.Size(190, 92)
        Me.picSample.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picSample.TabIndex = 20
        Me.picSample.TabStop = False
        '
        'btnNext
        '
        Me.btnNext.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.btnNext.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnNext.Location = New System.Drawing.Point(811, 569)
        Me.btnNext.Name = "btnNext"
        Me.btnNext.Size = New System.Drawing.Size(155, 73)
        Me.btnNext.TabIndex = 24
        Me.btnNext.Text = "&Next Page"
        Me.btnNext.UseVisualStyleBackColor = False
        '
        'picClear
        '
        Me.picClear.Image = CType(resources.GetObject("picClear.Image"), System.Drawing.Image)
        Me.picClear.Location = New System.Drawing.Point(704, 500)
        Me.picClear.Name = "picClear"
        Me.picClear.Size = New System.Drawing.Size(100, 50)
        Me.picClear.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picClear.TabIndex = 25
        Me.picClear.TabStop = False
        '
        'frmUserManual
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = Global.Project.My.Resources.Resources.background
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(998, 666)
        Me.Controls.Add(Me.picClear)
        Me.Controls.Add(Me.btnNext)
        Me.Controls.Add(Me.picSample)
        Me.Controls.Add(Me.picBrowse)
        Me.Controls.Add(Me.txtLogo)
        Me.Controls.Add(Me.lblSeven)
        Me.Controls.Add(Me.txtOrder)
        Me.Controls.Add(Me.lblSix)
        Me.Controls.Add(Me.picMenu)
        Me.Controls.Add(Me.txtMenu)
        Me.Controls.Add(Me.lblFive)
        Me.Controls.Add(Me.picTrack)
        Me.Controls.Add(Me.txtTrack)
        Me.Controls.Add(Me.lblFour)
        Me.Controls.Add(Me.txtLogout)
        Me.Controls.Add(Me.lblThree)
        Me.Controls.Add(Me.picHome)
        Me.Controls.Add(Me.lblTwo)
        Me.Controls.Add(Me.lblOne)
        Me.Controls.Add(Me.txtAccount)
        Me.Controls.Add(Me.lblLogin)
        Me.Controls.Add(Me.picUsers)
        Me.Controls.Add(Me.txtLogin)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "frmUserManual"
        Me.Text = "User Manual"
        CType(Me.picUsers, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picHome, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picTrack, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picMenu, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picBrowse, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picSample, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picClear, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents txtLogin As TextBox
    Friend WithEvents picUsers As PictureBox
    Friend WithEvents lblLogin As Label
    Friend WithEvents txtAccount As TextBox
    Friend WithEvents lblOne As Label
    Friend WithEvents lblTwo As Label
    Friend WithEvents picHome As PictureBox
    Friend WithEvents lblThree As Label
    Friend WithEvents txtLogout As TextBox
    Friend WithEvents lblFour As Label
    Friend WithEvents txtTrack As TextBox
    Friend WithEvents picTrack As PictureBox
    Friend WithEvents lblFive As Label
    Friend WithEvents txtMenu As TextBox
    Friend WithEvents picMenu As PictureBox
    Friend WithEvents lblSix As Label
    Friend WithEvents txtOrder As TextBox
    Friend WithEvents lblSeven As Label
    Friend WithEvents txtLogo As TextBox
    Friend WithEvents picBrowse As PictureBox
    Friend WithEvents picSample As PictureBox
    Friend WithEvents btnNext As Button
    Friend WithEvents picClear As PictureBox
End Class
