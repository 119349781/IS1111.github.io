﻿Public Class frmUserManual
    Private Sub btnNext_Click(sender As Object, e As EventArgs) Handles btnNext.Click
        'brings user to page 2 of user manual for customer
        Me.Hide()
        frmManualPg2.Show()
    End Sub
End Class