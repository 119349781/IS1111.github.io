﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmManualPg2
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmManualPg2))
        Me.btnBack = New System.Windows.Forms.Button()
        Me.picDiscount = New System.Windows.Forms.PictureBox()
        Me.txtDiscount = New System.Windows.Forms.TextBox()
        Me.lblEight = New System.Windows.Forms.Label()
        Me.lblNine = New System.Windows.Forms.Label()
        Me.txtProceed = New System.Windows.Forms.TextBox()
        Me.picProceed = New System.Windows.Forms.PictureBox()
        Me.lblTen = New System.Windows.Forms.Label()
        Me.txtPay = New System.Windows.Forms.TextBox()
        Me.picPay = New System.Windows.Forms.PictureBox()
        Me.lblConfirm = New System.Windows.Forms.Label()
        Me.txtConfirm = New System.Windows.Forms.TextBox()
        Me.picConfirm = New System.Windows.Forms.PictureBox()
        Me.picMenu = New System.Windows.Forms.PictureBox()
        Me.btnEmployee = New System.Windows.Forms.Button()
        CType(Me.picDiscount, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picProceed, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picPay, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picConfirm, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picMenu, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'btnBack
        '
        Me.btnBack.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.btnBack.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnBack.Location = New System.Drawing.Point(751, 31)
        Me.btnBack.Name = "btnBack"
        Me.btnBack.Size = New System.Drawing.Size(132, 95)
        Me.btnBack.TabIndex = 0
        Me.btnBack.Text = "&Back"
        Me.btnBack.UseVisualStyleBackColor = False
        '
        'picDiscount
        '
        Me.picDiscount.Image = CType(resources.GetObject("picDiscount.Image"), System.Drawing.Image)
        Me.picDiscount.Location = New System.Drawing.Point(233, 40)
        Me.picDiscount.Name = "picDiscount"
        Me.picDiscount.Size = New System.Drawing.Size(244, 64)
        Me.picDiscount.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picDiscount.TabIndex = 26
        Me.picDiscount.TabStop = False
        '
        'txtDiscount
        '
        Me.txtDiscount.Location = New System.Drawing.Point(49, 31)
        Me.txtDiscount.Multiline = True
        Me.txtDiscount.Name = "txtDiscount"
        Me.txtDiscount.ReadOnly = True
        Me.txtDiscount.Size = New System.Drawing.Size(178, 73)
        Me.txtDiscount.TabIndex = 25
        Me.txtDiscount.Text = "the user gets a 15% discount if they enter the line 'get15'"
        '
        'lblEight
        '
        Me.lblEight.AutoSize = True
        Me.lblEight.BackColor = System.Drawing.Color.Transparent
        Me.lblEight.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblEight.Location = New System.Drawing.Point(12, 46)
        Me.lblEight.Name = "lblEight"
        Me.lblEight.Size = New System.Drawing.Size(31, 25)
        Me.lblEight.TabIndex = 24
        Me.lblEight.Text = "8:"
        '
        'lblNine
        '
        Me.lblNine.AutoSize = True
        Me.lblNine.BackColor = System.Drawing.Color.Transparent
        Me.lblNine.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblNine.Location = New System.Drawing.Point(12, 139)
        Me.lblNine.Name = "lblNine"
        Me.lblNine.Size = New System.Drawing.Size(31, 25)
        Me.lblNine.TabIndex = 27
        Me.lblNine.Text = "9:"
        '
        'txtProceed
        '
        Me.txtProceed.Location = New System.Drawing.Point(50, 139)
        Me.txtProceed.Multiline = True
        Me.txtProceed.Name = "txtProceed"
        Me.txtProceed.ReadOnly = True
        Me.txtProceed.Size = New System.Drawing.Size(178, 90)
        Me.txtProceed.TabIndex = 28
        Me.txtProceed.Text = "To click the procced to next page button to view the total and to pay for the sho" &
    "es"
        '
        'picProceed
        '
        Me.picProceed.Image = CType(resources.GetObject("picProceed.Image"), System.Drawing.Image)
        Me.picProceed.Location = New System.Drawing.Point(234, 153)
        Me.picProceed.Name = "picProceed"
        Me.picProceed.Size = New System.Drawing.Size(202, 50)
        Me.picProceed.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picProceed.TabIndex = 29
        Me.picProceed.TabStop = False
        '
        'lblTen
        '
        Me.lblTen.AutoSize = True
        Me.lblTen.BackColor = System.Drawing.Color.Transparent
        Me.lblTen.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTen.Location = New System.Drawing.Point(12, 268)
        Me.lblTen.Name = "lblTen"
        Me.lblTen.Size = New System.Drawing.Size(43, 25)
        Me.lblTen.TabIndex = 30
        Me.lblTen.Text = "10:"
        '
        'txtPay
        '
        Me.txtPay.Location = New System.Drawing.Point(49, 269)
        Me.txtPay.Multiline = True
        Me.txtPay.Name = "txtPay"
        Me.txtPay.ReadOnly = True
        Me.txtPay.Size = New System.Drawing.Size(178, 113)
        Me.txtPay.TabIndex = 31
        Me.txtPay.Text = "You must fill out all textboxes before the order can be paid for. Or you can pres" &
    "s 'back' to return to the order form "
        '
        'picPay
        '
        Me.picPay.Image = CType(resources.GetObject("picPay.Image"), System.Drawing.Image)
        Me.picPay.Location = New System.Drawing.Point(234, 268)
        Me.picPay.Name = "picPay"
        Me.picPay.Size = New System.Drawing.Size(144, 113)
        Me.picPay.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picPay.TabIndex = 32
        Me.picPay.TabStop = False
        '
        'lblConfirm
        '
        Me.lblConfirm.AutoSize = True
        Me.lblConfirm.BackColor = System.Drawing.Color.Transparent
        Me.lblConfirm.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblConfirm.Location = New System.Drawing.Point(12, 412)
        Me.lblConfirm.Name = "lblConfirm"
        Me.lblConfirm.Size = New System.Drawing.Size(43, 25)
        Me.lblConfirm.TabIndex = 33
        Me.lblConfirm.Text = "11:"
        '
        'txtConfirm
        '
        Me.txtConfirm.Location = New System.Drawing.Point(49, 412)
        Me.txtConfirm.Multiline = True
        Me.txtConfirm.Name = "txtConfirm"
        Me.txtConfirm.ReadOnly = True
        Me.txtConfirm.Size = New System.Drawing.Size(298, 128)
        Me.txtConfirm.TabIndex = 34
        Me.txtConfirm.Text = resources.GetString("txtConfirm.Text")
        '
        'picConfirm
        '
        Me.picConfirm.Image = CType(resources.GetObject("picConfirm.Image"), System.Drawing.Image)
        Me.picConfirm.Location = New System.Drawing.Point(397, 412)
        Me.picConfirm.Name = "picConfirm"
        Me.picConfirm.Size = New System.Drawing.Size(124, 61)
        Me.picConfirm.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picConfirm.TabIndex = 35
        Me.picConfirm.TabStop = False
        '
        'picMenu
        '
        Me.picMenu.Image = CType(resources.GetObject("picMenu.Image"), System.Drawing.Image)
        Me.picMenu.Location = New System.Drawing.Point(354, 491)
        Me.picMenu.Name = "picMenu"
        Me.picMenu.Size = New System.Drawing.Size(332, 50)
        Me.picMenu.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picMenu.TabIndex = 36
        Me.picMenu.TabStop = False
        '
        'btnEmployee
        '
        Me.btnEmployee.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.btnEmployee.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnEmployee.Location = New System.Drawing.Point(751, 221)
        Me.btnEmployee.Name = "btnEmployee"
        Me.btnEmployee.Size = New System.Drawing.Size(132, 72)
        Me.btnEmployee.TabIndex = 37
        Me.btnEmployee.Text = "&Employee Manual"
        Me.btnEmployee.UseVisualStyleBackColor = False
        '
        'frmManualPg2
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = Global.Project.My.Resources.Resources.background
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(926, 544)
        Me.Controls.Add(Me.btnEmployee)
        Me.Controls.Add(Me.picMenu)
        Me.Controls.Add(Me.picConfirm)
        Me.Controls.Add(Me.txtConfirm)
        Me.Controls.Add(Me.lblConfirm)
        Me.Controls.Add(Me.picPay)
        Me.Controls.Add(Me.txtPay)
        Me.Controls.Add(Me.lblTen)
        Me.Controls.Add(Me.picProceed)
        Me.Controls.Add(Me.txtProceed)
        Me.Controls.Add(Me.lblNine)
        Me.Controls.Add(Me.picDiscount)
        Me.Controls.Add(Me.txtDiscount)
        Me.Controls.Add(Me.lblEight)
        Me.Controls.Add(Me.btnBack)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "frmManualPg2"
        Me.Text = "Manual Pg2"
        CType(Me.picDiscount, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picProceed, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picPay, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picConfirm, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picMenu, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btnBack As Button
    Friend WithEvents picDiscount As PictureBox
    Friend WithEvents txtDiscount As TextBox
    Friend WithEvents lblEight As Label
    Friend WithEvents lblNine As Label
    Friend WithEvents txtProceed As TextBox
    Friend WithEvents picProceed As PictureBox
    Friend WithEvents lblTen As Label
    Friend WithEvents txtPay As TextBox
    Friend WithEvents picPay As PictureBox
    Friend WithEvents lblConfirm As Label
    Friend WithEvents txtConfirm As TextBox
    Friend WithEvents picConfirm As PictureBox
    Friend WithEvents picMenu As PictureBox
    Friend WithEvents btnEmployee As Button
End Class
